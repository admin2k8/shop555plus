<?php
/*
╔═════════════════════════════════════════════╗
║     Design by Youtuber THI FF VLOG          ║
║      Facebook: facebook.com/ytbThiFF        ║
║   Hotline: 0369.056.756 - 0359.283.357      ║
╚═════════════════════════════════════════════╝
*/
?>
        <footer class="footer">
            <div class="container-fluid">
                <nav class="pull-left">
                    <ul>

                        <li>
                            <a href="https://www.facebook.com/">
                                LT09 GAMING TV
                            </a>
                        </li>
                    </ul>
                </nav>
                <div class="copyright pull-right">
                    &copy; <script>document.write(new Date().getFullYear())</script>
                </div>
            </div>
        </footer>

    </div>
</div>

    <!--   Core JS Files   -->  
    
    <script src="/admin/assets/js/bootstrap-multiselect.js"></script>
	<script src="/admin/assets/js/bootstrap-checkbox-radio.js"></script>
    <script src="/admin/assets/js/bootstrap-notify.js"></script>
	<script src="/admin/assets/js/paper-dashboard.js"></script>
	<script src="/admin/assets/js/demo.js"></script>
</body>



</html>
