
<div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col s12 m6">
      <div id="Form-advance" class="card card card-default scrollspy">
        <div class="card-content">
          <h4 class="card-title">Mở Hòm Kim Cương </h4>
          <form class="col s12" method="POST">
              

<?php 
$loai = "ff";
$gia = 20000;
$slgoi = $_POST['slgoi'];
$goi = $_POST['goi'];
$ghichu = 'gói vận may '.$goi.' kim cương';
if (isset($_POST['upkc'])){
    
$i = 1; 
while ($i <= $slgoi){ 
        
        mysql_query("INSERT INTO `homff` SET
            `loai` = '". $loai ."',
            `text` = 'VMKC' ,
            `kimcuong` = '".$goi."',
            `gia` = '". $gia ."',
            `trangthai` = 'on',
            `kichhoat` = 'yes',
            `noidung` = '" . $ghichu . "',
            `time` = '" . time() . "'
            ");
     $i++; // Tăng biến $i lên 1
}           
echo'<div class="alert alert-success" role="alert">
  <span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span>
  <span class="sr-only">Thông báo:</span>Thành công
</div>';
        
    }
    
    

    



?>
<form action ="" method="post" enctype="multipart/form-data">
    <div class="row">
   
    <div class="col-xs-12">
        <div class="panel-body">

	              
	              
	              <div class="row">

	<div class="col-md-4">
	    <div class="form-group">
	                <label>Loại gói</label>
	        <div class="input-group">
	            <div class="input-group-addon">
	               Loại Vận may kim cương
	            </div>
	<select class="form-control" name="goi" id="goi">


	                <option value="45">
	                    45
	                </option>
	                <option value="480">
	                    480
	                </option>
	                <option value="2600">
	                   2600
	                </option>
	               <option value="5300">
	                    5300
	                </option>
	              <!--   <option value="Tối Thượng">
	                    Random 4
	                </option>
	                <option value="VIP">
	                    Random 5 
	                </option> -->
	            </select>
	        </div>
	    </div>
	</div>
	
	
	
	<div class="row">

	<div class="col-md-4">
	    <div class="form-group">
	                <label>Số lượng gói</label>
	        <div class="input-group">
	            <div class="input-group-addon">
	               Chọn gói
	            </div>
	<select class="form-control" name="slgoi" id="slgoi">
                    <option value="1">1
                    </option>
                    <option value="5">5
                    </option>

	                <option value="10">
	                    10 
	                </option>
	                <option value="20">
	                    20
	                </option>
	                <option value="30">
	                    30
	                </option>
	               <!-- <option value="75000">
	                    75.000đ
	                </option>
	                <option value="120000">
	                    120.000đ
	                </option>
	                <option value="250000">
	                    250.000đ
	                </option>-->
	            </select>
	        </div>
	    </div>
	</div>

</div>
</div>
</div>
<div class="row">
	              <b id="note"></b>
	            <div class="col-md-12">
	              <div class="form-group">
	<button id="login" type="submit" class="sa-lib-dk btn btn-success" name="upkc">Đăng acc</button>

	              </div>
	            </div>
	          </div>

</form>


    

      </div>
    </div>
    
      </div>
    </div>
    
      </div>
    </div>
    
      </div>
    </div>
    
      </div>
    </div>
      </div>
    </div>
    