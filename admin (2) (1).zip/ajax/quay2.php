<?php
/*
╔═════════════════════════════════════════════╗
║     Design by Lua Uy Tin                    ║
║      Facebook: facebook.com/luauytin        ║
║   Hotline: 0369.056.756 - 0359.283.357      ║
╚═════════════════════════════════════════════╝
*/
require_once(realpath($_SERVER["DOCUMENT_ROOT"]) .'/core/init.php');
//check post
$iduser = $accounts['username'];
if(!$_POST){load_url('/');}
if (!is_client()) {
        echo json_encode(array('status' => "error",'link' => "/login.html", 'msg' => "Bạn chưa đăng nhập !"));exit();}

if($_POST['type'] == 'kimhunglatthefreefire'){
$phanqua = array('89' => '60', '111' => '15', '120' => '5', '250' => '5', '500' => '5', '3000' => '4', '5000' => '3', '12000' => '2', '25000' => '1');//chỉnh tỉ lệ ở đây

$mangphanqua = array();
foreach ($phanqua as $phanqua=>$value)
{
    $mangphanqua = array_merge($mangphanqua, array_fill(0, $value, $phanqua));
}

$kc = $mangphanqua[array_rand($mangphanqua)];
$img = '/latthe/'.$kc.'kc.jpg';


	if(!is_client()){
 $status = 'login'; // false
 $msg = 'Đăng nhập đi, xem json cái lol.';
}
elseif($settings['status'] == 0){
    $status = 'error'; // false
    $msg = 'Trang web của chúng tôi đang tạm dừng giao dịch, quay lại sau !';
    
}
elseif ($accounts['cash'] < 10000 ) {
        $status = 'error'; // false
    $msg = 'Số tiền không đủ để thực hiện giao dịch, vui lòng nạp thêm tiền vào tài khoản.';
    
}
else{
   $status = 'success'; // 
   $ketqua123 = 'success';
   $db->query("UPDATE `products` SET `status` = '1' WHERE `id` = '{$id}' LIMIT 1");// status
        $db->query("UPDATE `accounts` SET `cash` = `cash` - '10000' WHERE `username` = '{$iduser}'");//trừ tiền
        $db->query("UPDATE `accounts` SET `diamon_ff` = `diamon_ff` + $kc WHERE `username` = '{$iduser}'");//cộng kim cương
        $db->query("INSERT INTO `HK_lattheff` (nguoiquay,kimcuong,date,time) VALUES ('$iduser','$kc','". date('H:i:s d-m-Y') ."','".time()."')");// lịch sử
   
 $msg = 'Chúc mừng bạn đã trúng '.number_format($kc).' Kim Cương';

}

	$arr = array('status' => $status,'success' => $ketqua123, 'img' => $img,'msg' => $msg);

echo json_encode($arr);
}else{
    echo '?';
}