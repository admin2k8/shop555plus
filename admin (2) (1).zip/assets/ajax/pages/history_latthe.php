<?php
require_once(realpath($_SERVER["DOCUMENT_ROOT"]) .'/core/init.php');
$get_info = new Info;
if (!$user) {
?>
<tr><td colspan="7" class="text-center"><p>Vui lòng đăng nhập để xem thông tin !</p></td></tr>
<?php
exit;
}elseif(!$_POST){
exit;
}

$iduser = $accounts['username'];
$input = new Input;
$page = (int)$input->input_post("page");

$total_record = $db->fetch_row("SELECT COUNT(id) FROM HK_lattheff WHERE nguoiquay = '{$iduser}' LIMIT 1");
$limit = 20*$page;
$sql_get_list_mem = "SELECT * FROM `HK_lattheff` WHERE nguoiquay = '{$iduser}' ORDER BY `time` DESC  LIMIT $limit";

// Nếu có 
if ($total_record){
foreach ($db->fetch_assoc($sql_get_list_mem, 0) as $key => $data){?>
                <tr>
                    <td><?=$data['id']; ?></td>
                    <td><?=number_format($data['kimcuong'], 0, '.', '.'); ?>KC</td>
                    <td><?=$data['date']; ?></td>
                </tr>
<?php } if($limit < $total_record){?>
<td class="text-center" colspan="7"><a onclick="page=<?php echo $page+1;?>;load_page();">Xem thêm</a></td>
<?php }}else {
?>
<tr><td colspan="7" class="text-center"><p>Không có dữ liệu !</p></td></tr>
<?php
}
?>




