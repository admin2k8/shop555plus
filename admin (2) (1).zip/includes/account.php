<div class="sa-mainsa">
    <div class="container">
        <div class="sa-lprod">
            <div class="sa-filter">
                <div class="row">
<div class="col-sm-3 text-center" style="margin-right: -11px; margin-left: 11px;">
                    <a class="button btn <?php echo ($type == 'ZingSpeed Mobile') ? 'btn-danger':'btn-default';?>" type="button" href="/tencent/zing-speed-mobile.html">ZingSpeed Mobile <img src="/assets/images/new.gif"></a>
                    <a class="button btn <?php echo ($type == 'Free Fire') ? 'btn-danger':'btn-default';?>" type="button" href="/garena/free-fire.html">Free Fire <img src="/assets/images/hot.gif"></a>
</div>
<div class="col-sm-9">
<?php
//lấy loại acc
$type = $luauytin->type_account(GET('type')) != '' ? $luauytin->type_account(GET('type')):'ZingSpeed Mobile';

$cash = "SELECT * FROM `history_buy` where `id_products` != '0' order by id desc LIMIT 20";
if ($db->num_rows($cash) == 0):?>
<tr><marquee><p>Chưa có ai mua</p></marquee></tr>
<?php else:
    echo'<marquee>';
    foreach ($db->fetch_assoc($cash, 0) as $key => $data){?>
<img width="36" height="36" src="/assets/images/run.gif" longdesc="36">  <span class="text-success"><?=$data['name']?></span> đã mua Tài khoản #<?=$data['id_products']?>  giá  <?=number_format($data['price'])?>  <sup class="text-muted">đ</sup> - <span class="text-muted"><i> <?php echo time_stamp($data['time']); ?></i></span>
<?php }; echo'</marquee>'; endif; ?>   
</div></div></div></div></div></div>
 
<script>var type = "<?=GET('type');?>";</script>
<script src="/assets/js/bootstrap3-typeahead.min.js"></script>
<script src="/assets/js/Custom/ffilter.js"></script>
<div class="sa-mainsa">
    <div class="container">
        <div class="sa-lprod">
            <div class="sa-filter">
                <span class="sa-filic"><i class="glyphicon glyphicon-filter"></i> LỌC THEO</span>
                <div class="sa-filbox">
                <div class="dropdown" data-filter="sap-xep">
                    <button class="btn btn-default dropdown-toggle" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    Sắp Xếp Theo <span class="caret"></span>
                    </button>
                    <ul class="dropdown-menu select">
                        <li onclick="order=0;"><a href="javascript:;" class="acfiit">Mặc định </a></li>
                        <li onclick="order=1;"><a href="javascript:;" class="acfiit">Tài khoản mới thêm </a></li>
                        <li onclick="order=2;"><a href="javascript:;" class="acfiit">Giá giảm dần </a></li>
                        <li onclick="order=3;"><a href="javascript:;" class="acfiit">Giá tăng dần </a></li>
                        <li onclick="order=4;"><a href="javascript:;" class="acfiit">Số tướng giảm dần </a></li>
                        <li onclick="order=5;"><a href="javascript:;" class="acfiit">Số tướng tăng dần </a></li>
                        <li onclick="order=6;"><a href="javascript:;" class="acfiit">Số trang phục giảm dần </a></li>
                        <li onclick="order=7;"><a href="javascript:;" class="acfiit">Số trang phục tăng dần </a></li>
                        <li onclick="order=8;"><a href="javascript:;" class="acfiit">Rank từ cao đến thấp </a></li>
                        <li onclick="order=9;"><a href="javascript:;" class="acfiit">Rank từ thấp dến cao </a></li>
                    </ul>
                </div>
                <div class="dropdown" data-filter="tim-theo-gia">
                    <button class="btn btn-default dropdown-toggle" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    Tìm Theo Giá <span class="caret"></span>
                    </button>
                    <ul class="dropdown-menu select">
                        <li onclick="price=1;"><a href="javascript:;" class="acfiit">50K trở xuống </a></li>
                        <li onclick="price=2;"><a href="javascript:;" class="acfiit">Từ 50K đến 100K </a></li>
                        <li onclick="price=3;"><a href="javascript:;" class="acfiit">Từ 100K đến 500K </a></li>
                        <li onclick="price=4;"><a href="javascript:;" class="acfiit">Từ 500K đến 1 Triệu </a></li>
                        <li onclick="price=5;"><a href="javascript:;" class="acfiit">Từ 1 Triệu trở lên </a></li>
                    </ul>
                </div>
                <div class="dropdown" data-filter="tim-theo-rank">
                    <button class="btn btn-default dropdown-toggle" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    Tìm Theo Rank <span class="caret"></span>
                    </button>
                    <ul class="dropdown-menu select">
                        <li onclick="rank=0;"><a href="javascript:;" class="acfiit">Chưa rank </a></li>
                        <li onclick="rank=2;"><a href="javascript:;" class="acfiit">Rank Đồng </a></li>
                        <li onclick="rank=3;"><a href="javascript:;" class="acfiit">Rank Bạc </a></li>
                        <li onclick="rank=4;"><a href="javascript:;" class="acfiit">Rank Vàng </a></li>
                        <li onclick="rank=5;"><a href="javascript:;" class="acfiit">Rank Bạch Kim </a></li>
                        <li onclick="rank=6;"><a href="javascript:;" class="acfiit">Rank Kim Cương </a></li>
                        <li onclick="rank=7;"><a href="javascript:;" class="acfiit">Rank Cao Thủ </a></li>
                        <li onclick="rank=8;"><a href="javascript:;" class="acfiit">Rank Thách Đấu </a></li>
                    </ul>
                </div>
            <?php if($type == 'ZingSpeed Mobile'):?>
                <div class="dropdown" data-filter="tim-theo-tuong">
                    <button class="btn btn-default dropdown-toggle" type="button" data-toggle="dropdown">Nhập tên tướng</button>
                    <ul class="dropdown-menu filter-clothes">
                        <li class="txt-filter">
                            <input style="margin-left: 5px; color: #121212; border:none; padding: 5px; background-color: #fff;" type="text" id="champFilter" placeholder="Nhập tên tướng..." data-provide="typeahead" autocomplete="off"><ul class="typeahead dropdown-menu"></ul>
                        </li>
                    </ul>
                </div>
                <div class="dropdown" data-filter="trang-phuc">
                    <button class="btn btn-default dropdown-toggle" type="button" data-toggle="dropdown">Nhập tên trang phục</button>
                    <ul class="dropdown-menu filter-clothes">
                        <li class="txt-filter">
                            <input style="margin-left: 5px; color: #121212; border:none; padding: 5px; background-color: #fff;" type="text" id="skinFilter" placeholder="Nhập tên trang phục..." data-provide="typeahead" autocomplete="off"><ul class="typeahead dropdown-menu"></ul>
                        </li>
                    </ul>
                </div>
            <?php endif;?>
                <button class="sa-ftbtndel btn btn-default">XÓA</button>
            </div>
            </div>
            <div class="sa-lpmain"></div>
            <div id="loading" style="text-align: center; margin-bottom: 30px;">
                <img src="/assets/images/loading.gif">
            </div>
        </div>
    </div>
</div>
<?php $luauytin_tb = new Info; if($luauytin_tb->notify_account(GET('type')) != ''):?>
<script type="text/javascript">
               swal({   
                        title: "Thông báo",
                            html: true,
                            text: "<?=$luauytin_tb->notify_account(GET('type'));?>",   
                            showConfirmButton:true
        
                     }, function() {
                         
                         
                        });
</script>
<?php endif;?>