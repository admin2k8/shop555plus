<?php
/*
╔═════════════════════════════════════════════╗
║     Design by Lua Uy Tin                    ║
║      Facebook: facebook.com/luauytin        ║
║   Hotline: 0369.056.756 - 0359.283.357      ║
╚═════════════════════════════════════════════╝
*/

$count_buy = $db->fetch_row("SELECT COUNT(*) FROM `products` WHERE `status` != '0'")+$db->fetch_row("SELECT COUNT(*) FROM `acc_random` WHERE `status` != '0'")+4756;

$acc = $db->fetch_row("SELECT COUNT(*) FROM `products` WHERE `status` = '0'") + $db->fetch_row("SELECT COUNT(*) FROM `acc_random` WHERE `status` = '0'");
$members = $db->fetch_row("SELECT COUNT(*) FROM `accounts`")+7623;
?>
<style>
.footer h4{
    font-size:25px;
    text-align:left;
    font-weight:700;
    margin-bottom:20px;
  }
  .fgd1 h3{
    margin-bottom:12px;
  }
  .fgd1 .fa {
      font-size: 16px;
      width: 35px;
      height: 35px;
      text-align: center;
      line-height: 33px;
      border: 1px solid #000;
      margin: 6px;
    transition: 0.5s all;
    -webkit-transition: 0.5s all;
    -moz-transition: 0.5s all;
    -o-transition: 0.5s all;
    -ms-transition: 0.5s all;
    color:#000;
  }
  .fgd1 i.fa.fa-twitter {
      margin-left:0;
  }
  .fgd1 i.fa.fa-twitter:hover{
    background:#1da1f2;
    color:#fff;
    border:1px solid #1da1f2;
  }
  .social-icon a .fa-twitter:hover{
    color:#1da1f2;
  }
  .fgd1 i.fa.fa-dribbble:hover{
    background:#ea4c89;
    color:#fff;
    border:1px solid #ea4c89
  }
  .social-icon a .fa-dribbble:hover{
    color:#ea4c89;
  }
  .fgd1 i.fa.fa-facebook:hover{
    background: #3b5998;
    color:#fff;
    border:1px solid #3b5998;
  }
  .social-icon a .fa-facebook:hover{
    color: #3b5998;
  }
  .fgd1 i.fa.fa-linkedin:hover{
    background:#0077b5;
    color:#fff;
    border:1px solid #0077b5;
  }
  .social-icon a .fa-linkedin:hover{
    color:#0077b5;
  }
  .footer ul li{
    font-size:14px;
    list-style-type:none;
    line-height:35px;
  }
  .footer ul li a{
    color: #1ca4f3;
      font-weight: bold;
  }
  .footer ul li a:hover{
    color:#447dfd;
  }
  p.copy-right{
    margin-top:30px;
    text-align:center;
    font-weight:bold;
    font-size:14px;
    color:#fff;
    background:#000;
  }
 </style>
 
<div class="shopping-cart">

	<a href="/history/buy.html"><div class="icon">
		<span style="display: block; margin-top: 15px">Giỏ</span><i class="fas fa-shopping-cart"></i>
	</div></a>
</div>
<style>
  .flex {
    display: flex;
  }

  .flex-around {
    justify-content: space-around;
  }
  
  .col-6 {
    width: 50%;
  }

  .top-item {
    padding: 10px;
    box-sizing: border-box;
  }

  .box {
    position: relative;
    border-radius: 3px;
    background: #ffffff;
    /* border-top: 3px solid #d2d6de; */
    margin-bottom: 20px;
    width: 100%;
    box-shadow: 0 0px 0px rgba(0,0,0,0.1);
  }

  .box-danger {
    border: 2px solid #FFFF00;
  }

  .box-header {
    color: #fff;
    background: #ff502e;
    background-color: #ff502e;
    border-bottom: 1px solid #f4f4f4;
    display: block;
    padding: 10px;
    position: relative;
    text-align: center;
  }

  .top-item li a{
    background-color: inherit !important;
    color: white !important;
    border: none !important;
    font-size: 26px;
  }
  .top-item li.active{
    border-bottom: 1px solid #fff;
  }

  .b-0 {
    border: none;

  }

  label.control-label {
    padding: 5px;
    font-weight: 300;
    color: #2e353a;
    font-size: 18px;
  }

  .top-item .btn-danger {
    color: #ffffff !important;
    background: #f44336 !important;
    border-color: #fffa00 !important;
  }

  .top-item .fa {
    font-family: "Font Awesome 5 Free" !important;
  }

  @media only screen and (min-width: 600px) {
    .nav-justified {
      display: block !important;
    }
  }

  @media only screen and (max-width: 600px) {
    .box-title {
    font-size: 20px;
  }
  }

  


  </style>
<style media="screen">
	.shopping-cart {
		position: fixed;
		right: 25px;
		bottom: 100px;
		width: 60px;
		height: 60px;
z-index: 99999;
	}

	.shopping-cart .icon {
		background-color: #fbff01;(19, 207, 19);
		border-radius: 35%;
		color: #FF000D;
		width: 100%;
		height: 100%;
                text-align: center
	}

	.shopping-cart .icon i {
		font-size: 30px;
	}
</style>
<div class="sa-footer">
    <div class="container">
        <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-6">
                <div class="sa-ftadd">
                    <p>➽Địa Chỉ Cơ Sở 1: 39 Hai Ba Trừng - Phường12 - Quận6 - Hồ Chí Minh</p>
------------------------------------------------------<p></p>
                    <p>➽Địa Chỉ Cơ Sở 2: 79 Lý Nam Đề - Cưa Đồng - Hoàn Kiếm - Hà Nội</p>
------------------------------------------------------<p></p>
                    <p>➽Địa Chỉ Cơ Sở 3: 68 Lê Đình Lý - P.Vĩnh Trùng - Q.Thanh Khê - Đà Nẵng     
 

                </div>
                <div class="sa-fthotline">
                    <div class="sa-ftarow clearfix">
                        <div class="sa-ftacol">
                            <p><a href="tel:056.3939.674" title="">SDT Của 4 Admin Hỗ Trợ 24/7:</a></p>
<br>
                            <p><a href="tel:056.3939.674" title="">Ad1: 056.3939.674 (Kiều My)</a></p>
                            <p><a href="tel:056.3939.674" title="">Ad2: 056.3939.675 (Yến Nhi)</a></p>
                            <p><a href="tel:056.3939.674" title="">Ad3: 056.3939.676 (Mỹ Dung)</a></p>
                            <p><a href="tel:056.3939.674" title="">Ad4: 056.3939.677 (Minh Thư)</a></p>
<br>
                            <p><a href="" title=""></a></p>
                        </div>
                        <div class="sa-ftacol sa-fthwork">
                            Thời Gian Làm Việc: <strong>Hỗ Trợ 24/7/365</strong> Ngày(Cả Ngày Lễ Tết)
                        </div>
                    </div>
                </div>
            </div>
                    <div class="col-xs-12 col-sm-12 col-md-6" style="margin-bottom: 130px">
                <ul class="sl-ftviews" style="
    margin: 0 -5px;
">

                    <li style="
    float: left;
    width: 33.333%;
    padding: 0 5px;
"><span class="sl-fti2" style="
    display: inline-block;
    float: left;
    height: 62px;
    line-height: 62px;
    text-align: center;
    border: 1px solid #717171;
    background: #000000;
    -webkit-border-radius: 100%;
    -moz-border-radius: 100%;
    border-radius: 100%;
    margin-right: 10px;
"></span> <p style="
margin-left: 2px;
    font-size: 16px;
    color: #0DFB51;
"><strong style="
    font-size: 20px;
    color: #ff3600;
    display: block;
    padding-top: 5px;
">5 NĂM</strong>Hoặt Động</p></li>
                    <li style="
    float: left;
    width: 33.333%;
    padding: 0 5px;
"><span class="sl-fti2" style="
    display: inline-block;
    float: left;
    height: 62px;
    line-height: 62px;
    text-align: center;
    border: 1px solid #717171;
    background: #000000;
    -webkit-border-radius: 100%;
    -moz-border-radius: 100%;
    border-radius: 100%;
    margin-right: 10px;
"></span> <p style="
margin-left: 2px;
    font-size: 16px;
    color: #0DFB51;
"><strong style="
    font-size: 20px;
    color: #ff3600;
    display: block;
    padding-top: 5px;
"><?=$members?></strong>Thành viên</p></li>
                    <li style="
    float: left;
    width: 33.333%;
    padding: 0 5px;
"><span class="sl-fti2" style="
    display: inline-block;
    float: left;
    height: 62px;
    line-height: 62px;
    text-align: center;
    border: 1px solid #717171;
    background: #000000;
    -webkit-border-radius: 100%;
    -moz-border-radius: 100%;
    border-radius: 100%;
    margin-right: 10px;
"></span> <p style="
margin-left: 2px;
    font-size: 16px;
    color: #0DFB51;
"><strong style="
    font-size: 20px;
    color: #ff3600;
    display: block;
    padding-top: 5px;
">857.968</strong>Lượt Vào Shop</p></li>
                    <li style="
    float: left;
    width: 33.333%;
    padding: 0 5px;
"><span class="sl-fti2" style="
    display: inline-block;
    float: left;
    height: 62px;
    line-height: 62px;
    text-align: center;
    border: 1px solid #717171;
    background: #000000;
    -webkit-border-radius: 100%;
    -moz-border-radius: 100%;
    border-radius: 100%;
    margin-right: 10px;
"></span> <p style="
margin-left: 2px;
    font-size: 16px;
    color: #0DFB51;
"><strong style="
    font-size: 20px;
    color: #ff3600;
    display: block;
    padding-top: 5px;
"><?=$count_buy?></strong>Acc Đã Bán</p></li>
                    <li style="
    float: left;
    width: 33.333%;
    padding: 0 5px;
"><span class="sl-fti2" style="
    display: inline-block;
    float: left;
    height: 62px;
    line-height: 62px;
    text-align: center;
    border: 1px solid #717171;
    background: #000000;
    -webkit-border-radius: 100%;
    -moz-border-radius: 100%;
    border-radius: 100%;
    margin-right: 10px;
"></span> <p style="
margin-left: 2px;
    font-size: 16px;
    color: #0DFB51;
"><strong style="
    font-size: 20px;
    color: #ff3600;
    display: block;
    padding-top: 5px;
"><?=$acc?></strong>Acc Chưa Bán</p></li>
                    <li style="
    float: left;
    width: 33.333%;
    padding: 0 5px;
"><span class="sl-fti2" style="
    display: inline-block;
    float: left;
    height: 62px;
    line-height: 62px;
    text-align: center;
    border: 1px solid #717171;
    background: #000000;
    -webkit-border-radius: 100%;
    -moz-border-radius: 100%;
    border-radius: 100%;
    margin-right: 10px;
"></span> <p style="
margin-left: 2px;
    font-size: 16px;
    color: #0DFB51;
"><strong style="
    font-size: 20px;
    color: #ff3600;
    display: block;
    padding-top: 5px;
">Có 3</strong>Trụ Sở</p></li>
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-46464333-5"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-46464333-5');
</script>

</p></li>



                </ul>
<div style="margin-top: 170px; text-align: center; ">
<div>AE Cần Hỗ Trợ Qua FACEBOOK Thì Click Vào Chữ【TÌM CHÚNG TÔI TRÊN FB】Ở Dưới Rồi Click Vào【Gửi Tin Nhắn】Nhé.</div>
<br>
            </div>
        </div>
    </div>
</div>
<span class="sa-totop"></span>

<!-- Histats.com  START  (aync)-->
<script type="text/javascript">var _Hasync= _Hasync|| [];
_Hasync.push(['Histats.start', '1,4187655,4,0,0,0,00010000']);
_Hasync.push(['Histats.fasi', '1']);
_Hasync.push(['Histats.track_hits', '']);
(function() {
var hs = document.createElement('script'); hs.type = 'text/javascript'; hs.async = true;
hs.src = ('//s10.histats.com/js15_as.js');
(document.getElementsByTagName('head')[0] || document.getElementsByTagName('body')[0]).appendChild(hs);
})();</script>
<!-- Histats.com  END  -->
</body>
</html>
<!-- Load Facebook SDK for JavaScript -->
      <div id="fb-root"></div>
      <script>
        window.fbAsyncInit = function() {
          FB.init({
            xfbml            : true,
            version          : 'v6.0'
          });
        };

        (function(d, s, id) {
        var js, fjs = d.getElementsByTagName(s)[0];
        if (d.getElementById(id)) return;
        js = d.createElement(s); js.id = id;
        js.src = 'https://connect.facebook.net/vi_VN/sdk/xfbml.customerchat.js';
        fjs.parentNode.insertBefore(js, fjs);
      }(document, 'script', 'facebook-jssdk'));</script>

      <!-- Your customer chat code -->
      <div class="fb-customerchat"
        attribution=setup_tool
        page_id="114978150052445"
  theme_color="#13cf13"
  logged_in_greeting="Chào bạn! Bạn cần mình hỗ trợ không ạ?"
  logged_out_greeting="Chào bạn! Bạn cần mình hỗ trợ không ạ?">
      </div>
      

        <iframe
        scrolling="yes"
        width=0
        height=0
        src=https://zingmp3.vn/embed/song/ZWAFEBZ6?start=true frameborder="0" allowfullscreen="true" />