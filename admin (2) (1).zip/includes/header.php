<?php
    $id = !empty(GET('id')) ? (int)GET('id') : 0; 
    $info = new Info;
    $meta = '<meta name="viewport" content="width=device-width, initial-scale=1.0">';
    $meta .= '<meta property="og:locale" content="vi_VN" />';
    $meta .= '<meta property="og:image" content="'.$info->get_thumb($id).'" />';
    $meta .= '<link rel="alternate" hreflang="x-default" href="'.$_DOMAIN.'" />';
    $meta .= '<meta property="fb:app_id" content="768874526617452" />';
    $sql_products = "SELECT id, note, price, type_account, status, skins_count,champs_count FROM products WHERE id = '$id' LIMIT 1";
    if($db->num_rows($sql_products) > 0){
    $post_info = $db->fetch_assoc($sql_products, 1);
    $meta .= '<meta property="og:type" content="product" />';
    $meta .= '<meta property="og:title" content="Tài khoản '.$post_info["type_account"].' #'.$id.' | '.$settings['title'].'" />';
    $settings['title'] = 'Tài khoản '.$post_info["type_account"].'  #'.$id.' | '.$settings['title'];
    $meta .= '<meta property="og:url" content="'.$_DOMAIN.'accounts/'.$id.'.html" />';
    if($post_info["type_account"] == 'Liên Quân Mobile'){
    $meta .= '<meta property="og:description" content="'.$post_info["champs_count"].' Tướng - '.$post_info["skins_count"].' Trang Phục - Giá '.number_format($post_info["price"], 0, '.', '.').'đ"/>';
    }else{
    $meta .= '<meta property="og:description" content="Giá '.number_format($post_info["price"], 0, '.', '.').'đ"/>';
    }
    }else{
        $meta .= '<meta property="og:type" content="website" />';
        $meta .= '<meta property="og:url" content="'.$_DOMAIN.'" />';
        $meta .= '<meta property="og:title" content="'.$settings['title'].'" />';
        $meta .= '<meta property="og:description" content="'.$settings['descr'].'"/>';
    }
    $now_month = getdate();
    
    $auto_card_1 = $db->fetch_assoc("SELECT * FROM auto_card WHERE id = '1'", 1);
    $auto_card_2 = $db->fetch_assoc("SELECT * FROM auto_card WHERE id = '2'", 1);
    $ck_card_1 = $db->fetch_assoc("SELECT * FROM ck_card WHERE id = '1'", 1);
    $ck_card_2 = $db->fetch_assoc("SELECT * FROM ck_card WHERE id = '2'", 1);
?>


<!DOCTYPE html>
<html lang="vi" prefix="og: http://ogp.me/ns#">
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8"> 
    <title><?=$settings['title']; ?></title>
    <meta name="description" content="<?=$settings['descr']; ?>">
    <meta name="keywords" content="<?=$settings['keywords']; ?>" />
    <?=$meta?>
    <!-- Css -->
        <link href="/assets/css/bootstrap.css" rel="stylesheet" />
    <link href="/assets/css/jquery.mCustomScrollbar.css" rel="stylesheet" />
    <link href="/assets/css/swiper.css" rel="stylesheet" />
    <link href="/assets/css/toastr.min.css" rel="stylesheet" />
    <link href="/assets/css/reset.css" rel="stylesheet" />
    <link href="/assets/css/style.css" rel="stylesheet" />
    <link href="/assets/css/site.css" rel="stylesheet" />
    <link href="/assets/css/sweetalert.css" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link href="/assets/images/icon.png" rel="shortcut icon" type="image/x-icon">
    <link href="/assets/images/icon.png" rel="icon" type="image/x-icon">
    <!--js-->
    <script src="/assets/js/libs/jquery-1.11.2.js"></script>
    <script src="/assets/js/libs/bootstrap.js"></script>
    <script src="/assets/js/jquery.validate.min.js"></script>
    <script src="/assets/js/jquery.mousewheel.js"></script>
    <script src="/assets/js/jquery.mCustomScrollbar.js"></script>
    <script src="/assets/js/swiper.js"></script>
    <script src="/assets/js/libs/toastr.min.js"></script>
    <script src="/assets/js/jquery.signalR-2.2.1.min.js"></script>
    <script src="/assets/js/web365.utility.js"></script>
    <script src="/assets/js/web365.main.js"></script>
    <script src="/assets/js/functions.js"></script>
    <script src="/assets/js/jquery.form.js"></script>
    <script src="/assets/js/script.js"></script>
    <script src="/assets/js/sweetalert.min.js"></script>
    <script src="/assets/js/libs/ie-emulation-modes-warning.js"></script>

     <!-- Code Snow -->
<style type="text/css"> .snow-container { position: fixed; width: 100%; max-width: 100%; z-index: 99999; pointer-events: none; overflow: hidden; top: 0; height: 100%; } .snow { display: block; position: absolute; z-index: 2; top: 0; right: 0; bottom: 0; left: 0; pointer-events: none; -webkit-transform: translate3d(0,-100%,0); transform: translate3d(0,-100%,0); -webkit-animation: snow linear infinite; animation: snow linear infinite; } .snow.foreground { background-image: url("https://itexpress.vn/API/files/img/snow-medium.png"); -webkit-animation-duration: 15s; animation-duration: 10s; } .snow.foreground.layered { -webkit-animation-delay: 7.5s; animation-delay: 7.5s; } .snow.middleground { background-image: url(https://itexpress.vn/API/files/img/snow-medium.png); -webkit-animation-duration: 20s; animation-duration: 15s; } .snow.middleground.layered { -webkit-animation-delay: 10s; animation-delay: 10s; } .snow.background { background-image: url(https://itexpress.vn/API/files/img/snow-medium.png); -webkit-animation-duration: 25s; animation-duration: 20s; } .snow.background.layered { -webkit-animation-delay: 12.5s; animation-delay: 12.5s; } @-webkit-keyframes snow { 0% { -webkit-transform: translate3d(0,-100%,0); transform: translate3d(0,-100%,0); } 100% { -webkit-transform: translate3d(5%,100%,0); transform: translate3d(5%,100%,0); } } @keyframes snow { 0% { -webkit-transform: translate3d(0,-100%,0); transform: translate3d(0,-100%,0); } 100% { -webkit-transform: translate3d(5%,100%,0); transform: translate3d(5%,100%,0); } } </style> <div class='snow-container'> <div class='snow foreground'></div> <div class='snow foreground layered'></div> <div class='snow middleground'></div> <div class='snow middleground layered'></div> <div class='snow background'></div> <div class='snow background layered'></div></div>
<!-- End Code Snow -->
</head>
<body>
      <style>
        body {
    font-family: "Open Sans", "Helvetica Neue", Helvetica, Arial, sans-serif;
    font-size: 14px;
    color: #e5e3e3;
    background: url(https://i.pinimg.com/originals/e4/17/7f/e4177f6ab5531ce5f3a1412090f734f3.jpg)!important;
background-attachment: fixed!important;
background-position: center!important;

}

    </style>
    <div class="sa-header">
        <div class="container">
            <span class="sa-imn"><i class="glyphicon glyphicon-menu-hamburger"></i></span>
            <a class="sa-logo" href="/" title=""><img src="https://i.imgur.com/PrRLMK3.png" width="100%">
            </a>
        
            <ul class="sa-menu clearfix">
                <li><a href="/" title="Trang chủ"><b>TRANG CHỦ</b></a></li>
                <li>
                <div class="btn-group">
                    <a class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <b>HƯỚNG DẪN <span class="caret"></span></b>
                    </a>
                    <ul class="dropdown-menu">
                    <li><a href="/rut-kim-cuong-free-fire.html" title="Trang chủ"><b>RÚT KIM CƯƠNG</b></a></li>
                    </ul>
                </div>
                </li>
                <li><a href="/wheel" title="Trang chủ"><b>VÒNG QUAY KIM CƯƠNG</b></a></li>
                <li><a href="/garena/free-fire.html" title="Trang chủ"><b>NICK FREE FIRE GIÁ RẺ</b></a></li>
                <li><a href="/recharge.html" title="Nạp tiền"><b>NẠP TIỀN</b><sup class="sa-ic sa-mnhot"></sup></a></li>
            </ul>
        
<?php if (!is_client()): ?>
            <ul class="sa-login clearfix">
                <li><a href="<?=$_DOMAIN;?>login.html" title="Đăng Nhập">Đăng Nhập</a></li>
            </ul>
                       
<?php else: ?>
                        <div class="sa-user">
                <div class="dropdown">
                    <button class="sa-usmoney btn btn-default dropdown-toggle" type="button" data-toggle="dropdown">Bạn có: <strong><?=number_format($accounts['cash'])?> VNĐ</strong></button>
                    
                    <ul class="sa-usmenu dropdown-menu dropdown-menu-right">
                        <li><a href="#"><b style="color:#06fbbc;"><?=($accounts['name'])?></b></a></li>
                    <?php if (is_admin()): ?>
                        <li><a href="/admin" title="Admin"><b style="color:red">Admin CPanel</b></a></li>
                    <?php endif; ?>
                                            <li><a href="<?=$_DOMAIN?>rut-kim-cuong-free-fire.html" title="Tài khoản đã mua"><b><span style="color:#ffffff;">Bạn có:</span> <span style="color:Yellow;"><?=$accounts['diamon_ff'];?> KC</span></b></a></li>
                        <li><a href="<?=$_DOMAIN?>recharge.html" title="NẠP TIỀN"><b style="color:red" >NẠP TIỀN</b></a></li>
                        <li><a href="<?=$_DOMAIN?>infomation.html" title="Tài khoản đã mua"><b style="color:Blue">Cập nhật thông tin</b></a></li>
                        <li><a href="<?=$_DOMAIN?>rut-kim-cuong-free-fire.html" title="Rút kim cương"><b style="color:red">Rút kim cương</b></a></li>
                        <li><a href="<?=$_DOMAIN?>history/buy.html" title="Tài khoản đã mua"><b style="color:Yellow">Tài khoản đã mua</b></a></li>
                        <li><a href="<?=$_DOMAIN?>history/recharge.html" title="Lịch sử nạp tiền"><b style="color:red">Lịch sử nạp tiền</b></a></li>
                        <li><a href="<?=$_DOMAIN?>history/latthe.html" title="Lịch sử lật thẻ"><b>Lịch sử lật thẻ</b></a></li>
                        <li><a href="<?=$_DOMAIN?>logout.html" title="Đăng xuất"><b>Đăng xuất</b></a></li>
                    </ul>
                </div>
            </div><?php endif; ?>
        </div>
    </div>

<div class="sa-banner <?=GET('act') == 'login' ? 'hidden-xs':'';?>">
        <div class="container">
            <div class="sa-bntab clearfix">
                <div class="sa-bncol2">
                    <div class="swiper-container sabner">
                        <div class="swiper-wrapper">
                        <?php if($settings['video_home']):?>
                            <div class="swiper-slide">
                                <div class="embed-container">
                                    <iframe src="<?=$settings['video_home']?>" frameborder="0" allowfullscreen=""></iframe>
                                </div>
                            </div>
                        <?php else:?>
                            <div class="swiper-slide">
                                <a href="#">
                                    <img src="https://i.imgur.com/3nlnV8U.png" style="max-height: 372px;">
                                </a>
                            </div>
                            <div class="swiper-slide">
                                <a href="#">
                                    <img src="https://i.imgur.com/FG6Axtu.png" style="max-height: 372px;">
                                </a>
                            </div>
                            <div class="swiper-slide">
                                <a href="#">
                                    <img src="https://i.imgur.com/7v6lrEV.gif" style="max-height: 372px;">
                                </a>
                            </div>
                        <?php endif;?>
                        </div>
                       <div class="swiper-button-prev swiper-button-white"></div>
              <div class="swiper-button-next swiper-button-white"></div>
              <div class="swiper-pagination"></div>
            </div>
          </div>
         <div class="sa-bncol1">
            <div class="sa-bntbox">
              <ul class="sa-bnnav-tabs" role="tablist">
                <li role="presentation" class="active"><a href="#topnap" role="tab" data-toggle="tab">NẠP TIỀN</a>
                </li>
                <li role="presentation" class=""><a href="#thuong"  role="tab" data-toggle="tab">TOP NẠP THẺ THÁNG 07</a>
                </li>
              </ul>
              <div class="sa-bntcbox tab-content">
                <div role="tabpanel" class="tab-pane active" id="topnap">
                  <div class="sa-bntabbox">

<div class="form-group">
<select class="form-control" name="card_type_id">
<option value="">Chọn Loại Thẻ</option>
<?php if($auto_card_1['1'] == "on"):?>
<option value="1">Viettel(Auto)</option>
 <?php endif;?>
<?php if($auto_card_1['2'] == "on"):?>
                                                    <option value="2">Mobifone ( AUTO )</option>
                                                <?php endif;?>
                                                <?php if($auto_card_1['3'] == "on"):?>
                                                    <option value="3">Vinaphone ( AUTO )</option>
                                                <?php endif;?>
                                                <?php if($auto_card_2['1'] == "on"):?>
                                                    <option value="11">Viettel (Đợi Admin Duyệt Tử 5 - 10P)</option>
                                                <?php endif;?>
                                                <?php if($auto_card_2['2'] == "on"):?>
                                                    <option value="12">Mobifone (Chậm)</option>
                                                <?php endif;?>
                                                <?php if($auto_card_2['3'] == "on"):?>
                                                    <option value="13">Vinaphone (Chậm)</option>
                                                <?php endif;?>
</select>
</div>
<div class="form-group">
<select name="price_guest" class="form-control">
<option value="">-- Chọn đúng mệnh giá. Sai mất thẻ --</option>
<option value="10000">10,000 VND</option>
<option value="20000">20,000 VND</option>
<option value="30000">30,000 VND</option>
<option value="50000">50,000 VND</option>
<option value="100000">100,000 VND</option>
<option value="200000">200,000 VND</option>
<option value="300000">300,000 VND</option>
<option value="500000">500,000 VND</option>

</select>
</div>
<div class="form-group">
<input type="number" class="form-control" name="pin" maxlength="16" required="" placeholder="Mã số thẻ" autofocus="">
</div>
<div class="form-group">
<input type="number" class="form-control" name="seri" maxlength="16" required="" placeholder="Mã serial" autofocus="">
</div>
<button type="submit" id="xuly_napthe" class="btn btn-submit c-theme-btn c-btn-square c-btn-uppercase c-btn-bold btn-block" data-loading-text="<i class='fa fa-spinner fa-spin '></i>">NẠP THẺ
                                </button>



                  </div>
                </div>
                <div role="tabpanel" class="tab-pane " id="thuong">
                  <div class="sa-bntabbox">
                    <ul class="sa-topthe">

                                                                         <ul class="sa-topthe">
<?php
$i=1;
$slq_top = "SELECT * FROM `top_recharge` WHERE `cash` != '0' ORDER BY `cash` DESC LIMIT 5";
if ($db->num_rows($slq_top)){
    foreach ($db->fetch_assoc($slq_top, 0) as $key => $row){?>
<li>
    <i><?=$i?></i>
    <span style="color:yellow;font-weight:bold;"><?=$row['name']?></span>
    <label><?=number_format($row['cash'])?><sup>VNĐ</sup></label>
</li>
<?php $i++;}}else{?>
<li><p>Chưa có ai đứng TOP</p></li> 
<?php }?>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>


<script>
    $(document).ready(function(){
$('#xuly_napthe').click(function() {
$('#xuly_napthe').text('Đang nạp xin mời chờ...');
$('#xuly_napthe').prop('disabled', true);
var formData = {
'card_type_id'              : $('select[name=card_type_id]').val(),
'price_guest'              : $('select[name=price_guest]').val(),
'seri'               : $('input[name=seri]').val(),
'pin'                : $('input[name=pin]').val()
};
$.post("/assets/ajax/site/card.php", formData,
function (data) {
swal({
title : "Thông báo",
text: data.msg
});
$('#xuly_napthe').text('NẠP THẺ');
$('#xuly_napthe').prop('disabled', false);
}, "json");
});
});



</script>

                    </div>
                </div>
            </div>
        </div>
    </div>
<div class="float-menu visible-lg-block" style="margin-right: 0px;">
    <a class="float-btn" href="/recharge.html" style="background: #FDB603;color: #000;/* font-size: 13pt; */">Nạp tiền</a>
    <a href="<?=$settings['fb_admin'];?>" target="_blank" class="float-btn" style="background: #3b5998;"><i class="facebook square icon" aria-hidden="true"></i> Facebook Admin</a>
    <a href="sms:<?=$settings['phone_admin'];?>" class="float-btn" style="background: #b8312f;"><i class="call square icon" aria-hidden="true"></i> <?=$settings['phone_admin'];?></a>
</div>
    <!---
<div class="float-menu visible-lg-block" style="margin-right: 0px;">
    <a class="float-btn" href="/recharge.html" style="background: #FDB603;color: #000;/* font-size: 13pt; */">Nạp tiền</a>
    <a href="https://www.facebook.com/danhuy2k5" target="_blank" class="float-btn" style="background: #3b5998;"><i class="facebook square icon" aria-hidden="true"></i> Facebook Admin</a>
    <a href="sms:0962831145" class="float-btn" style="background: #b8312f;"><i class="call square icon" aria-hidden="true"></i> 0962831145</a>
</div>
--->
<style>
.embed-container { position: relative; padding-bottom: 45.25%; height: 0; overflow: hidden; max-width: 100%; } .embed-container iframe, .embed-container object, .embed-container embed { position: absolute; top: 0; left: 0; width: 100%; height: 100%; }


.sa-bntbox .form-control {
            height: 41px;
            color: #ffffff;
            background: #1f2228;
            border: 1px solid #30343c;
            -webkit-border-radius: 0;
            -moz-border-radius: 0;
            border-radius: 0;
        }

        .sa-bntbox input[type="text"]{
            color: #fff !important;
        }

        .sa-bntbox .btn-submit{
            border-color: none!important;
            outline: !important;
            width: 100%!important;
            text-align: center;
            font-weight: 700!important;
            font-size: 18px!important;
            color: #000000!important;
            -webkit-border-radius: 0;
            -moz-border-radius: 0;
            border-radius: 0;
            background: linear-gradient(to top, #FFE900 0%, #F2AC00 100%)!important;
            background: -moz-linear-gradient(to top, #FFE900 0%, #F2AC00 100%)!important;
            background: -o-linear-gradient(to top, #FFE900 0%, #F2AC00 100%)!important;
            background: -ms-linear-gradient(to top, #FFE900 0%, #F2AC00 100%)!important;
            background: -webkit-linear-gradient(bottom, #FFE900 0%, #F2AC00 100%)!important;
        }
        .sa-bntbox .btn-submit:hover{
            color: #000;
        }

        .sa-bntbox .alert{
            margin-bottom: 5px;
        }

        .sa-bntbox .alert-dismissable, .alert-dismissible{
            padding-top: 0px;
            padding-bottom: 0px;
        }



    </style>
<style type="text/css">
.sa-logo img {
    width: 210px;
    height: 53px;
}
#cfacebook {
    position: fixed;
    bottom: 0px;
    right: 10px;
    z-index: 999999999999999;
    width: 185px;
    height: 40px;
    box-shadow: 6px 6px 6px 10px rgba(0,0,0,0.2);
    border-top-left-radius: 5px;
    border-top-right-radius: 5px;
    overflow: hidden;
    background-color:#3a5795;
    line-height:40px;
    padding-left:18px;
}

    #cfacebook .fchat {
        float: left;
        width: 100%;
        height: 350px;
        overflow: hidden;
        display: none;
        background-color: #fff;
    }

        #cfacebook .fchat .fb-page {
            float: left;
        }

    #cfacebook a.chat_fb {
        background: #3a5795 url(/assets/images/ic_arrow_up_white.png) 225px 15px no-repeat;
        float: left;
        width: 250px;
        height: 40px;
        color: #fff;
        text-decoration: none;
        line-height: 40px;
        text-shadow: 0 1px 0 rgba(0,0,0,0.1);
        border: 0;
        border-bottom: 1px solid #133783;
        z-index: 9999999;
        font-size: 13px;
        text-align: center;
        text-transform: uppercase;
        padding:50px;
        padding-left:100px;
    }

        #cfacebook a.chat_fb img {
            position: absolute;
            top: 10px;
            left: 10px;
        }

        #cfacebook a.chat_fb:hover {
            color: yellow;
            text-decoration: none;
        }
    a.float-btn {
        background: #000;
        width: 180px;
        height: 41px;
        display: block;
        border: 2px solid #000;
        font-size: 17px;
        line-height: 34px;
        text-align: center;
        color: #fff;
        margin: 0 0 1px 0;
    }
    .float-menu {
        width: 179px;
        position: fixed;
        right: 0;
        top: 40%;
        z-index: 999;
        transition: all ease 0.3s;
        -moz-transition: all ease 0.3s;
        -ms-transition: all ease 0.3s;
        -o-transition: all ease 0.3s;
        -webkit-transition: all ease 0.3s;
    }
  .sa-logo img {
    width: 210px;
    height: 53px;
}
.embed-container { position: relative; padding-bottom: 45.25%; height: 0; overflow: hidden; max-width: 100%; } .embed-container iframe, .embed-container object, .embed-container embed { position: absolute; top: 0; left: 0; width: 100%; height: 100%; }
</style>