<link rel="stylesheet" type="text/css" href="/assets/css/custom.css">
<?php if($settings['notify']):?>
<script type="text/javascript">
               swal({   
                        title: "Thông báo",
                            html: true,
                            text: "<?=$settings['notify'];?>",   
                            showConfirmButton:true
        
                     }, function() {
                         
                         
                        });
</script>
<?php endif;?>
<?php
/*
╔═════════════════════════════════════════════╗
║     Design by Youtuber THI FF VLOG          ║
║      Facebook: facebook.com/ytbThiFF        ║
║   Hotline: 0369.056.756 - 0359.283.357      ║
╚═════════════════════════════════════════════╝
*/
$count_products = $db->fetch_row("SELECT COUNT(*) FROM `products` WHERE `status` = '0' AND `type_account` = 'ZingSpeed Mobile'");
$count_products_buy = $db->fetch_row("SELECT COUNT(*) FROM `products` WHERE `status` != '0' AND `type_account` = ZingSpeed Mobile'")+5;
$count_products_ff = $db->fetch_row("SELECT COUNT(*) FROM `products` WHERE `status` = '0' AND `type_account` = 'Free Fire'");
$count_products_ff_buy = $db->fetch_row("SELECT COUNT(*) FROM `products` WHERE `status` != '0' AND `type_account` = 'Free Fire'")+9;
$count_products_pubg = $db->fetch_row("SELECT COUNT(*) FROM `products` WHERE `status` = '0' AND `type_account` = 'PUBG Mobile'");
$count_products_pubg_buy = $db->fetch_row("SELECT COUNT(*) FROM `products` WHERE `status` != '0' AND `type_account` = 'PUBG Mobile'");
$count_rd_1 = $db->fetch_row("SELECT COUNT(*) FROM `acc_random` WHERE `status` = '0' AND `type` = '1'");
$count_rd_1_buy = $db->fetch_row("SELECT COUNT(*) FROM `acc_random` WHERE `status` != '0' AND `type` = '1'")+628;
$count_rd_2 = $db->fetch_row("SELECT COUNT(*) FROM `acc_random` WHERE `status` = '0' AND `type` = '2'");
$count_rd_2_buy= $db->fetch_row("SELECT COUNT(*) FROM `acc_random` WHERE `status` != '0' AND `type` = '2'")+568;
$count_rd_3 = $db->fetch_row("SELECT COUNT(*) FROM `acc_random` WHERE `status` = '0' AND `type` = '3'");
$count_rd_3_buy= $db->fetch_row("SELECT COUNT(*) FROM `acc_random` WHERE `status` != '0' AND `type` = '3'")+407;
$count_rd_4 = $db->fetch_row("SELECT COUNT(*) FROM `acc_random` WHERE `status` = '0' AND `type` = '4'");
$count_rd_4_buy= $db->fetch_row("SELECT COUNT(*) FROM `acc_random` WHERE `status` != '0' AND `type` = '4'")+291;
$count_rd_5 = $db->fetch_row("SELECT COUNT(*) FROM `acc_random` WHERE `status` = '0' AND `type` = '5'");
$count_rd_5_buy= $db->fetch_row("SELECT COUNT(*) FROM `acc_random` WHERE `status` != '0' AND `type` = '5'")+234;
$count_rd_6 = $db->fetch_row("SELECT COUNT(*) FROM `acc_random` WHERE `status` = '0' AND `type` = '6'");
$count_rd_6_buy= $db->fetch_row("SELECT COUNT(*) FROM `acc_random` WHERE `status` != '0' AND `type` = '6'")+891;
$count_rd_7 = $db->fetch_row("SELECT COUNT(*) FROM `acc_random` WHERE `status` = '0' AND `type` = '7'");
$count_rd_7_buy= $db->fetch_row("SELECT COUNT(*) FROM `acc_random` WHERE `status` != '0' AND `type` = '7'")+772;
$count_rd_8 = $db->fetch_row("SELECT COUNT(*) FROM `acc_random` WHERE `status` = '0' AND `type` = '8'");
$count_rd_8_buy= $db->fetch_row("SELECT COUNT(*) FROM `acc_random` WHERE `status` != '0' AND `type` = '8'")+515;
$count_rd_9 = $db->fetch_row("SELECT COUNT(*) FROM `acc_random` WHERE `status` = '0' AND `type` = '9'");
$count_rd_9_buy= $db->fetch_row("SELECT COUNT(*) FROM `acc_random` WHERE `status` != '0' AND `type` = '9'")+472;
$count_rd_10 = $db->fetch_row("SELECT COUNT(*) FROM `acc_random` WHERE `status` = '0' AND `type` = '10'");
$count_rd_10_buy= $db->fetch_row("SELECT COUNT(*) FROM `acc_random` WHERE `status` != '0' AND `type` = '10'")+345;
$count_rd_11 = $db->fetch_row("SELECT COUNT(*) FROM `acc_random` WHERE `status` = '0' AND `type` = '11'");
$count_rd_11_buy= $db->fetch_row("SELECT COUNT(*) FROM `acc_random` WHERE `status` != '0' AND `type` = '11'")+521;
$count_rd_12 = $db->fetch_row("SELECT COUNT(*) FROM `acc_random` WHERE `status` = '0' AND `type` = '12'");
$count_rd_12_buy= $db->fetch_row("SELECT COUNT(*) FROM `acc_random` WHERE `status` != '0' AND `type` = '12'")+224;
$count_rd_13 = $db->fetch_row("SELECT COUNT(*) FROM `acc_random` WHERE `status` = '0' AND `type` = '13'");
$count_rd_13_buy= $db->fetch_row("SELECT COUNT(*) FROM `acc_random` WHERE `status` != '0' AND `type` = '13'");
$count_rd_14 = $db->fetch_row("SELECT COUNT(*) FROM `acc_random` WHERE `status` = '0' AND `type` = '14'");
$count_rd_14_buy= $db->fetch_row("SELECT COUNT(*) FROM `acc_random` WHERE `status` != '0' AND `type` = '14'");
$count_rd_15 = $db->fetch_row("SELECT COUNT(*) FROM `acc_random` WHERE `status` = '0' AND `type` = '15'");
$count_rd_15_buy= $db->fetch_row("SELECT COUNT(*) FROM `acc_random` WHERE `status` != '0' AND `type` = '15'");
$count_wheel = $db->fetch_row("SELECT COUNT(*) FROM `history_wheel`")+162;
$count_latthe = $db->fetch_row("SELECT COUNT(*) FROM `HK_lattheff`");
?>
<div class="sl-search">
    <div class="container">
        <div class="sa-mainsa">
    <div class="container">
   
            <div class="sl-row clearfix">
                <div class="box-title-menu-game">
                    <center><img src="https://i.imgur.com/zUbUoQU.png"><center>
                   
            </div>
        </div>

    <marquee scrollamount="5" style="padding-top: 8px;padding-bottom: 4px;"><img width="36" height="36" src="/assets/images/run.gif" longdesc="36">
    <span class="text-success">Chào Mừng Bạn Tới Shop Chính Thức Của chúng tôi Giao Dịch Hoàn Toàn Tự Động Lớn Nhất Việt Nam-Uy Tín-An Toàn-Tiện Lợi-Acc Đa Dạng-Nạp Tiền Nhiều Hình Thức...</span></marquee>
 
     

        <div class="sl-sebox">
            <div class="sl-row clearfix">
                <div class="sl-col col-md-12 col-xs-12">
                    <h1 class="sl-htit text-center" style="font-size: 29px;"><u>DANH MỤC FREE FIRE</h1>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="sl-lprod">
    <div class="container">
        <div class="sllpbox">
            <div class="sl-produl clearfix">
                
                
                    <div class="sl-prodli">
                        <div class="sl-prodbox">
                            <a class="sl-prlinks" href="/wheel" title="Tài Khoản Free Fire">
                                 <div class="ribbon-vip"><span>SALE 30%</span></div>
                                
                                <p class="sl-primg"><img src="/assets/images/VQ-KC.gif" alt="Trắng TT - Đảm Đảm - Uy Tín"></p>
                            </a>
                            <div class="sl-prifs">
                                <div class="sl-prifbot">
                                    <b style="color:Orange;">VÒNG QUAY KIM CƯƠNG</b></a></li><b style="color:RED;"></span></h3>
                                   
                                    <ul>
                                 
                                       <li>Lượt quay: <?=number_format($count_wheel);?></li>
                                        <li>Tỉ lệ trúng 11000 kc cực cao</li>
                                    </ul>
                                </div>

                                <p class="sl-prbot"><a href="/wheel" title="XEM TẤT CẢ" class="sl-btnod">QUAY NGAY</a></p>
                            </div>
                        </div>
                        </div>
 
         <div class="sl-prodli">
                        <div class="sl-prodbox">
                            <a class="sl-prlinks" href="/garena/random-kim-cuong-ff-cao-cap.html" title="THỬ VẬN MAY KIM CƯƠNG">
                                <div class="ribbon-vip"><span>SALE 30%</span></div>
                             
                                <p class="sl-primg"><img src="https://i.imgur.com/ka4P1k5.gif" alt="Thử vận may"></p>
                            </a>
                            <div class="sl-prifs">
                                <div class="sl-prifbot">
                                    <b style="color:Orange;">Máy Hút Kim Cương</b></a></li><b style="color:RED;"> <?=number_format($settings['rd_11']);?> VNĐ</span></h3>
                                   
                                    <ul>
                                 
                                       <li>Kim Cương Đã Hút: <?=number_format($count_rd_11);?></li>
                                        <li>Kim Cương Chưa Hút:<?=number_format($count_rd_11_buy);?></li>
                                    </ul>
                                </div>

                                <p class="sl-prbot"><a href="/garena/random-kim-cuong-ff-cao-cap.html" title="XEM TẤT CẢ" class="sl-btnod">XEM TẤT CẢ</a></p>
                            </div>
                        </div>
                    </div> 
                    <div class="sl-prodli">
                        <div class="sl-prodbox">
                            <a class="sl-prlinks" href="/garena/random-kim-cuong-ff.html" title="THỬ VẬN MAY KIM CƯƠNG">
                                  <div class="ribbon-vip"><span>SALE 30%</span></div>
                          
                                <p class="sl-primg"><img src="https://shopnhangaming.com/assets/images/thumb/thiblue-10.jpg" alt="Thử vận may"></p>
                            </a>
                             <div class="sl-prifs">
                                <div class="sl-prifbot">
                                    <b style="color:Orange;">MỞ HÒM KIM CƯƠNG</b></a></li><b style="color:RED;"> <?=number_format($settings['rd_10']);?> VNĐ</span></h3>
                                   
                                    <ul>
                                 
                                       <li> Hòm Chưa Bán: <?=number_format($count_rd_10);?></li>
                                        <li>Tài Khoản Chưa Bán:<?=number_format($count_rd_10_buy);?></li>
                                    </ul>
                                </div>

                                <p class="sl-prbot"><a href="/garena/random-kim-cuong-ff.html" title="XEM TẤT CẢ" class="sl-btnod">XEM TẤT CẢ</a></p>
                            </div>
                        </div>
                    </div>
                    
                    
                    <div class="sl-prodli">
                        <div class="sl-prodbox">
                            <a class="sl-prlinks" href="/lat-the" title="LẬT HÌNH 10K">
                          
                                <p class="sl-primg"><img src="https://accgame24h.vn/10.png" alt="Lật Hình 10K"></p>
                            </a>
                             <div class="sl-prifs">
                                <div class="sl-prifbot">
                                    <b style="color:Orange;">Lật Hình KC FF </b></a></li><b style="color:RED;"> 10.000VNĐ</span></h3>
                                   
                                    <ul>
                                 
                                       <li>Lượt lật: <?=number_format($count_latthe);?></li>
                                    </ul>
                                </div>

                                <p class="sl-prbot"><a href="/lat-the" title="LẬT NGAY" class="sl-btnod">LẬT NGAY</a></p>
                            </div>
                        </div>
                    </div>
                    
                  
                    <div class="sl-prodli">
                        <div class="sl-prodbox">
                            <a class="sl-prlinks" href="garena/free-fire.html" title="Tài Khoản Free Fire">
                                  <div class="ribbon-vip"><span>SALE 30%</span></div>
                               
                                <p class="sl-primg"><img src="https://i.imgur.com/PMjKB2s.gif" alt="Trắng TT - Đảm Đảm - Uy Tín"></p>
                            </a>
                           <div class="sl-prifs">
                                <div class="sl-prifbot">
                                    <b style="color:Orange;">TÀI KHOẢN FREE FIRE</b></a></li><b style="color:RED;"></span></h3>
                                   
                                    <ul>
                                 
                                       <li>Tài Khoản Chưa Bán: <?=number_format($count_products_ff);?></li>
                                        <li>Tài Khoản Chưa Bán:<?=number_format($count_products_ff_buy);?></li>
                                    </ul>
                                </div>

                                <p class="sl-prbot"><a href="garena/free-fire.html" title="XEM TẤT CẢ" class="sl-btnod">XEM TẤT CẢ</a></p>
                            </div>
                        </div>
                    </div>
                    
                    <div class="sl-prodli">
                        <div class="sl-prodbox">
                            <a class="sl-prlinks" href="/garena/random-free-fire.html" title="THỬ VẬN MAY">
                                  <div class="ribbon-vip"><span>SALE 30%</span></div>
                              
                                <p class="sl-primg"><img src="/assets/images/thumb/random-6.jpg" alt="Thử vận may"></p>
                            </a>
                            <div class="sl-prifs">
                                <div class="sl-prifbot">
                                    <b style="color:Orange;">THỬ VẬN MAY FREE FIRE</b></a></li><b style="color:RED;"> <?=number_format($settings['rd_6']);?> VNĐ</span></h3>
                                   
                                    <ul>
                                 
                                       <li>Chưa Bán: <?=number_format($count_rd_6);?></li>
                                        <li>Chưa Bán:<?=number_format($count_rd_6_buy);?></li>
                                    </ul>
                                </div>

                                <p class="sl-prbot"><a href="/garena/random-free-fire.html" title="XEM TẤT CẢ" class="sl-btnod">XEM TẤT CẢ</a></p>
                            </div>
                        </div>
                    </div>
                   
                   
                    <div class="sl-prodli">
                        <div class="sl-prodbox">
                            <a class="sl-prlinks" href="/garena/random-free-fire-vip.html" title="THỬ VẬN MAY">
                                  <div class="ribbon-vip"><span>SALE 30%</span></div>
                              
                                <p class="sl-primg"><img src="/assets/images/thumb/random-7.jpg" alt="Thử vận may"></p>
                            </a>
                             <div class="sl-prifs">
                                <div class="sl-prifbot">
                                    <b style="color:Orange;">THỬ VẬN MAY FREE FIRE</b></a></li><b style="color:RED;"> <?=number_format($settings['rd_7']);?> VNĐ</span></h3>
                                   
                                    <ul>
                                 
                                       <li>Chưa Bán: <?=number_format($count_rd_7);?></li>
                                        <li>Chưa Bán:<?=number_format($count_rd_7_buy);?></li>
                                    </ul>
                                </div>

                                <p class="sl-prbot"><a href="/garena/random-free-fire-vip.html" title="XEM TẤT CẢ" class="sl-btnod">XEM TẤT CẢ</a></p>
                            </div>
                        </div>
                    </div>
                    <div class="sl-prodli">
                        <div class="sl-prodbox">
                            <a class="sl-prlinks" href="/garena/random-free-fire-sieu-vip.html" title="THỬ VẬN MAY">
                                  <div class="ribbon-vip"><span>SALE 30%</span></div>
                              
                                <p class="sl-primg"><img src="/assets/images/thumb/random-8.jpg" alt="Thử vận may"></p>
                            </a>
                             <div class="sl-prifs">
                                <div class="sl-prifbot">
                                    <b style="color:Orange;">THỬ VẬN MAY FREE FIRE</b></a></li><b style="color:RED;"> <?=number_format($settings['rd_8']);?> VNĐ</span></h3>
                                   
                                    <ul>
                                 
                                       <li>Chưa Bán: <?=number_format($count_rd_8);?></li>
                                        <li>Chưa Bán:<?=number_format($count_rd_8_buy);?></li>
                                    </ul>
                                </div>

                                <p class="sl-prbot"><a href="/garena/random-free-fire-sieu-vip.html" title="XEM TẤT CẢ" class="sl-btnod">XEM TẤT CẢ</a></p>
                            </div>
                        </div>
                    </div>
                    
                               <div class="sl-prodli">
                        <div class="sl-prodbox">
                            <a class="sl-prlinks" href="/garena/random-free-fire-sieu-vip-2.html" title="THỬ VẬN MAY">
                                  <div class="ribbon-vip"><span>SALE 30%</span></div>
                                
                                <p class="sl-primg"><img src="/assets/images/thumb/random-9.jpg" alt="Thử vận may"></p>
                            </a>
                           <div class="sl-prifs">
                                <div class="sl-prifbot">
                                    <b style="color:Orange;">THỬ VẬN MAY FREE FIRE</b></a></li><b style="color:RED;"> <?=number_format($settings['rd_9']);?> VNĐ</span></h3>
                                   
                                    <ul>
                                 
                                       <li>Chưa Bán: <?=number_format($count_rd_9);?></li>
                                        <li>Chưa Bán:<?=number_format($count_rd_9_buy);?></li>
                                    </ul>
                                </div>

                                <p class="sl-prbot"><a href="/garena/random-free-fire-sieu-vip-2.html" title="XEM TẤT CẢ" class="sl-btnod">XEM TẤT CẢ</a></p>
                            </div>
                        </div>
                    </div>
                    
                     
                    
                    
                   
            </div>
        </div>
    </div>
</div>
<br>
<div class="sl-search">
    <div class="container">
        <div class="sl-sebox">
            <div class="sl-row clearfix">
                <div class="sl-col col-md-12 col-xs-12">
                    <h1 class="sl-htit text-center" style="font-size: 29px;"><u>GAME ZINGSPEED MOBILE</h1>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="sl-lprod">
    <div class="container">
        <div class="sllpbox">
            <div class="sl-produl clearfix">
                <div class="sl-prodli">
                        <div class="sl-prodbox">
                                <p class="sl-primg"><img src="https://i.imgur.com/qPYkwvC.jpg" alt="Trắng TT - Đảm Đảm - Uy Tín"></p>
                            </a>
                             <div class="sl-prifs">
                                <div class="sl-prifbot">
                                    <b style="color:Orange;">TÀI KHOẢN ZSM</b></span></h3>
                                   
                                    <ul>
                                   <li>Chưa Bán: <?=number_format($count_products);?></li>
                                        <li>Đã Bán: <?=number_format($count_products_buy);?></li>
                                    </ul>
                                </div>
                           

                                <p class="sl-prbot"><a href="tencent/zing-speed-mobile.html" title="XEM TẤT CẢ" class="sl-btnod">XEM TẤT CẢ</a></p>
                            </div>
                        </div>
                    </div>
                    
                    <div class="sl-prodli">
                        <div class="sl-prodbox">
                            <a class="sl-prlinks" href="/random-zsm-50k.html" title="THỬ VẬN MAY RANDOM 9K">
                                  <div class="ribbon-vip"><span>SALE 30%</span></div>
                               
                                <p class="sl-primg"><img src="https://i.imgur.com/MV4JF1B.png" alt="Thử vận may 9.000đ"></p>
                            </a>
                           
                        <div class="sl-prifs">
                                <div class="sl-prifbot">
                                    <b style="color:Orange;">THỬ VẬN MAY ZSM </b></a></li><b style="color:RED;"> <?=number_format($settings['rd_1']);?> VNĐ</span></h3>
                                   
                                    <ul>
                                        <li>Chưa Bán: <?=number_format($count_rd_1);?></li>
                                        <li>Đã Bán: <?=number_format($count_rd_1_buy);?></li>
                                    </ul>
                                </div>

                                <p class="sl-prbot"><a href="/random-zsm-50k.html" title="XEM TẤT CẢ" class="sl-btnod">XEM TẤT CẢ</a></p>
                            </div>
                        </div>
                    </div>
                     
                     <div class="sl-prodli">
                        <div class="sl-prodbox">
                            <a class="sl-prlinks" href="/random-zsm-100k.html" title="THỬ VẬN MAY RANDOM TRUNG CẤP 30k">
                                  <div class="ribbon-vip"><span>SALE 30%</span></div>
                               
                                <p class="sl-primg"><img src="https://i.imgur.com/1LopjjI.png" alt="Thử vận may 25.000đ"></p>
                            </a>
                             
                        <div class="sl-prifs">
                                <div class="sl-prifbot">
                                    <b style="color:Orange;">THỬ VẬN MAY ZSM </b></a></li><b style="color:RED;"> <?=number_format($settings['rd_2']);?> VNĐ</span></h3>
                                   
                                    <ul>
                                        <li>Chưa Bán: <?=number_format($count_rd_2);?></li>
                                        <li>Đã Bán: <?=number_format($count_rd_2_buy);?></li>
                                    </ul>
                                </div>

                                <p class="sl-prbot"><a href="/random-zsm-100k.html" title="XEM TẤT CẢ" class="sl-btnod">XEM TẤT CẢ</a></p>
                            </div>
                        </div>
                    </div>

                    
                    
                    <div class="sl-prodli">
                        <div class="sl-prodbox">
                            <a class="sl-prlinks" href="/random-zsm-200k.htmll" title="THỬ VẬN MAY RANDOM CAO CẤP 50.000 VNĐ">
                                  <div class="ribbon-vip"><span>SALE 30%</span></div>
                              
                                <p class="sl-primg"><img src="https://i.imgur.com/wiaZVPD.png" alt="Thử vận may 50.000đ"></p>
                            </a>
                               
                        <div class="sl-prifs">
                                <div class="sl-prifbot">
                                    <b style="color:Orange;">THỬ VẬN MAY ZSM </b></a></li><b style="color:RED;"> <?=number_format($settings['rd_3']);?> VNĐ</span></h3>
                                   
                                    <ul>
                                        <li>Chưa Bán: <?=number_format($count_rd_3);?></li>
                                        <li>Đã Bán: <?=number_format($count_rd_3_buy);?></li>
                                    </ul>
                                </div>

                                <p class="sl-prbot"><a href="/random-zsm-200k.html" title="XEM TẤT CẢ" class="sl-btnod">XEM TẤT CẢ</a></p>
                            </div>
                        </div>
                    </div>

                    <div class="sl-prodli">
                        <div class="sl-prodbox">
                            <a class="sl-prlinks" href="/random-zsm-300k.html" title="THỬ VẬN MAY RANDOM SIÊU CẤP 100.000 VNĐ">
                                  <div class="ribbon-vip"><span>SALE 30%</span></div>
                               
                                <p class="sl-primg"><img src="https://i.imgur.com/fYJvmbj.png" alt="Thử vận may 100.000đ"></p>
                            </a>
                               
                        <div class="sl-prifs">
                                <div class="sl-prifbot">
                                    <b style="color:Orange;">THỬ VẬN MAY ZSM </b></a></li><b style="color:RED;"> <?=number_format($settings['rd_4']);?> VNĐ</span></h3>
                                   
                                    <ul>
                                       <li>Chưa Bán: <?=number_format($count_rd_4);?></li>
                                        <li>Đã Bán: <?=number_format($count_rd_4_buy);?></li>
                                    </ul>
                                </div>

                                <p class="sl-prbot"><a href="/random-zsm-300k.html" title="XEM TẤT CẢ" class="sl-btnod">XEM TẤT CẢ</a></p>
                            </div>
                        </div>
                    </div>
                    <div class="sl-prodli">
                        <div class="sl-prodbox">
                            <a class="sl-prlinks" href="/random-zsm-500k.html" title="THỬ VẬN MAY RANDOM SIÊU CẤP 200.000 VNĐ">
                                  <div class="ribbon-vip"><span>SALE 30%</span></div>
                                
                                <p class="sl-primg"><img src="https://i.imgur.com/Gr4vw2V.jpg" alt="Thử vận may"></p>
                            </a>
                               
                        <div class="sl-prifs">
                                <div class="sl-prifbot">
                                    <b style="color:Orange;">THỬ VẬN MAY ZSM </b></a></li><b style="color:RED;"> <?=number_format($settings['rd_5']);?> VNĐ</span></h3>
                                   
                                    <ul>
                                       <li>Chưa Bán: <?=number_format($count_rd_5);?></li>
                                        <li>Đã Bán: <?=number_format($count_rd_5_buy);?></li>
                                    </ul>
                                </div>

                                <p class="sl-prbot"><a href="/random-zsm-500k.html" title="XEM TẤT CẢ" class="sl-btnod">XEM TẤT CẢ</a></p>
                            </div>
                        </div>
                    </div>
              
             <!-- 
              <div class="sl-prodli">
                        <div class="sl-prodbox">
                            <a class="sl-prlinks" href="https://quay.ngaogamingshop.com/" title="Tài Khoản Free Fire">
                                <h3 class="sl-prcode text-center"><span>VÒNG QUAY KIM CƯƠNG</span></h3>
                                <p class="sl-primg"><img src="/assets/images/vongquay.jpg" alt="Trắng TT - Đảm Đảm - Uy Tín"></p>
                            </a>
                            <div class="sl-prifs">
                                <div class="sl-prifbot">
                                    <ul>
                                        <li>Lượt quay: <?=number_format($count_wheel1);?></li>
                                        <li>Tỷ lệ trúng cực cao</li>
                                    </ul>
                                </div>

                                <p class="sl-prbot"><a href="https://quay.hoangzinshop.com/" title="XEM TẤT CẢ" class="sl-btnod">QUAY NGAY</a></p>
                            </div>
                        </div>
                    </div>
                                -->
                                        
            </div>
            
        </div>
    </div>
</div>


<div class="container" style="margin-top: 15px;">
    <link rel="stylesheet" href="/assets/css/luauytin-ahihi.css">
    <div class="fan">
        <div class="col-md-6 features">
            <h3>DỊCH VỤ CỦA CHÚNG TÔI</h3>
            <div class="support">
                <div class="col-md-2 ficon hvr-rectangle-out">
                    <i class="fa fa-user " aria-hidden="true"></i>
                </div>
                <div class="col-md-10 ftext">
                    <h4>Tự động giao dịch</h4>
                    <p>Thanh toán tự động 24/7 bằng cách nạp tiền mua acc.</p>
                </div>
                <div class="clearfix"></div>
            </div>
            <div class="shipping">
                <div class="col-md-2 ficon hvr-rectangle-out">
                    <i class="fa fa-bus" aria-hidden="true"></i>
                </div>
                <div class="col-md-10 ftext">
                    <h4>Giao dịch an toàn</h4>
                    <p>Có thể giao dịch thủ công thông qua các thông tin trong phần liên hệ.</p>
                </div>  
                <div class="clearfix"></div>
            </div>
            <div class="money-back">
                <div class="col-md-2 ficon hvr-rectangle-out">
                    <i class="fa fa-money" aria-hidden="true"></i>
                </div>
                <div class="col-md-10 ftext">
                    <h4>Uy tín hàng đầu</h4>
                    <p>Cam kết tất cả tài khoản trên website đều đúng như thông tin và hình ảnh trên web.</p>
                </div>  
                <div class="clearfix"></div>                
            </div>
        </div>
        <div class="col-md-6 testimonials">
            <div class="test-inner">
                <div class="wmuSlider example1 animated wow slideInUp" data-wow-delay=".5s" style="height: 291px;">
                    <div class="wmuSliderWrapper">
                        <article style="position: absolute; width: 100%; opacity: 0;"> 
                            <div class="banner-wrap">
                                <img src="/assets/images/HuyChannel.png" alt=" " class="img-responsive">
                                <p>Shop bán acc liên quân rẻ nhất mà tôi từng gặp. Có dịp tôi sẽ ủng hộ tiếp!</p>
                                <h4># Huy Channel</h4>
                            </div>
                        </article>
                        <article style="position: relative; width: 100%; opacity: 1;"> 
                            <div class="banner-wrap">
                                <img src="/assets/images/kinas.png" alt=" " class="img-responsive">
                                <p>Chủ shop nhiệt tình, chất lượng trên cả tuyệt vời. Đây đúng là shop acc số 1 Việt Nam!</p>
                                <h4># As Mobile</h4>
                            </div>
                        </article>
                        <article style="position: absolute; width: 100%; opacity: 0;">
                            <div class="banner-wrap">
                                <img src="/assets/images/hhcc.png" alt=" " class="img-responsive">
                                <p>Mua acc ở đây tôi không có gì phàn nàn, giá quá rẻ mà acc lại quá ngon! Sẽ tiếp tục ủng hộ nếu có cơ hội.</p>
                                <h4># Gil Gaming</h4>
                            </div>
                        </article>
                    </div>
                </div>
            </div>
        </div>
        <div class="clearfix"></div>
    </div>
                <script src="/assets/js/jquery.wmuSlider.js"></script> 
                                <script>
                                    $('.example1').wmuSlider();         
                                </script> 
</div>