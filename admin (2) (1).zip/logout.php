<?php
/*
╔═════════════════════════════════════════════╗
║     Design by Lua Uy Tin                    ║
║      Facebook: facebook.com/luauytin        ║
║   Hotline: 0369.056.756 - 0359.283.357      ║
╚═════════════════════════════════════════════╝
*/
 
// Require database & thông tin chung
require_once 'core/init.php';
 
// Xoá session
$session->destroy();
new Redirect($_DOMAIN); // Trở về trang index
 
?>