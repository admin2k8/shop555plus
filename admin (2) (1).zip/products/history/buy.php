   <div class="sa-mainsa">
    <div class="container">
        <div class="sa-lprod">
            <div class="sa-lpmain">
                <div class="sa-lsnmain clearfix">
                    <h1 class="sa-ls-tit">Tài khoản đã mua</h1>
                    <div class="sa-ls-table table-responsive">
                <?php if(is_client() && $accounts['diamon_ff'] > 0):?>
                    <h1 style="font-size: 20px;color: #e3d40c;margin-bottom: 10px;">Bạn đã tích lũy được <span style="color:#ff62dc;"><?=$accounts['diamon_ff'];?></span> kim cương Free Fire (<a href="/rut-kim-cuong-free-fire.html">rút về luôn</a>)</h1>
                <?php endif;?>
                        <table class="table">
                            <thead>
                                <tr>
                                    <td>ID ACC</td>
                                    <td>Loại</td>
                                    <td>Tài khoản</td>
                                    <td>Mật khẩu</td>
                                    <td>Giá</td>
                                    <td>Ngày mua</td>
                                </tr>
                            </thead>
                            <tbody class="list"></tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script>
    page = 1;
           function load_page(){
                $.post("/assets/ajax/pages/history_buy.php", { page : page })
                .done(function(data) {
                    $(".list").html('');
                    $('.list').empty().append(data);
                    $(".list").show();   
                }); 
            }
            function search(){
                id = $("#id").val();
                load_page();                                                                                                                                          
            }
load_page();
</script>