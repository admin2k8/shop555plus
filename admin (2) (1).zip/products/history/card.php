   <div class="sa-mainsa">
    <div class="container">
        <div class="sa-lprod">
            <div class="sa-lpmain">
                <div class="sa-lsnmain clearfix">
                    <h1 class="sa-ls-tit">Lịch sử nạp thẻ</h1>
                    <div class="sa-ls-table table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <td>Mã GD</td>
                                    <td>Loại thẻ</td>
                                    <td>Serial</td>
                                    <td>Mã thẻ</td>
                                    <td>Thực nhận</td>
                                    <td>Trạng thái</td>
                                    <td>Ngày nạp</td>
                                </tr>
                            </thead>
                            <tbody class="list"></tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script>
    page = 1;
           function load_page(){
                $.post("/assets/ajax/pages/history_card.php", { page : page })
                .done(function(data) {
                    $(".list").html('');
                    $('.list').empty().append(data);
                    $(".list").show();   
                }); 
            }
            function search(){
                id = $("#id").val();
                load_page();                                                                                                                                          
            }
load_page();
</script>