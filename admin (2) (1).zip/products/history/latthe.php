   <div class="sa-mainsa">
    <div class="container">
        <div class="sa-lprod">
            <div class="sa-lpmain">
                <div class="sa-lsnmain clearfix">
                    <h1 class="sa-ls-tit">Lịch sử lật thẻ</h1>
                    <div class="sa-ls-table table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <td>Id</td>
                                    <td>Kim cương nhận</td>
                                    <td>Thời gian</td>
                                </tr>
                            </thead>
                            <tbody class="list"></tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script>
    page = 1;
           function load_page(){
                $.post("/assets/ajax/pages/history_latthe.php", { page : page })
                .done(function(data) {
                    $(".list").html('');
                    $('.list').empty().append(data);
                    $(".list").show();   
                }); 
            }
            function search(){
                id = $("#id").val();
                load_page();                                                                                                                                          
            }
load_page();
</script>