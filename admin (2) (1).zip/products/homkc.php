<div class="c-layout-page">
	<!-- BEGIN: PAGE CONTENT -->
    <div class="container">
        <div class="row">
            <div class="col-sm-12">
                <div class="alert alert-info" role="alert">
                     <h2 class="alert-heading">Mở Rương Kim Cương</h2>
                    <p><p>H&ograve;m Kim Cương<br />
100% Nhận Được Kim Cương</p>

<p>10% Acc Free Fire V&iacute;p<br />
30% Nhận G&oacute;i Nạp 2000 Kim Cương<br />
20% Nhận Gọi Nạp 3500 Kim Cương<br />
40% Nhận G&oacute;i Nạp Kim Cương Bất Kỳ</p>

<p>L&uacute;c R&uacute;t Kim Cương H&ecirc;n Xui Bạn Sẽ Nhận Ngẫu Nhi&ecirc;n Th&ecirc;m Kim Cương &lt;3</p></p>                </div>
            </div>
        </div>

<div class="container">
    <div class="row">
        <div class="m-l-10 m-r-10">
              <form class="form-inline m-b-10" role="form" action="" method="post">

                <div class="input-group m-t-10 c-square col-md-4 col-sm-5">
                    <span class="input-group-addon" id="basic-addon1" for="price">Giá tiền</span>
                    <select class="form-control c-square c-theme" name="price">
						<option value="0">Chọn Khoảng Giá</option>
						<option value="1">Giá Dưới 50k</option>
						<option value="2">Giá Dưới 100k</option>
						<option value="3">Giá Dưới 500k</option>
						<option value="4">Giá Dưới 1000k</option>
						<option value="5">Giá 100k-500k</option>
						<option value="6">Giá 500k-1000k</option>
						<option value="7">Giá lớn hơn 1000k</option>
                    </select></div>
                    <div class="input-group m-t-10 c-square col-md-3 col-sm-4">
                    <span class="input-group-addon" id="basic-addon1" for="rank">Rank</span>
                    <select class="form-control c-square c-theme" name="rank">
					<option value="0">Không Rank</option>
					<option value="1">Rank Đồng</option>
					<option value="2">Rank Bạc</option>
					<option value="3">Rank Vàng</option>
					<option value="4">Rank Bạch Kim</option>
					<option value="5">Rank Kim Cương</option>
					<option value="6">Rank Cao Thủ</option>
					<option value="7">Rank Thách Đấu</option>		
						
                    </select>
                </div>
                <div class="input-group m-t-10 c-square col-md-3 col-sm-5">
                    <span class="input-group-addon" id="basic-addon1" for="frame">Khung</span>
                     <select class="form-control c-square c-theme" name="frame">
					<option value="0">Không Khung</option>
					<option value="1">Khung Bạc</option>
					<option value="2">Khung Vàng</option>
					<option value="3">Khung Bạch Kim</option>
					<option value="4">Khung Kim Cương</option>
					<option value="5">Khung Cao Thủ</option>
					<option value="6">Khung Thách Đấu</option>						
                    </select>
                </div>
                  <div class="form-group m-t-10 c-square">
                    <input type="submit" class="btn c-square c-theme c-btn-green" name="submit" value="Tìm">
                      <a class="btn c-square m-l-0 btn-danger" href="<?=$home;?>/mohom/hom-kimcuong">Xóa Lọc</a>
                </div>
        
</form>

        </div>
        
           <?php



$price = !empty($_POST['price']) ? addslashes($_POST['price']) : ""; 
$rank = !empty($_POST['rank']) ? addslashes($_POST['rank']) : ""; 
$frame = !empty($_POST['frame']) ? addslashes($_POST['frame']) : "";

/* lọc theo tiền */

if($price == '1'):
$sql_gia = " gia <= 50000  ";
elseif($price == '2'):
$sql_gia = " gia <= 100000  ";
elseif($price == '3'):
$sql_gia = " gia <= 500000  ";
elseif($price == '4'):
$sql_gia = " gia <= 1000000  ";
elseif($price == '5'):
$sql_gia = " gia BETWEEN 100000 AND 500000   ";
elseif($price == '6'):
$sql_gia = " gia BETWEEN 500000 AND 100000  ";
elseif($price == '7'):
$sql_gia = " gia >= 1000000 ";
else:
$sql_gia = "";
endif;

/* lọc theo rank */

if($rank == '0'):
$sql_rank = "";
elseif($rank == '1'): //đồng
$sql_rank = " rank BETWEEN 2 AND 6  ";
elseif($rank == '2'): //bạc
$sql_rank = " rank BETWEEN 7 AND 11  ";
elseif($rank == '3'): //vàng
$sql_rank = " rank BETWEEN 12 AND 16  ";
elseif($rank == '4'): //bạch kim
$sql_rank = " rank BETWEEN 17 AND 21  ";
elseif($rank == '5'): //kim cương
$sql_rank = " rank BETWEEN 22 AND 26  ";
elseif($rank == '6'): //cao thủ
$sql_rank = " rank = 27  ";
elseif($rank == '7'): //thách đấu
$sql_rank = " rank = 28 ";
else:
$sql_rank = "";
endif;
/* khung */

if($frame == '1'):
$sql_khung = " khung = 1  ";
elseif($frame == '2'):
$sql_khung = " khung = 2  ";
elseif($frame == '3'):
$sql_khung = " khung = 3  ";
elseif($frame == '4'):
$sql_khung = " khung = 4  ";
elseif($frame == '5'):
$sql_khung = " khung = 5   ";
elseif($frame == '6'):
$sql_khung = " khung = 6  ";
elseif($frame == '7'):
$sql_khung = " khung = 7 ";
else:
$sql_khung = "";
endif;
    ?>
<?php
/*
╔═════════════════════════════════════════════╗
║     Design by Lua Uy Tin                    ║
║      Facebook: facebook.com/luauytin        ║
║   Hotline: 0369.056.756 - 0359.283.357      ║
╚═════════════════════════════════════════════╝
*/
// Kết nối database và thông tin chung
require_once(realpath($_SERVER["DOCUMENT_ROOT"]) .'/core/init.php');
$get_info = new Info;

$input = new Input;
$page = (int)$input->input_post("page");
$price = $settings['rd_'.$type.''];



$total_record = $db->fetch_row("SELECT COUNT(id) FROM acc_random WHERE $where LIMIT 1");
    // config phân trang
    $config = array(
      "current_page" => $page,
      "total_record" => $total_record,
      "limit" => "20",
      "range" => "5",
      "link_first" => "",
      "link_full" => "?page={page}"
    );
    $total_pages = ceil($total_record/20);
    $paging = new Pagination;
    $paging->init($config);
    $sql_get = "SELECT * FROM `homff` WHERE $where ORDER BY RAND() LIMIT {$paging->getConfig()["start"]}, {$paging->getConfig()["limit"]}";

// Nếu có 
if ($total_record){?>
<div class="jscroll-inner">
<?php
foreach ($db->fetch_assoc($sql_get, 0) as $key => $data){?>
                    <div class="sa-lpcol">
                        <div class="sa-lpi" style="border-image: url(/assets/images/diamond.png) 25 round;">
                            <h3><span class="sa-lpcode">Mở hòm kim cương 20K</span></h3>
                            <p class="sa-lpping"><img src="/assets/images/thumb/random-<?=$data['type'];?>.jpg"></p>
                            <div class="sa-lpbott clearfix">                                 
                                <div class="gg-info">
                                    <div class="gg-lpbif">
                                      <p class="hero"> ??</p>
                                      <p class="skin"> ??</p>
                                    </div>
                                    <div class="gg-lpbpri"> <p class="hero"> ??</p>
                                      <p class="skin"> <?=$get_info->random_level($type)?> <?=number_format($price*0.001)?>K</p>
                                    </div>
                                </div>
                                <div class="sa-lpbpri" style="text-align: left;">                                      
                                    <p class="sa-lpbpice" style="color: #f0b252;">#<?=$data['id'];?></p>
                                    <p></p>
                                </div>
                                <div class="sa-lpbpri">
                                    <p class="sa-lpbpice"><?=number_format($price)?><sup>Đ</sup></p>
                                    <p></p>
                                    <a class="sa-lpbbtn ac-buy-acc" onclick="buy_acc_random(<?=$data['id'];?>);">THỬ NGAY</a>
                                </div>
                            </div>
                        </div>
                    </div>



<?php }?>
</div>
<div class="clearfix"></div>
<?php if($total_pages > 1){?>
<ul class="sa-pagging text-center">
<li onclick="page=1;" class="PagedList-skipToFirst"><a href="?page=1">««</a></li>
<?php
for ($i=1; $i<=$total_pages; $i++) { 
if($page==$i):
echo "<li onclick='page=$i;' class='active'><a href='?page=$i'>".$i."</a></li>";
else:
echo "<li onclick='page=$i;'><a href='?page=$i'>".$i."</a></li>";
endif;
};
?>
<li onclick="page=<?=$total_pages?>;" class="PagedList-skipToLast"><a href="?page=<?=$total_pages?>">»»</a></li>
</ul>
<?php
}}else {
?>
<h3 class="text-center">Không Có Tài Khoản Nào Được Tìm Thấy</h3>
<?php
}
?>





   

                        
        
                        <div class="data_paginate paging_bootstrap paginations_custom" style="text-align: center">
            <ul class="pagination pagination-sm">
        
  
        
        
        
                                                        <li class="page-item active"><?php
for ($i=1; $i<=$total_pages; $i++) { 
    
if($page==$i):
echo "<li onclick='page=$i;' class='page-item active'><a href='?page=$i'>".$i."</a></li>";
else:
echo "<li onclick='page=$i;'><a href='?page=$i'>".$i."</a></li>";
endif;

}; 

?></li>
                                                                        
        
        
        
                    
            </ul>

        </div>


        
        <div class="tab-vertical tutorial_area">
            <div class="panel-group" id="accordion">

                
                
                            </div>
        </div>
        
        
    </div>



            <!-- END: PAGE CONTENT -->
</div>
                        <script>
function alert_mo(acc) {
	swal(
	{
	  title: "Mở Rương",
	  text: "Bạn Có Muốn Mở 1 Rương Với Gía 20k",
	  type: "info",
	  showCancelButton: true,
	  confirmButtonColor: "rgb(5, 119, 114)",
          
	  confirmButtonText: "Mở Ngay",
          cancelButtonColor: "#DD6B55",
	  cancelButtonText: "Thôi",
	  closeOnConfirm: false,
	  showLoaderOnConfirm: true
	}, function () {
	  $.post("/assets/ajax/site/buy_homkc.php", {id: acc}, function (data) {
	    if (data.error == 0) {
	      
	     swal({
  title: "Mua Lượt Thành Công !",
  text: data.msg,
  type: "success",
  html: true,
  showCancelButton: true,
  confirmButtonColor: "#FF6633",
  cancelButtonColor: "#9933CC",
  confirmButtonText: "OK",
  showLoaderOnConfirm: true,
  showLoaderOnCancel: true,
  

},
function(isConfirm){
  if (isConfirm) {
     setTimeout(function () {
    load_account_list();
  }, 20);
  } else {
     setTimeout(function () {
    window.location = "/mohom/hom-kimcuong";
  }, 20);
  }
});
    
	    } else {
	      swal({
	        title : "Có lỗi xảy ra!!",
	        type: "error",
	        text: data.msg
	        
	      }, function (isConfirm) {
                 window.location = data.link;

	           
	        
	      });
	    }
	  }, "json");
	}
	);
}

</script> 