<?php
/*
╔═════════════════════════════════════════════╗
║     Design by Lua Uy Tin                    ║
║      Facebook: facebook.com/luauytin        ║
║   Hotline: 0369.056.756 - 0359.283.357      ║
╚═════════════════════════════════════════════╝
*/
$type = GET('type');
if($accounts['password'] == ''){$type = 'password';}
if($type != 'email' && $type != 'phone' && $type != 'password'){$type = '';}
?>
<div class="sa-mainsa">
    <div class="container">
            <div class="sa-logmain sa-themain">
            <div class="sa-charingbox">
                <ul class="sa-lognav-tabs" role="tablist">
                    <li role="presentation">
                        <a role="tab" data-toggle="tab" aria-expanded="true">
                            <?php if($type == 'phone'):?>
                            Cập nhật số điện thoại
                            <?php elseif($type == 'email'):?>
                            Cập nhật Email kết nối
                            <?php elseif($type == 'password'):?>
                            Cập nhật mật khẩu
                            <?php else:?>
                            Thông tin tài khoản
                            <?php endif;?>
                        </a>
                    </li>
                </ul>
                <div class="sa-logtct tab-content">
                    <div role="tabpanel" class="tab-pane active"">
                        <div class="row">
                            <div class="col-md-6 col-md-offset-3">
                                    <form id="change_info" novalidate="novalidate">
                                        <input type="hidden" name="type" value="<?=$type;?>">
                                        <ul>
                                        <?php if($type == 'phone'):?>
                                        <?php if($accounts['phone']):?>
                                            <li class="input-group form-group">
                                                <div class="input-group-addon">
                                                    <b style="color:red">SĐT cũ:</b>
                                                </div>
                                                <input class="form-control" type="text" name="oldinfo" id="oldinfo" placeholder="Số điện thoại cũ">
                                            </li>
                                        <?php else:?>
                                        <li class="input-group form-group">
                                                <p class="text-danger">Sau khi cập nhật. Số điện thoại có thể dùng để làm tài khoản đăng nhập !</p>
                                        </li>
                                        <?php endif;?>
                                            <li class="input-group form-group">
                                                <div class="input-group-addon">
                                                    <b style="color:red">SĐT mới:</b>
                                                </div>
                                                <input class="form-control" type="text" name="newinfo" placeholder="Số điện thoại mới">
                                            </li>
                                            <li class="input-group form-group">
                                                <div class="input-group-addon">
                                                    <b style="color:red">Mật khẩu:</b>
                                                </div>
                                                <input class="form-control" type="password" name="renewinfo" placeholder="Nhập mật khẩu">
                                            </li>
                                        <?php elseif($type == 'email'):?>
                                        <?php if($accounts['email']):?>
                                            <li class="input-group form-group">
                                                <div class="input-group-addon">
                                                    <b style="color:red">Email cũ:</b>
                                                </div>
                                                <input class="form-control" type="email" name="oldinfo" id="oldinfo" placeholder="Email cũ">
                                            </li>
                                        <?php endif;?>
                                            <li class="input-group form-group">
                                                <div class="input-group-addon">
                                                    <b style="color:red">Email mới:</b>
                                                </div>
                                                <input class="form-control" type="email" name="newinfo" id="newinfo" placeholder="Email mới">
                                            </li>
                                            <li class="input-group form-group">
                                                <div class="input-group-addon">
                                                    <b style="color:red">Mật khẩu:</b>
                                                </div>
                                                <input class="form-control" type="password" name="renewinfo" id="renewinfo" placeholder="Nhập mật khẩu">
                                            </li>
                                        <?php elseif($type == 'password'):?>
                                            <?php if($accounts['password'] != ''):?>
                                            <li class="input-group form-group">
                                                <div class="input-group-addon">
                                                    <b style="color:red">MẬt khẩu cũ:</b>
                                                </div>
                                                <input class="form-control" type="password" name="oldinfo" id="oldinfo" placeholder="Mật khẩu cũ">
                                            </li>
                                            <?php else:?>
                                            <li class="input-group form-group">
                                                <p class="text-danger">Vui lòng cập nhật mật khẩu mới !</p>
                                            </li>
                                            <?php endif;?>
                                            <li class="input-group form-group">
                                                <div class="input-group-addon">
                                                    <b style="color:red">Mật khẩu mới:</b>
                                                </div>
                                                <input class="form-control" type="password" name="newinfo" id="newinfo" placeholder="Mật khẩu mới">
                                            </li>
                                            <li class="input-group form-group">
                                                <div class="input-group-addon">
                                                    <b style="color:red">Mật khẩu mới:</b>
                                                </div>
                                                <input class="form-control" type="password" name="renewinfo" id="renewinfo" placeholder="Nhập lại mật khẩu mới">
                                            </li>
                                        <?php else:?>
                                            <li class="input-group form-group">
                                                <div class="input-group-addon">
                                                    <b style="color:red">Email:</b>
                                                </div>
                                                <input class="form-control" value="<?php if($accounts['email'] != ""){echo str_replace( substr(substr($accounts['email'], 0, strpos($accounts['email'], '@')), -5), '*****', $accounts['email']);}else{echo "Chưa cập nhật !";}?>" disabled>
                                                <div class="input-group-addon">
                                                    <a href="/infomation/email.html"><b style="color:blue">Cập nhật</b></a>
                                                </div>
                                            </li>
                                            <li class="input-group form-group">
                                                <div class="input-group-addon">
                                                    <b style="color:red">Phone:</b>
                                                </div>
                                                <input class="form-control" value="<?php if($accounts['phone'] != ""){echo str_replace( substr($accounts['phone'], -4), '****', $accounts['phone'] );}else{echo "Chưa cập nhật !";}?>" disabled>
                                                <div class="input-group-addon">
                                                    <a href="/infomation/phone.html"><b style="color:blue">Cập nhật</b></a>
                                                </div>
                                            </li>
                                            <li class="input-group form-group">
                                                <div class="input-group-addon">
                                                    <b style="color:red">Mật khẩu:</b>
                                                </div>
                                                <input type="password" class="form-control" placeholder="Nhập mật khẩu" value="**********" disabled>
                                                <div class="input-group-addon">
                                                    <a href="/infomation/password.html"><b style="color:blue">Cập nhật</b></a>
                                                </div>
                                            </li>
                                        <?php endif;?>
                                        <?php if($type != ''):?>
                                            <li>
                                                <button type="submit" class="sa-lib-dk btn btn-danger">CẬP NHẬT <i class="fa fa-spinner fa-spin" id="loading" style="color:white;display: none;"></i></button>
                                            </li>
                                        <?php endif;?>
                                        </ul>
                                    </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
