<?php
/*
╔═════════════════════════════════════════════╗
║     Design by Lua Uy Tin                    ║
║      Facebook: facebook.com/luauytin        ║
║   Hotline: 0369.056.756 - 0359.283.357      ║
╚═════════════════════════════════════════════╝
*/
$id = GET('id');
$get_info = new Info;
$products= $db->fetch_assoc("SELECT * FROM `products` WHERE `id` = '{$id}'", 1);

//check ID products
if($db->num_rows($sql_products) == 0){
    new Redirect($_DOMAIN);
}
    //tạo json Xe
    $list_champ = $db->fetch_assoc("SELECT * FROM lq_champion ORDER BY name DESC",0); 
    $rows = array();
    foreach ($list_champ as $r) { 
        $rows[] = $r;}
    $data_champ = json_decode(json_encode($rows), true);
    $champ = text($products["champs"]);

    //tạo json trang phục
    $list_skin = $db->fetch_assoc("SELECT * FROM lq_skin ORDER BY name DESC",0); 
    $rows = array();
    foreach ($list_skin as $r) { 
        $rows[] = $r;}
    $data_skin = json_decode(json_encode($rows), true);
    $skin = text($products["skins"]);
?>

    <div class="sa-mainsa">
    <div class="container">
        <div class="sa-lprod">
            <div class="sa-lpmain">
                <div class="sa-lsnmain clearfix">
                    <div class="sa-ttacc">
                    <?php if($products['status'] == 0):?>    
                        <div class="sa-ttactit clearfix">
                            <h1 class="sa-ttacc-tit">Tài khoản #<font color="red"><?=$products['id']?></font> - <?=$get_info->get_string_rank($products['rank'])?>  - <?=$products['type_account'] == 'ZingSpeed Mobile' ? 'Xe':'Skin Súng';?> <font color="red"><?=($products['champs_count'])?></font> - Trang Phục <font color="red"><?=($products['skins_count'])?></font> - <?=$products['type_account'] == 'ZingSpeed Mobile' ? 'Pet':($products['type_account'] == 'PUBG Mobile' ? 'Level':'Pet');?> <font color="red"><?=($products['gem_count'])?></font></h1>
                            <ul class="sa-ttactul hidden-xs">
                                <li class="sa-ttac-btn"><a class="buy-acc" title="MUA NGAY" onclick="buy_acc(<?=$products['id'];?>);">MUA NGAY <?=number_format($products['price'], 0, '.', '.')?><sup>đ</sup></a></li>
                            </ul>
                            <ul class="hidden-md hidden-sm hidden-lg">
                            <center>
                                <li class="sa-ttac-btn"><a class="buy-acc" title="MUA NGAY" onclick="buy_acc(<?=$products['id'];?>);">MUA NGAY VỚI <?=number_format($products['price'], 0, '.', '.')?><sup>VNĐ</sup></a></li>
                            </center>
                            </ul>
                        </div>
                    <?php else:?>
                        <h1 class="sa-ttacc-tit">Tài khoản #<font color="red"><?=$products['id']?></font> - <?=$get_info->get_string_rank($products['rank'])?>  - <?=$products['type_account'] == 'ZingSpeed Mobile' ? 'Xe':'Skin Súng';?> <font color="red"><?=($products['champs_count'])?></font> - Trang Phục <font color="red"><?=($products['skins_count'])?></font> - <?=$products['type_account'] == 'ZingSpeed Mobile' ? 'Pet':($products['type_account'] == 'PUBG Mobile' ? 'Level':'Pet');?> <font color="red"><?=($products['gem_count'])?></font></h1>
                        <div class="sa-ttactit clearfix">
                            <ul class="sa-ttactul">
                                <li class="sa-ttac-btn"><a class="buy-acc" style="background: -webkit-linear-gradient(bottom, #2e4bb9 0%, #04ff00 100%);">Đã bán</a></li>
                            </ul>
                        </div>
                    <?php endif;?>
                        <ul class="sa-ttacc-tabs clearfix" role="tablist">
                            <li role="presentation" class="active">
                                <a href="#ct-thong-tin" role="tab" data-toggle="tab">THÔNG TIN</a>
                            </li>
                            <li role="presentation">
                                <a href="#ct-tuong" role="tab" data-toggle="tab">
                                    <?=$products['type_account'] == 'ZingSpeed Mobile' ? 'Xe':'SKIN SÚNG';?> <span><?=$products['champs_count'];?></span>
                                </a>
                            </li>
                            <li role="presentation">
                                <a href="#ct-trang-phuc" role="tab" data-toggle="tab">
                                    TRANG PHỤC <span><?=$products['skins_count'];?></span>
                                </a>
                            </li>
                            <li role="presentation">
                                <a href="#ct-ngoc-bo-tro" role="tab" data-toggle="tab">
                                    <?=$products['type_account'] == 'ZingSpeed Mobile' ? 'Pet':($products['type_account'] == 'PUBG Mobile' ? 'LEVEL':'PET');?> <span><?=$products['gem_count'];?></span>
                                </a>
                            </li>
                        </ul>
                        <div class="sa-ttacc-tcont tab-content">
                        <div style="font-size:20px;text-align: center;">
                            <a href="/huong-dan-thanh-toan.html" target="_blank">
                                <button class="btn btn-success" type="button"><i class="fa fa-check"></i> MUA BẰNG MoMo, ATM: <?=number_format($products['price']*0.8, 0, '.', '.')?><sup>đ</sup></button>
                            </a>
                        </div><br/>
                        <div role="tabpanel" class="tab-pane active" id="ct-thong-tin">
                            <div style="text-align: center;">
                        <?php if($products['note']):?>
                            <p class="h3"><?=$products['note']?></p><br/>
                        <?php endif;?>
                            <div class="swiper-container ccc swiper-container-horizontal sabner">
                                <div class="swiper-wrapper">
                                    <?php
                                        $arr_info = glob($root."/assets/files/post/".$id."-*");
                                        if($arr_info){
                                         foreach ($arr_info as $inf) { 
                                            $img = str_replace($root,"",$inf);      
                                            $name = str_replace($root."/assets/files/post/","",$inf);?>
                                        <div class="swiper-slide">
                                            <img src="<?php echo $img; ?>">
                                        </div>
                                    <?php }}?>
                                    <?php
                                        $arr_info = glob($root."/assets/files/gem/".$id."-*");
                                        if($arr_info){
                                         foreach ($arr_info as $inf) { 
                                            $img = str_replace($root,"",$inf);      
                                            $name = str_replace($root."/assets/files/gem/","",$inf);?>
                                        <div class="swiper-slide">
                                            <img src="<?php echo $img; ?>">
                                        </div>
                                    <?php }}?>
                                </div>
                                <div class="swiper-button-prev swiper-button-white"></div>
                                <div class="swiper-button-next swiper-button-white"></div>
                                <div class="swiper-pagination"></div>
                            </div>
                            </div>
                        </div>
                        <?php if(!empty($products["champs"])){?>
                        <div role="tabpanel" class="tab-pane" id="ct-tuong">
                            <ul class="l-i-c-acc">
                                <?php foreach ($data_champ as $list){
                                    if (in_array_r(strtolower(trim($list['name'])), $champ)) {?>
                                    <li><img src="/assets/images/lq_champion/<?=$list['img_name'];?>" title="<?=$list['name'];?>" alt="<?=$list['name'];?>"><label style="<?php if($list['vip'] != 'no'){echo 'background-color: yellow;color:red;';}?>"><?=$list['name'];?></label></li>
                                <?php }}?> 
                            </ul>
                        </div>
                        <?php }?>
                        <?php if(!empty($products["skins"])){?>
                        <div role="tabpanel" class="tab-pane" id="ct-trang-phuc">
                            <ul class="l-i-c-acc">
                                <?php foreach ($data_skin as $list){
                                    if (in_array_r(strtolower(trim($list['name'])), $skin)) {?>
                                    <li><img src="/assets/images/lq_skin/<?=$list['img_name'];?>" title="<?=$list['name'];?>" alt="<?=$list['name'];?>"><label style="<?php if($list['vip'] != 'no'){echo 'background-color: yellow;color:red;';}?>"><?=$list['name'];?></label></li>
                                <?php }}?> 
                            </ul>
                        </div>
                        <?php }?>

<?php
$total_record = $db->fetch_row("SELECT COUNT(id) FROM `products` WHERE `id` != '{$products['id']}' AND `status` = '0' AND `type_account` = '{$products['type_account']}' LIMIT 1");
$sql_get = "SELECT * FROM `products` WHERE `status` = '0' AND `id` != '{$products['id']}' AND `type_account` = '{$products['type_account']}' ORDER BY RAND() LIMIT 4";
if ($total_record){?>
                        <br/><br/>
                        <div class="sa-ttmore">
                            <h2 class="sa-ttmoretit">ACC CÙNG ĐƠN GIÁ</h2>
                            <div class="swiper-container sattmore swiper-container-horizontal">
                                <div class="sa-lpmain">
                                <div class="jscroll-inner">

<?php foreach ($db->fetch_assoc($sql_get, 0) as $key => $data){?>
                    <div class="sa-lpcol">
                        <div class="sa-lpi" style="border-image: url(/assets/images/diamond.png) 25 round;">
                          <a class="sa-lpimg" href="/accounts/<?=$data['id'];?>.html">
                                <p class="sa-lpping"><img src="<?php echo $get_info->get_thumb($data['id']); ?>"></p>                            
                            <div class="sa-lpinfo">
                                <div class="sa-lpits mcustomscrollbar mCustomScrollbar _mCS_2 mCS_no_scrollbar">
                                  <div id="mCSB_2" class="mCustomScrollBox mCS-light mCSB_vertical mCSB_inside" style="max-height: 197px;" tabindex="0">
                                    <div id="mCSB_2_container" class="mCSB_container mCS_y_hidden mCS_no_scrollbar_y" style="position:relative; top:0; left:0;" dir="ltr">
                                    <?php if($data['type_account'] == 'ZingSpeed Mobile'):?>
                                      ● Rank: <?php echo $get_info->get_string_rank($data['rank']); ?><br/>
                                      ● Xe: <?=$data['champs_count'];?><br/>
                                      ● Trang Phục: <?=$data['skins_count'];?><br/>
                                      ● Bảng Ngọc: <?=$data['gem_count'];?><br/>
                                    <?php else:?>
                                      ● Rank: <?php echo $get_info->get_string_rank($data['rank']); ?><br/>
                                      ● Skin Súng: <?=$data['champs_count'];?><br/>
                                      ● Trang Phục: <?=$data['skins_count'];?><br/>
                                      ● <?=$data['type_account'] == 'PUBG Mobile' ? 'Level':'Pet';?>: <?=$data['gem_count'];?><br/>
                                    <?php endif;?>
                                    <?php if($data['note']):?>
                                      ● <?=$data['note']?>
                                    <?php endif;?>
                                    </div>
                                  <div id="mCSB_2_scrollbar_vertical" class="mCSB_scrollTools mCSB_2_scrollbar mCS-light mCSB_scrollTools_vertical" style="display: none;">
                                    <div class="mCSB_draggerContainer">
                                      <div id="mCSB_2_dragger_vertical" class="mCSB_dragger" style="position: absolute; min-height: 0px; height: 0px; top: 0px;">
                                        <div class="mCSB_dragger_bar" style="line-height: 0px;"></div>
                                      </div>
                                      <div class="mCSB_draggerRail"></div>
                                    </div>
                                  </div>
                                </div>
                              </div>                      
                        </div>
                            </a>
                            <div class="sa-lpbott clearfix">
                            <?php if($data['type_account'] != 'ZingSpeed Mobile'):?>                  
                                <div class="gg-info">
                                    <div class="gg-lpbif">
                                      <p class="hero"> Skin Súng: <?=$data['champs_count'];?></p>
                                      <p class="skin"> Trang Phục: <?=$data['skins_count'];?></p>
                                    </div>
                                    <div class="gg-lpbpri"> <p class="hero"> <?=$data['type_account'] == 'PUBG Mobile' ? 'Level':'Pet';?>: <?=$data['gem_count'];?></p>
                                      <p class="skin"> <?php echo $get_info->get_string_rank($data['rank']); ?> </p>
                                    </div>
                                </div>
                            <?php else:?>
                                <div class="gg-info">
                                    <div class="gg-lpbif">
                                      <p class="hero"> Xe: <?=$data['champs_count'];?></p>
                                      <p class="skin"> Skin: <?=$data['skins_count'];?></p>
                                    </div>
                                    <div class="gg-lpbpri"> <p class="hero"> Ngọc: <?=$data['gem_count'];?></p>
                                      <p class="skin"> <?php echo $get_info->get_string_rank($data['rank']); ?> </p>
                                    </div>
                                </div>
                            <?php endif;?>
                                <div class="sa-lpbpri" style="text-align: left;">                                      
                                    <p class="sa-lpbpice" style="color: #f0b252;">#<?=$data['id'];?></p>
                                    <p></p>
                                    <a href="/accounts/<?=$data['id'];?>.html" class="xem-acc" title="XEM ACC" style="color:white;">XEM ACC</a>
                                </div>
                                <div class="sa-lpbpri">
                                    <p class="sa-lpbpice"><?=number_format($data['price']);?><sup>Đ</sup></p>
                                    <p></p>
                                    <a class="sa-lpbbtn ac-buy-acc" onclick="buy_acc(<?=$data['id'];?>);">MUA NGAY</a>
                                </div>
                            </div>
                        </div>
                    </div>
<?php }?>
                                </div>
                            </div>
                            </div>
                        </div>
<?php }?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>