<?php
/*
╔═════════════════════════════════════════════╗
║     Design by Lua Uy Tin                    ║
║      Facebook: facebook.com/luauytin        ║
║   Hotline: 0369.056.756 - 0359.283.357      ║
╚═════════════════════════════════════════════╝
*/
require_once(realpath($_SERVER["DOCUMENT_ROOT"]) .'/core/init.php');
//lấy dữ liệu vòng quay
$sql_setting_wheel =  "SELECT * FROM `setting_wheel`";
if ($db->num_rows($sql_setting_wheel)){
    $setting_wheel = $db->fetch_assoc($sql_setting_wheel, 1);
    $page = (int)POST("page");

$total_record = $db->fetch_row("SELECT COUNT(id) FROM `history_wheel` WHERE `username` = '".$iduser."' LIMIT 1");
$limit = 15*$page;
$sql_history = "SELECT * FROM `history_wheel` WHERE `type` != '0' ORDER BY `time` DESC LIMIT 5";
    $price = $setting_wheel['wheel_price'];//giá quay
}else{
    die('Bảo trì');
}
?>
<link rel="stylesheet" type="text/css" href="/assets/css/custom.css">
<link rel="stylesheet" type="text/css" href="/assets/css/wheel.css">
<script type="text/javascript" src="/assets/js/Custom/wheel.js"></script>
<?php
$cash = "SELECT * FROM `history_wheel` order by id desc LIMIT 15";
if ($db->num_rows($cash) > 0):?>
<div class="sl-search">
    <div class="container">
        <div class="col-sm-12" style="background-color: #323131;font-size: 17px;color: #fff;">
            <marquee scrollamount="4" style="padding-top: 8px;">
<?php foreach ($db->fetch_assoc($cash, 0) as $key => $data){?>
<img src="/assets/images/run.gif" style="border-radius: 1.25em;width: 27px;"> <b style="color: #f5ff91;"><?=$data['name'];?></b> vừa quay số <?=time_stamp(strtotime($data['time']));?> 
<?php }?>
            </marquee>
        </div>
    </div>
</div>
<?php endif; ?>
<div class="sl-search">
    <div class="container">
        <div class="sl-sebox">
            <div class="sl-row clearfix">
                <div class="sl-col col-md-12 col-xs-12">
                    <h1 class="sl-htit text-center" style="font-size: 33px;">VÒNG QUAY KIM CƯƠNG FREE FIRE</h1>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="sa-mainsa">
    <div class="container">
        <div class="sa-logmain sa-themain">
            <div class="sa-charingbox">
                <div class="sa-logtct">
                    <div class="row">
                        <div class="col-md-6">
                            <section class="rotation">
                                <div class="play-spin">
                                    <a href="#" class="ani-zoom" id="start-played"><img src="/assets/img/IMG_3478.png" alt="Play Center">
                                    </a>
                                    <img src="/assets/img/wheel_kc_ff.png" alt="Play" id="rotate-play">
                                </div>
                                <br />
                                <style>
                                    .h3,
                                    h3 {
                                        font-size: 24px;
                                    }
                                    
                                    img#hu {
                                        width: 55%;
                                    }
                                </style>
                                <div class="text-center">
                                    <h3 class="num-play"><span><?=number_format($setting_wheel['wheel_price']);?>đ</span> mỗi lượt quay.</h3>
                                </div>
                            </section>
                        </div>
                        
  <br>
  
                    <h1 class="sa-ls-tit">Lịch sử quay của các thành viên</h1>
                                <div class="sa-ls-table table-responsive">
                                            <table class="table">
                                                <thead>
                                                    <tr>
                                                        <td>TÊN</td>
                                                        <td>SỐ KIM CƯƠNG</td>
                                                        <td>THỜI GIAN</td>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php
                                                    $slq_history_wheel = "SELECT * FROM `history_wheel` WHERE `type` != '0' ORDER BY `time` DESC LIMIT 5";
                                                    if ($db->num_rows($slq_history_wheel)){
                                                        foreach ($db->fetch_assoc($slq_history_wheel, 0) as $key => $row){?>
                                                    <tr>
                                                        <td><?=$row['name'];?></td>
                                                       <td><?=$row['prize'];?></td>>
                                                        <td><?=$row['time'];?></td>
                                                    </tr>
                                                    <?php } if($limit < $total_record){?>
<td class="text-center" colspan="3"><a onclick="page=<?=$page+1;?>;history_wheel();" style="color: #a1c938;font-weight: 900;font-size: larger;">XEM THÊM <i class="fa fa-spinner fa-spin loading_other" style="display: none;"></i></a></td>
                                                    <?php }}else{?>

                                                    <tr><td colspan="3" class="text-center">CHƯA CÓ AI QUAY !</td></tr>
                                                    <?php }?>
                                                </tbody>
                                            </table>
                                </div>
                            
                        </div>
                    </div>
                </div>

<div class="col-md-12" style="margin-top: 30px;">
    <ul class="sa-lognav-tabs" role="tablist">
                                <li role="presentation" class="active"><a href="#his"role="tab" data-toggle="tab" aria-expanded="false">LỊCH SỬ QUAY</a></li>
                                <li role="presentation"><a href="#policy" role="tab" data-toggle="tab" aria-expanded="false">THỂ LỆ</a></li>
                            </ul>
                            <div class="sa-logtct tab-content">
                                <div role="tabpanel" class="tab-pane" id="danh-sach">
                                    <div class="sa-ls-table table-responsive">
                                        <table class="table">
                                            <thead>
                                                <tr>
                                                    <td>TÊN</td>
                                                    <td>GIẢI THƯỞNG</td>
                                                    <td>THỜI GIAN</td>
                                                </tr>
                                            </thead>
                                            <tbody id="history">
                                                <td class="text-center" colspan="3">Xin chờ <i class="fa fa-spinner fa-spin"></i></td>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                                <div role="tabpanel" class="tab-pane active" id="his">
                                <div class="sa-ls-table table-responsive">
                                        <table class="table">
                                            <thead>
                                                <tr>
                                                    <td style="width: 60px;">ID</td>
                                                    <td>SỐ KIM CƯƠNG</td>
                                                    <td>THỜI GIAN</td>
                                                </tr>
                                            </thead>
                                            <tbody id="history_wheel">
                                                <td class="text-center" colspan="3">Xin chờ <i class="fa fa-spinner fa-spin"></i></td>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                                <div role="tabpanel" class="tab-pane" id="policy" style="font-weight: bold;font-size: 17px;color: white;">
                                    <p>-Khi quay được bao nhiêu kim cương thì shop sẽ tự động cộng kim cương vào tài khoản trên shop của bạn. Bạn chỉ cần vào mục rút kim cương và rút về tài khoản game của các bạn nhé! </p>
                                    <p>- 1 Lượt quay sẽ mất <?=number_format($setting_wheel['wheel_price']);?>đ tiền trên shop,tiền shop sở hữu bằng cách nạp thẻ cào.</p>
                                    <p>- Quay càng nhiều tỉ lệ quay ra 11,000 kim cương sẽ càng cao nhé.</p>
          </div>
                            </div>
</div>



                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>