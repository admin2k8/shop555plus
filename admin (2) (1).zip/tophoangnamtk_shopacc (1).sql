-- phpMyAdmin SQL Dump
-- version 4.9.4
-- https://www.phpmyadmin.net/
--
-- Máy chủ: localhost:3306
-- Thời gian đã tạo: Th8 15, 2020 lúc 08:49 PM
-- Phiên bản máy phục vụ: 10.0.38-MariaDB-cll-lve
-- Phiên bản PHP: 7.3.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Cơ sở dữ liệu: `tophoangnamtk_shopacc`
--

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `accounts`
--

CREATE TABLE `accounts` (
  `id` int(11) NOT NULL,
  `username` text COLLATE utf8_unicode_ci NOT NULL,
  `name` text COLLATE utf8_unicode_ci NOT NULL,
  `password` text COLLATE utf8_unicode_ci NOT NULL,
  `cash` int(11) DEFAULT '0',
  `email` text COLLATE utf8_unicode_ci NOT NULL,
  `phone` text COLLATE utf8_unicode_ci NOT NULL,
  `diamon_ff` int(11) NOT NULL DEFAULT '0',
  `fb` int(11) NOT NULL,
  `time` int(11) NOT NULL,
  `datetime` datetime DEFAULT NULL,
  `time_block` int(11) DEFAULT NULL,
  `days_block` int(11) DEFAULT NULL,
  `block` int(11) DEFAULT NULL,
  `note` text COLLATE utf8_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `accounts`
--

INSERT INTO `accounts` (`id`, `username`, `name`, `password`, `cash`, `email`, `phone`, `diamon_ff`, `fb`, `time`, `datetime`, `time_block`, `days_block`, `block`, `note`) VALUES
(1, 'hungakira123', 'Trịnh Quang Hung', 'acb5714f50ca485fd135a69df2f5f84f', 0, '', '', 0, 0, 0, '2020-08-07 20:29:39', NULL, NULL, NULL, NULL),
(2, 'admin168', 'LT09 GAMING TV', 'f2186c3f9017a9963c327bfdc9b63f1a', 0, '', '', 0, 0, 0, '2020-08-08 16:04:44', NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `acc_random`
--

CREATE TABLE `acc_random` (
  `id` int(11) NOT NULL,
  `iduser` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `id_name` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `username` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `password` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `price` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `type` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `time` datetime DEFAULT NULL,
  `date` date DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `auto_card`
--

CREATE TABLE `auto_card` (
  `id` int(11) NOT NULL,
  `1` text NOT NULL,
  `2` text NOT NULL,
  `3` text NOT NULL,
  `4` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Đang đổ dữ liệu cho bảng `auto_card`
--

INSERT INTO `auto_card` (`id`, `1`, `2`, `3`, `4`) VALUES
(1, 'on', 'on', 'on', ''),
(2, 'on', 'on', 'on', '');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `ck_card`
--

CREATE TABLE `ck_card` (
  `id` int(11) NOT NULL,
  `1` int(11) NOT NULL,
  `2` int(11) NOT NULL,
  `3` int(11) NOT NULL,
  `4` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Đang đổ dữ liệu cho bảng `ck_card`
--

INSERT INTO `ck_card` (`id`, `1`, `2`, `3`, `4`) VALUES
(1, 100, 100, 100, 100),
(2, 100, 100, 100, 100);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `history_buy`
--

CREATE TABLE `history_buy` (
  `id` int(11) NOT NULL,
  `username` text COLLATE utf8_unicode_ci NOT NULL,
  `name` text COLLATE utf8_unicode_ci NOT NULL,
  `id_products` int(11) NOT NULL,
  `id_random` int(11) NOT NULL,
  `price` int(11) NOT NULL,
  `type` int(11) NOT NULL DEFAULT '0',
  `time` int(11) NOT NULL,
  `date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `history_buy`
--

INSERT INTO `history_buy` (`id`, `username`, `name`, `id_products`, `id_random`, `price`, `type`, `time`, `date`) VALUES
(1, 'phidoivox', 'vohoangnam', 3, 0, 400000, 0, 1596539928, '2020-08-04'),
(2, 'phidoivox', 'vohoangnam', 4, 0, 100000, 0, 1596550490, '2020-08-04'),
(3, 'phidoivox', 'vohoangnam', 5, 0, 200000, 0, 1596554903, '2020-08-04'),
(4, 'phidoivox', 'vohoangnam', 6, 0, 500, 0, 1596592842, '2020-08-05'),
(5, 'phidoivox', 'vohoangnam', 0, 2, 20000, 1, 1596624043, '2020-08-05'),
(6, 'phidoivox', 'vohoangnam', 0, 5, 20000, 1, 1596625092, '2020-08-05'),
(7, 'phidoivox', 'vohoangnam', 0, 14, 20000, 1, 1596644240, '2020-08-05'),
(8, 'phidoivox', 'vohoangnam', 0, 21, 20000, 1, 1596644282, '2020-08-05'),
(9, 'duongdz', 'Trịnh Quang Hung', 0, 23, 20000, 1, 1596672775, '2020-08-06'),
(10, 'duongdz', 'Trịnh Quang Hung', 0, 9, 20000, 1, 1596673174, '2020-08-06'),
(11, 'phidoivox', 'vohoangnam', 0, 24, 20000, 1, 1596673336, '2020-08-06'),
(12, 'duongdz', 'Trịnh Quang Hung', 0, 10, 20000, 1, 1596680625, '2020-08-06'),
(13, 'phidoivox', 'vohoangnam', 0, 7, 20000, 1, 1596680637, '2020-08-06'),
(14, 'duongdz', 'Trịnh Quang Hung', 0, 6, 20000, 1, 1596680651, '2020-08-06'),
(15, 'phidoivox', 'vohoangnam', 0, 12, 20000, 1, 1596680699, '2020-08-06'),
(16, 'duongdz', 'Trịnh Quang Hung', 0, 3, 20000, 1, 1596680699, '2020-08-06'),
(17, 'duongdz', 'Trịnh Quang Hung', 0, 8, 20000, 1, 1596680713, '2020-08-06'),
(18, 'duongdz', 'Trịnh Quang Hung', 0, 4, 20000, 1, 1596680730, '2020-08-06'),
(19, 'phidoivox', 'vohoangnam', 0, 13, 20000, 1, 1596680736, '2020-08-06'),
(20, 'duongdz', 'Trịnh Quang Hung', 0, 11, 20000, 1, 1596680749, '2020-08-06'),
(21, 'duongdz', 'Trịnh Quang Hung', 0, 15, 20000, 1, 1596680779, '2020-08-06'),
(22, 'phidoivox', 'vohoangnam', 0, 20, 20000, 1, 1596680816, '2020-08-06'),
(23, 'duongdz', 'Trịnh Quang Hung', 0, 1, 20000, 1, 1596680830, '2020-08-06'),
(24, 'phidoivox', 'vohoangnam', 0, 19, 20000, 1, 1596680846, '2020-08-06'),
(25, 'duongdz', 'Trịnh Quang Hung', 0, 22, 20000, 1, 1596680848, '2020-08-06'),
(26, 'duongdz', 'Trịnh Quang Hung', 0, 16, 20000, 1, 1596680859, '2020-08-06'),
(27, 'phidoivox', 'vohoangnam', 0, 17, 20000, 1, 1596680879, '2020-08-06'),
(28, 'duongdz', 'Trịnh Quang Hung', 1, 0, 500000000, 0, 1596681148, '2020-08-06');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `history_card`
--

CREATE TABLE `history_card` (
  `id` int(11) NOT NULL,
  `trans_id` text COLLATE utf8_unicode_ci,
  `username` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `type_card` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `seri` text COLLATE utf8_unicode_ci NOT NULL,
  `pin` text COLLATE utf8_unicode_ci NOT NULL,
  `count_card` int(11) NOT NULL,
  `cash_nhan` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `message` text COLLATE utf8_unicode_ci,
  `notice` text COLLATE utf8_unicode_ci,
  `time` datetime NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `history_card`
--

INSERT INTO `history_card` (`id`, `trans_id`, `username`, `name`, `type_card`, `seri`, `pin`, `count_card`, `cash_nhan`, `status`, `message`, `notice`, `time`, `date`) VALUES
(1, '4135153', 'phidoivox', 'vohoangnam', '1', '20000021605801', '418182518443509', 500000, 450000, 2, NULL, NULL, '2020-08-03 15:52:06', '2020-08-03'),
(2, '2698857', 'phidoivox', 'vohoangnam', '1', '20000021605801', '118182518443999', 500000, 450000, 2, NULL, NULL, '2020-08-03 16:03:47', '2020-08-03'),
(3, '2698906', 'phidoivox', 'vohoangnam', '1', '20000021605801', '118182518444568', 500000, 450000, 1, NULL, NULL, '2020-08-03 16:06:55', '2020-08-03'),
(4, '2699113', 'phidoivox', 'vohoangnam', '1', '20000021546213', '426885141076437', 300000, 270000, 1, NULL, NULL, '2020-08-03 16:20:44', '2020-08-03'),
(5, NULL, 'phidoivox', 'vohoangnam', '1', '53835832354', '4522330866328', 100000, 100000, 1, NULL, NULL, '2020-08-06 21:01:53', '2020-08-06');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `history_dff`
--

CREATE TABLE `history_dff` (
  `id` int(11) NOT NULL,
  `username` text NOT NULL,
  `name` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `id_ingame` text NOT NULL,
  `soluong` int(11) NOT NULL DEFAULT '0',
  `status` int(11) NOT NULL DEFAULT '0',
  `time` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Đang đổ dữ liệu cho bảng `history_dff`
--

INSERT INTO `history_dff` (`id`, `username`, `name`, `id_ingame`, `soluong`, `status`, `time`) VALUES
(1, 'phidoivox', 'vohoangnam', '123456789', 1900, 5, '2020-08-03 15:54:50'),
(2, 'phidoivox', 'vohoangnam', '123456789', 1900, 1, '2020-08-03 15:54:58'),
(3, 'phidoivox', 'vohoangnam', '123456789', 1900, 4, '2020-08-03 15:55:01'),
(4, 'phidoivox', 'vohoangnam', '123456789', 1900, 1, '2020-08-03 15:55:06'),
(5, 'phidoivox', 'vohoangnam', '123456789', 1900, 1, '2020-08-03 15:55:09'),
(6, 'phidoivox', 'vohoangnam', '123456789', 1900, 1, '2020-08-03 15:55:11'),
(7, 'phidoivox', 'vohoangnam', '123456789', 1900, 1, '2020-08-03 15:55:14'),
(8, 'phidoivox', 'vohoangnam', '1800007816', 1900, 1, '2020-08-04 15:51:56'),
(9, 'phidoivox', 'vohoangnam', '1800007816', 1900, 1, '2020-08-04 15:51:58'),
(10, 'phidoivox', 'vohoangnam', '1783632971', 1900, 1, '2020-08-04 19:28:46'),
(11, 'phidoivox', 'vohoangnam', '1783632971', 1900, 1, '2020-08-04 19:28:48'),
(12, 'phidoivox', 'vohoangnam', '1630828937', 1900, 1, '2020-08-04 19:54:36'),
(13, 'phidoivox', 'vohoangnam', '1630828937', 1900, 1, '2020-08-04 19:54:38'),
(14, 'phidoivox', 'vohoangnam', '1630828937', 1900, 1, '2020-08-04 19:54:41'),
(15, 'phidoivox', 'vohoangnam', '1800007816', 1900, 1, '2020-08-05 08:54:34'),
(16, 'phidoivox', 'vohoangnam', '856850475', 1900, 1, '2020-08-05 09:46:31'),
(17, 'phidoivox', 'vohoangnam', '1783632971', 1900, 1, '2020-08-05 17:10:16'),
(18, 'phidoivox', 'vohoangnam', '1783632971', 1900, 1, '2020-08-05 17:10:17'),
(19, 'phidoivox', 'vohoangnam', '1783632971', 1900, 1, '2020-08-05 17:10:19'),
(20, 'phidoivox', 'vohoangnam', '1783632971', 1900, 1, '2020-08-05 17:10:20'),
(21, 'phidoivox', 'vohoangnam', '1783632971', 1900, 1, '2020-08-05 17:10:22'),
(22, 'phidoivox', 'vohoangnam', '1783632971', 1900, 1, '2020-08-05 17:10:23'),
(23, 'phidoivox', 'vohoangnam', '1783632971', 1900, 1, '2020-08-05 17:10:25'),
(24, 'phidoivox', 'vohoangnam', '1783632971', 1900, 1, '2020-08-05 17:10:26'),
(25, 'phidoivox', 'vohoangnam', '1783632971', 1900, 1, '2020-08-05 17:10:27'),
(26, 'phidoivox', 'vohoangnam', '1783632971', 1900, 1, '2020-08-05 17:10:29'),
(27, 'phidoivox', 'vohoangnam', '2015401915', 1900, 1, '2020-08-05 20:09:48'),
(28, 'phidoivox', 'vohoangnam', '1426250401', 1900, 1, '2020-08-05 20:14:32'),
(29, 'phidoivox', 'vohoangnam', '1172300528', 1900, 1, '2020-08-05 20:21:54'),
(30, 'phidoivox', 'vohoangnam', '488515810', 1900, 1, '2020-08-05 20:23:34'),
(31, 'phidoivox', 'vohoangnam', '2001813071', 1900, 1, '2020-08-05 21:22:33'),
(32, 'phidoivox', 'vohoangnam', '1580555352', 1900, 1, '2020-08-05 21:23:57'),
(33, 'namhoai221100', 'Namhoài', '528206983', 1900, 4, '2020-08-05 22:33:40'),
(34, 'duongdz', 'Trịnh Quang Hung', '1630828937', 950, 4, '2020-08-06 07:13:44'),
(35, 'duongdz', 'Trịnh Quang Hung', '53194342', 230, 1, '2020-08-06 08:13:05'),
(36, 'duongdz', 'Trịnh Quang Hung', '53194342', 1900, 1, '2020-08-06 08:16:26'),
(37, 'duongdz', 'Trịnh Quang Hung', '53194342', 1900, 1, '2020-08-06 08:16:30'),
(38, 'duongdz', 'Trịnh Quang Hung', '1630828937', 950, 1, '2020-08-06 09:30:02'),
(39, 'duongdz', 'Trịnh Quang Hung', '749014169', 1900, 4, '2020-08-06 18:44:18'),
(40, 'duongdz', 'Trịnh Quang Hung', '749014169', 1900, 4, '2020-08-06 18:44:21'),
(41, 'duongdz', 'Trịnh Quang Hung', '749014169', 1900, 4, '2020-08-06 18:44:22'),
(42, 'duongdz', 'Trịnh Quang Hung', '749014169', 1900, 4, '2020-08-06 18:44:24'),
(43, 'duongdz', 'Trịnh Quang Hung', '749014169', 950, 4, '2020-08-06 18:52:42');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `history_wheel`
--

CREATE TABLE `history_wheel` (
  `id` int(11) NOT NULL,
  `username` text COLLATE utf8_unicode_ci NOT NULL,
  `name` text COLLATE utf8_unicode_ci NOT NULL,
  `type` int(11) NOT NULL DEFAULT '0',
  `nohu` int(11) NOT NULL DEFAULT '0',
  `prize` text COLLATE utf8_unicode_ci NOT NULL,
  `id_wheel` int(11) NOT NULL DEFAULT '0',
  `note` text COLLATE utf8_unicode_ci NOT NULL,
  `hide` int(11) NOT NULL DEFAULT '0',
  `date` text COLLATE utf8_unicode_ci,
  `time` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `history_wheel`
--

INSERT INTO `history_wheel` (`id`, `username`, `name`, `type`, `nohu`, `prize`, `id_wheel`, `note`, `hide`, `date`, `time`) VALUES
(1, 'phidoivox', 'vohoangnam', 1, 0, '45 Kim Cương', 0, '', 0, '2020-08-04', '2020-08-04 18:09:03'),
(2, 'phidoivox', 'vohoangnam', 1, 0, '45 Kim Cương', 0, '', 0, '2020-08-04', '2020-08-04 18:09:40'),
(3, 'phidoivox', 'vohoangnam', 1, 0, '45 Kim Cương', 0, '', 0, '2020-08-04', '2020-08-04 18:11:46'),
(4, 'phidoivox', 'vohoangnam', 3, 0, '200 Kim Cương', 0, '', 0, '2020-08-04', '2020-08-04 18:23:43'),
(5, 'phidoivox', 'vohoangnam', 1, 0, '45 Kim Cương', 0, '', 0, '2020-08-04', '2020-08-04 18:47:35'),
(6, 'phidoivox', 'vohoangnam', 5, 4770800, '400 Kim Cương', 0, '', 0, '2020-08-04', '2020-08-04 19:14:34'),
(7, 'phidoivox', 'vohoangnam', 4, 0, '32 Kim Cương', 0, '', 1, '2020-08-04', '2020-08-04 19:14:46'),
(8, 'phidoivox', 'vohoangnam', 4, 0, '32 Kim Cương', 0, '', 1, '2020-08-04', '2020-08-04 19:14:59'),
(9, 'phidoivox', 'vohoangnam', 4, 0, '32 Kim Cương', 0, '', 1, '2020-08-04', '2020-08-04 19:15:13'),
(10, 'phidoivox', 'vohoangnam', 4, 0, '32 Kim Cương', 0, '', 1, '2020-08-04', '2020-08-04 19:15:28'),
(11, 'phidoivox', 'vohoangnam', 4, 0, '32 Kim Cương', 0, '', 1, '2020-08-04', '2020-08-04 19:16:31'),
(12, 'phidoivox', 'vohoangnam', 5, 4823600, '400 Kim Cương', 0, '', 0, '2020-08-04', '2020-08-04 19:24:24'),
(13, 'phidoivox', 'vohoangnam', 1, 0, '45 Kim Cương', 0, '', 0, '2020-08-04', '2020-08-04 19:24:37'),
(14, 'phidoivox', 'vohoangnam', 1, 0, '45 Kim Cương', 0, '', 0, '2020-08-04', '2020-08-04 19:24:48'),
(15, 'phidoivox', 'vohoangnam', 1, 0, '45 Kim Cương', 0, '', 0, '2020-08-04', '2020-08-04 19:25:00'),
(16, 'phidoivox', 'vohoangnam', 1, 0, '45 Kim Cương', 0, '', 0, '2020-08-04', '2020-08-04 19:25:29'),
(17, 'phidoivox', 'vohoangnam', 4, 0, '32 Kim Cương', 0, '', 1, '2020-08-04', '2020-08-04 19:25:40'),
(18, 'phidoivox', 'vohoangnam', 5, 4876400, '400 Kim Cương', 0, '', 0, '2020-08-04', '2020-08-04 19:25:57'),
(19, 'phidoivox', 'vohoangnam', 4, 0, '32 Kim Cương', 0, '', 1, '2020-08-04', '2020-08-04 19:26:25'),
(20, 'phidoivox', 'vohoangnam', 5, 4894000, '400 Kim Cương', 0, '', 0, '2020-08-04', '2020-08-04 19:26:38'),
(21, 'phidoivox', 'vohoangnam', 4, 0, '32 Kim Cương', 0, '', 1, '2020-08-04', '2020-08-04 19:26:51'),
(22, 'phidoivox', 'vohoangnam', 4, 0, '32 Kim Cương', 0, '', 1, '2020-08-04', '2020-08-04 19:40:39'),
(23, 'phidoivox', 'vohoangnam', 4, 0, '32 Kim Cương', 0, '', 1, '2020-08-04', '2020-08-04 19:40:52'),
(24, 'phidoivox', 'vohoangnam', 3, 0, '200 Kim Cương', 0, '', 0, '2020-08-04', '2020-08-04 19:41:04'),
(25, 'phidoivox', 'vohoangnam', 4, 0, '32 Kim Cương', 0, '', 1, '2020-08-04', '2020-08-04 19:41:15'),
(26, 'phidoivox', 'vohoangnam', 3, 0, '200 Kim Cương', 0, '', 0, '2020-08-04', '2020-08-04 19:41:27'),
(27, 'phidoivox', 'vohoangnam', 4, 0, '32 Kim Cương', 0, '', 1, '2020-08-04', '2020-08-04 19:41:39'),
(28, 'phidoivox', 'vohoangnam', 4, 0, '32 Kim Cương', 0, '', 1, '2020-08-04', '2020-08-04 19:42:04'),
(29, 'phidoivox', 'vohoangnam', 4, 0, '32 Kim Cương', 0, '', 1, '2020-08-04', '2020-08-04 19:42:16'),
(30, 'phidoivox', 'vohoangnam', 4, 0, '32 Kim Cương', 0, '', 1, '2020-08-04', '2020-08-04 19:42:29'),
(31, 'phidoivox', 'vohoangnam', 1, 0, '45 Kim Cương', 0, '', 0, '2020-08-04', '2020-08-04 19:42:41'),
(32, 'phidoivox', 'vohoangnam', 3, 0, '200 Kim Cương', 0, '', 0, '2020-08-04', '2020-08-04 19:45:16'),
(33, 'phidoivox', 'vohoangnam', 4, 0, '32 Kim Cương', 0, '', 1, '2020-08-04', '2020-08-04 19:45:28'),
(34, 'phidoivox', 'vohoangnam', 4, 0, '32 Kim Cương', 0, '', 1, '2020-08-04', '2020-08-04 19:45:40'),
(35, 'phidoivox', 'vohoangnam', 1, 0, '45 Kim Cương', 0, '', 0, '2020-08-04', '2020-08-04 19:45:51'),
(36, 'phidoivox', 'vohoangnam', 4, 0, '32 Kim Cương', 0, '', 1, '2020-08-04', '2020-08-04 19:46:23'),
(37, 'phidoivox', 'vohoangnam', 3, 0, '200 Kim Cương', 0, '', 0, '2020-08-04', '2020-08-04 19:48:07'),
(38, 'phidoivox', 'vohoangnam', 4, 0, '32 Kim Cương', 0, '', 1, '2020-08-04', '2020-08-04 19:48:37'),
(39, 'phidoivox', 'vohoangnam', 4, 0, '32 Kim Cương', 0, '', 1, '2020-08-04', '2020-08-04 19:48:52'),
(40, 'phidoivox', 'vohoangnam', 4, 0, '32 Kim Cương', 0, '', 1, '2020-08-04', '2020-08-04 19:49:04'),
(41, 'phidoivox', 'vohoangnam', 4, 0, '32 Kim Cương', 0, '', 1, '2020-08-04', '2020-08-04 21:05:30'),
(42, 'phidoivox', 'vohoangnam', 4, 0, '32 Kim Cương', 0, '', 1, '2020-08-04', '2020-08-04 21:06:05'),
(43, 'phidoivox', 'vohoangnam', 1, 0, '45 Kim Cương', 0, '', 0, '2020-08-04', '2020-08-04 21:06:06'),
(44, 'phidoivox', 'vohoangnam', 1, 0, '45 Kim Cương', 0, '', 0, '2020-08-04', '2020-08-04 21:06:06'),
(45, 'phidoivox', 'vohoangnam', 4, 0, '32 Kim Cương', 0, '', 1, '2020-08-04', '2020-08-04 21:06:21'),
(46, 'phidoivox', 'vohoangnam', 4, 0, '32 Kim Cương', 0, '', 1, '2020-08-04', '2020-08-04 21:06:34'),
(47, 'phidoivox', 'vohoangnam', 1, 0, '45 Kim Cương', 0, '', 0, '2020-08-05', '2020-08-05 08:50:26'),
(48, 'phidoivox', 'vohoangnam', 4, 0, '32 Kim Cương', 0, '', 1, '2020-08-05', '2020-08-05 08:50:38'),
(49, 'phidoivox', 'vohoangnam', 5, 5149200, '400 Kim Cương', 0, '', 0, '2020-08-05', '2020-08-05 08:53:18'),
(50, 'phidoivox', 'vohoangnam', 4, 0, '32 Kim Cương', 0, '', 1, '2020-08-05', '2020-08-05 08:53:49'),
(51, 'phidoivox', 'vohoangnam', 1, 0, '45 Kim Cương', 0, '', 0, '2020-08-05', '2020-08-05 08:54:01'),
(52, 'phidoivox', 'vohoangnam', 5, 5175600, '400 Kim Cương', 0, '', 0, '2020-08-05', '2020-08-05 08:55:13'),
(53, 'phidoivox', 'vohoangnam', 4, 0, '32 Kim Cương', 0, '', 1, '2020-08-05', '2020-08-05 08:55:27'),
(54, 'phidoivox', 'vohoangnam', 1, 0, '45 Kim Cương', 0, '', 0, '2020-08-05', '2020-08-05 08:55:40'),
(55, 'phidoivox', 'vohoangnam', 5, 5202000, '400 Kim Cương', 0, '', 0, '2020-08-05', '2020-08-05 09:05:15'),
(56, 'phidoivox', 'vohoangnam', 3, 0, '200 Kim Cương', 0, '', 0, '2020-08-05', '2020-08-05 09:05:27'),
(57, 'phidoivox', 'vohoangnam', 8, 0, '6100 Kim Cương', 0, '', 0, '2020-08-05', '2020-08-05 09:05:39'),
(58, 'phidoivox', 'vohoangnam', 5, 5228400, '400 Kim Cương', 0, '', 0, '2020-08-05', '2020-08-05 09:06:11'),
(59, 'phidoivox', 'vohoangnam', 6, 0, '3000 Kim Cương', 0, '', 1, '2020-08-05', '2020-08-05 09:06:23'),
(60, 'phidoivox', 'vohoangnam', 8, 0, '6100 Kim Cương', 0, '', 0, '2020-08-05', '2020-08-05 09:06:57'),
(61, 'phidoivox', 'vohoangnam', 7, 0, '9000 Kim Cương', 0, '', 0, '2020-08-05', '2020-08-05 09:07:09'),
(62, 'phidoivox', 'vohoangnam', 7, 0, '9000 Kim Cương', 0, '', 0, '2020-08-05', '2020-08-05 09:07:21'),
(63, 'phidoivox', 'vohoangnam', 5, 5272400, '400 Kim Cương', 0, '', 0, '2020-08-05', '2020-08-05 09:07:33'),
(64, 'phidoivox', 'vohoangnam', 4, 0, '32 Kim Cương', 0, '', 1, '2020-08-05', '2020-08-05 09:08:06'),
(65, 'phidoivox', 'vohoangnam', 7, 0, '9000 Kim Cương', 0, '', 0, '2020-08-05', '2020-08-05 09:08:18'),
(66, 'phidoivox', 'vohoangnam', 5, 5298800, '400 Kim Cương', 0, '', 0, '2020-08-05', '2020-08-05 09:08:30'),
(67, 'phidoivox', 'vohoangnam', 3, 0, '200 Kim Cương', 0, '', 0, '2020-08-05', '2020-08-05 09:08:42'),
(68, 'phidoivox', 'vohoangnam', 2, 0, '11000 Kim Cương', 0, '', 0, '2020-08-05', '2020-08-05 09:08:57'),
(69, 'phidoivox', 'vohoangnam', 6, 0, '3000 Kim Cương', 0, '', 1, '2020-08-05', '2020-08-05 09:09:30'),
(70, 'phidoivox', 'vohoangnam', 4, 0, '32 Kim Cương', 0, '', 1, '2020-08-05', '2020-08-05 09:09:54'),
(71, 'phidoivox', 'vohoangnam', 4, 0, '32 Kim Cương', 0, '', 1, '2020-08-05', '2020-08-05 09:10:06'),
(72, 'phidoivox', 'vohoangnam', 4, 0, '32 Kim Cương', 0, '', 1, '2020-08-05', '2020-08-05 09:10:19'),
(73, 'phidoivox', 'vohoangnam', 5, 5360400, '400 Kim Cương', 0, '', 0, '2020-08-05', '2020-08-05 09:11:44'),
(74, 'phidoivox', 'vohoangnam', 7, 0, '9000 Kim Cương', 0, '', 0, '2020-08-05', '2020-08-05 09:11:56'),
(75, 'phidoivox', 'vohoangnam', 6, 0, '3000 Kim Cương', 0, '', 1, '2020-08-05', '2020-08-05 09:12:08'),
(76, 'phidoivox', 'vohoangnam', 8, 0, '6100 Kim Cương', 0, '', 0, '2020-08-05', '2020-08-05 09:12:20'),
(77, 'phidoivox', 'vohoangnam', 2, 0, '11000 Kim Cương', 0, '', 0, '2020-08-05', '2020-08-05 09:12:32'),
(78, 'phidoivox', 'vohoangnam', 8, 0, '6100 Kim Cương', 0, '', 0, '2020-08-05', '2020-08-05 09:12:44'),
(79, 'phidoivox', 'vohoangnam', 8, 0, '6100 Kim Cương', 0, '', 0, '2020-08-05', '2020-08-05 09:12:56'),
(80, 'phidoivox', 'vohoangnam', 4, 0, '32 Kim Cương', 0, '', 1, '2020-08-05', '2020-08-05 09:13:40'),
(81, 'phidoivox', 'vohoangnam', 8, 0, '6100 Kim Cương', 0, '', 0, '2020-08-05', '2020-08-05 09:13:40'),
(82, 'phidoivox', 'vohoangnam', 8, 0, '6100 Kim Cương', 0, '', 0, '2020-08-05', '2020-08-05 09:13:40'),
(83, 'phidoivox', 'vohoangnam', 7, 0, '9000 Kim Cương', 0, '', 0, '2020-08-05', '2020-08-05 09:13:41'),
(84, 'phidoivox', 'vohoangnam', 5, 5457200, '400 Kim Cương', 0, '', 0, '2020-08-05', '2020-08-05 09:13:41'),
(85, 'phidoivox', 'vohoangnam', 4, 0, '32 Kim Cương', 0, '', 1, '2020-08-05', '2020-08-05 09:13:41'),
(86, 'phidoivox', 'vohoangnam', 6, 0, '3000 Kim Cương', 0, '', 1, '2020-08-05', '2020-08-05 09:14:14'),
(87, 'phidoivox', 'vohoangnam', 7, 0, '9000 Kim Cương', 0, '', 0, '2020-08-05', '2020-08-05 09:14:15'),
(88, 'phidoivox', 'vohoangnam', 2, 0, '11000 Kim Cương', 0, '', 0, '2020-08-05', '2020-08-05 09:14:47'),
(89, 'phidoivox', 'vohoangnam', 8, 0, '6100 Kim Cương', 0, '', 0, '2020-08-05', '2020-08-05 09:14:59'),
(90, 'phidoivox', 'vohoangnam', 7, 0, '9000 Kim Cương', 0, '', 0, '2020-08-05', '2020-08-05 09:15:12'),
(91, 'phidoivox', 'vohoangnam', 2, 0, '11000 Kim Cương', 0, '', 0, '2020-08-05', '2020-08-05 09:18:25'),
(92, 'phidoivox', 'vohoangnam', 2, 0, '11000 Kim Cương', 0, '', 0, '2020-08-05', '2020-08-05 09:18:37'),
(93, 'phidoivox', 'vohoangnam', 2, 0, '11000 Kim Cương', 0, '', 0, '2020-08-05', '2020-08-05 09:18:50'),
(94, 'phidoivox', 'vohoangnam', 2, 0, '11000 Kim Cương', 0, '', 0, '2020-08-05', '2020-08-05 09:19:02'),
(95, 'phidoivox', 'vohoangnam', 2, 0, '11000 Kim Cương', 0, '', 0, '2020-08-05', '2020-08-05 09:19:31'),
(96, 'phidoivox', 'vohoangnam', 2, 0, '11000 Kim Cương', 0, '', 0, '2020-08-05', '2020-08-05 09:19:45'),
(97, 'phidoivox', 'vohoangnam', 2, 0, '11000 Kim Cương', 0, '', 0, '2020-08-05', '2020-08-05 09:19:57'),
(98, 'phidoivox', 'vohoangnam', 2, 0, '11000 Kim Cương', 0, '', 0, '2020-08-05', '2020-08-05 09:20:09'),
(99, 'phidoivox', 'vohoangnam', 2, 0, '11000 Kim Cương', 0, '', 0, '2020-08-05', '2020-08-05 09:20:21'),
(100, 'phidoivox', 'vohoangnam', 2, 0, '11000 Kim Cương', 0, '', 0, '2020-08-05', '2020-08-05 09:20:46'),
(101, 'phidoivox', 'vohoangnam', 2, 0, '11000 Kim Cương', 0, '', 0, '2020-08-05', '2020-08-05 09:20:58'),
(102, 'phidoivox', 'vohoangnam', 2, 0, '11000 Kim Cương', 0, '', 0, '2020-08-05', '2020-08-05 09:21:12'),
(103, 'phidoivox', 'vohoangnam', 2, 0, '11000 Kim Cương', 0, '', 0, '2020-08-05', '2020-08-05 09:21:24'),
(104, 'phidoivox', 'vohoangnam', 2, 0, '11000 Kim Cương', 0, '', 0, '2020-08-05', '2020-08-05 09:21:38'),
(105, 'phidoivox', 'vohoangnam', 2, 0, '11000 Kim Cương', 0, '', 0, '2020-08-05', '2020-08-05 09:21:49'),
(106, 'phidoivox', 'vohoangnam', 2, 0, '11000 Kim Cương', 0, '', 0, '2020-08-05', '2020-08-05 09:22:01'),
(107, 'phidoivox', 'vohoangnam', 2, 0, '11000 Kim Cương', 0, '', 0, '2020-08-05', '2020-08-05 09:22:14'),
(108, 'phidoivox', 'vohoangnam', 2, 0, '11000 Kim Cương', 0, '', 0, '2020-08-05', '2020-08-05 09:22:26'),
(109, 'phidoivox', 'vohoangnam', 2, 0, '11000 Kim Cương', 0, '', 0, '2020-08-05', '2020-08-05 09:22:39'),
(110, 'phidoivox', 'vohoangnam', 2, 0, '11000 Kim Cương', 0, '', 0, '2020-08-05', '2020-08-05 09:22:51'),
(111, 'phidoivox', 'vohoangnam', 2, 0, '11000 Kim Cương', 0, '', 0, '2020-08-05', '2020-08-05 09:23:18'),
(112, 'phidoivox', 'vohoangnam', 2, 0, '11000 Kim Cương', 0, '', 0, '2020-08-05', '2020-08-05 09:23:30'),
(113, 'phidoivox', 'vohoangnam', 4, 0, '32 Kim Cương', 0, '', 1, '2020-08-05', '2020-08-05 09:24:20'),
(114, 'phidoivox', 'vohoangnam', 4, 0, '32 Kim Cương', 0, '', 1, '2020-08-05', '2020-08-05 09:24:32'),
(115, 'phidoivox', 'vohoangnam', 8, 0, '6100 Kim Cương', 0, '', 0, '2020-08-05', '2020-08-05 09:26:04'),
(116, 'phidoivox', 'vohoangnam', 3, 0, '200 Kim Cương', 0, '', 0, '2020-08-05', '2020-08-05 09:27:00'),
(117, 'phidoivox', 'vohoangnam', 4, 0, '32 Kim Cương', 0, '', 1, '2020-08-05', '2020-08-05 09:27:39'),
(118, 'phidoivox', 'vohoangnam', 8, 0, '6100 Kim Cương', 0, '', 0, '2020-08-05', '2020-08-05 09:27:54'),
(119, 'phidoivox', 'vohoangnam', 5, 2147483647, '400 Kim Cương', 0, '', 0, '2020-08-05', '2020-08-05 09:28:07'),
(120, 'phidoivox', 'vohoangnam', 8, 0, '6100 Kim Cương', 0, '', 0, '2020-08-05', '2020-08-05 09:28:44'),
(121, 'phidoivox', 'vohoangnam', 2, 0, '11000 Kim Cương', 0, '', 0, '2020-08-05', '2020-08-05 09:28:59'),
(122, 'phidoivox', 'vohoangnam', 3, 0, '200 Kim Cương', 0, '', 0, '2020-08-05', '2020-08-05 09:29:12'),
(123, 'phidoivox', 'vohoangnam', 8, 0, '6100 Kim Cương', 0, '', 0, '2020-08-05', '2020-08-05 09:29:25'),
(124, 'phidoivox', 'vohoangnam', 4, 0, '32 Kim Cương', 0, '', 1, '2020-08-05', '2020-08-05 09:29:37'),
(125, 'phidoivox', 'vohoangnam', 2, 0, '11000 Kim Cương', 0, '', 0, '2020-08-05', '2020-08-05 09:30:13'),
(126, 'phidoivox', 'vohoangnam', 3, 0, '200 Kim Cương', 0, '', 0, '2020-08-05', '2020-08-05 09:30:26'),
(127, 'phidoivox', 'vohoangnam', 4, 0, '32 Kim Cương', 0, '', 1, '2020-08-05', '2020-08-05 09:30:38'),
(128, 'phidoivox', 'vohoangnam', 4, 0, '32 Kim Cương', 0, '', 1, '2020-08-05', '2020-08-05 09:30:51'),
(129, 'phidoivox', 'vohoangnam', 8, 0, '6100 Kim Cương', 0, '', 0, '2020-08-05', '2020-08-05 09:31:03'),
(130, 'phidoivox', 'vohoangnam', 1, 0, '45 Kim Cương', 0, '', 0, '2020-08-05', '2020-08-05 09:31:15'),
(131, 'phidoivox', 'vohoangnam', 8, 0, '6100 Kim Cương', 0, '', 0, '2020-08-05', '2020-08-05 09:31:30'),
(132, 'phidoivox', 'vohoangnam', 4, 0, '32 Kim Cương', 0, '', 1, '2020-08-05', '2020-08-05 09:33:05'),
(133, 'phidoivox', 'vohoangnam', 7, 0, '9000 Kim Cương', 0, '', 0, '2020-08-05', '2020-08-05 09:33:17'),
(134, 'phidoivox', 'vohoangnam', 1, 0, '45 Kim Cương', 0, '', 0, '2020-08-05', '2020-08-05 09:33:29'),
(135, 'phidoivox', 'vohoangnam', 4, 0, '32 Kim Cương', 0, '', 1, '2020-08-05', '2020-08-05 09:33:41'),
(136, 'phidoivox', 'vohoangnam', 7, 0, '9000 Kim Cương', 0, '', 0, '2020-08-05', '2020-08-05 09:33:57'),
(137, 'phidoivox', 'vohoangnam', 4, 0, '32 Kim Cương', 0, '', 1, '2020-08-05', '2020-08-05 09:34:09'),
(138, 'phidoivox', 'vohoangnam', 3, 0, '200 Kim Cương', 0, '', 0, '2020-08-05', '2020-08-05 09:34:21'),
(139, 'phidoivox', 'vohoangnam', 4, 0, '32 Kim Cương', 0, '', 1, '2020-08-05', '2020-08-05 09:34:33'),
(140, 'phidoivox', 'vohoangnam', 8, 0, '6100 Kim Cương', 0, '', 0, '2020-08-05', '2020-08-05 09:34:45'),
(141, 'phidoivox', 'vohoangnam', 7, 0, '9000 Kim Cương', 0, '', 0, '2020-08-05', '2020-08-05 09:34:57'),
(142, 'phidoivox', 'vohoangnam', 5, 2147483647, '400 Kim Cương', 0, '', 0, '2020-08-05', '2020-08-05 09:35:09'),
(143, 'phidoivox', 'vohoangnam', 4, 0, '32 Kim Cương', 0, '', 1, '2020-08-05', '2020-08-05 09:35:22'),
(144, 'phidoivox', 'vohoangnam', 4, 0, '32 Kim Cương', 0, '', 1, '2020-08-05', '2020-08-05 09:35:34'),
(145, 'phidoivox', 'vohoangnam', 1, 0, '45 Kim Cương', 0, '', 0, '2020-08-05', '2020-08-05 09:35:51'),
(146, 'phidoivox', 'vohoangnam', 3, 0, '200 Kim Cương', 0, '', 0, '2020-08-05', '2020-08-05 17:19:42'),
(147, 'phidoivox', 'vohoangnam', 2, 0, '11000 Kim Cương', 0, '', 0, '2020-08-05', '2020-08-05 17:19:54'),
(148, 'phidoivox', 'vohoangnam', 4, 0, '32 Kim Cương', 0, '', 1, '2020-08-05', '2020-08-05 17:20:08'),
(149, 'phidoivox', 'vohoangnam', 8, 0, '6100 Kim Cương', 0, '', 0, '2020-08-05', '2020-08-05 17:20:25'),
(150, 'phidoivox', 'vohoangnam', 2, 0, '11000 Kim Cương', 0, '', 0, '2020-08-05', '2020-08-05 17:20:37'),
(151, 'phidoivox', 'vohoangnam', 4, 0, '32 Kim Cương', 0, '', 1, '2020-08-05', '2020-08-05 17:20:50'),
(152, 'phidoivox', 'vohoangnam', 5, 2147483647, '400 Kim Cương', 0, '', 0, '2020-08-05', '2020-08-05 17:21:02'),
(153, 'phidoivox', 'vohoangnam', 3, 0, '200 Kim Cương', 0, '', 0, '2020-08-05', '2020-08-05 17:21:14'),
(154, 'phidoivox', 'vohoangnam', 4, 0, '32 Kim Cương', 0, '', 1, '2020-08-05', '2020-08-05 17:21:41'),
(155, 'phidoivox', 'vohoangnam', 2, 0, '11000 Kim Cương', 0, '', 0, '2020-08-05', '2020-08-05 17:24:28'),
(156, 'phidoivox', 'vohoangnam', 3, 0, '200 Kim Cương', 0, '', 0, '2020-08-05', '2020-08-05 17:24:41'),
(157, 'phidoivox', 'vohoangnam', 3, 0, '200 Kim Cương', 0, '', 0, '2020-08-05', '2020-08-05 17:25:04'),
(158, 'phidoivox', 'vohoangnam', 2, 0, '11000 Kim Cương', 0, '', 0, '2020-08-05', '2020-08-05 17:26:08'),
(159, 'phidoivox', 'vohoangnam', 2, 0, '11000 Kim Cương', 0, '', 0, '2020-08-05', '2020-08-05 17:26:21'),
(160, 'phidoivox', 'vohoangnam', 2, 0, '11000 Kim Cương', 0, '', 0, '2020-08-05', '2020-08-05 17:27:26'),
(161, 'phidoivox', 'vohoangnam', 2, 0, '11000 Kim Cương', 0, '', 0, '2020-08-05', '2020-08-05 17:27:52'),
(162, 'phidoivox', 'vohoangnam', 2, 0, '11000 Kim Cương', 0, '', 0, '2020-08-05', '2020-08-05 17:28:12'),
(163, 'phidoivox', 'vohoangnam', 2, 0, '11000 Kim Cương', 0, '', 0, '2020-08-05', '2020-08-05 17:28:47'),
(164, 'phidoivox', 'vohoangnam', 2, 0, '11000 Kim Cương', 0, '', 0, '2020-08-05', '2020-08-05 17:29:01'),
(165, 'phidoivox', 'vohoangnam', 2, 0, '11000 Kim Cương', 0, '', 0, '2020-08-05', '2020-08-05 17:34:28'),
(166, 'phidoivox', 'vohoangnam', 2, 0, '11000 Kim Cương', 0, '', 0, '2020-08-05', '2020-08-05 17:34:41'),
(167, 'phidoivox', 'vohoangnam', 2, 0, '11000 Kim Cương', 0, '', 0, '2020-08-05', '2020-08-05 17:35:40'),
(168, 'phidoivox', 'vohoangnam', 2, 0, '11000 Kim Cương', 0, '', 0, '2020-08-05', '2020-08-05 17:35:59'),
(169, 'phidoivox', 'vohoangnam', 2, 0, '11000 Kim Cương', 0, '', 0, '2020-08-05', '2020-08-05 17:36:12'),
(170, 'phidoivox', 'vohoangnam', 2, 0, '11000 Kim Cương', 0, '', 0, '2020-08-05', '2020-08-05 17:37:07'),
(171, 'phidoivox', 'vohoangnam', 8, 0, '6100 Kim Cương', 0, '', 0, '2020-08-05', '2020-08-05 17:57:42'),
(172, 'phidoivox', 'vohoangnam', 6, 0, '3000 Kim Cương', 0, '', 1, '2020-08-05', '2020-08-05 18:04:47'),
(173, 'phidoivox', 'vohoangnam', 8, 0, '6100 Kim Cương', 0, '', 0, '2020-08-05', '2020-08-05 18:04:59'),
(174, 'phidoivox', 'vohoangnam', 4, 0, '32 Kim Cương', 0, '', 1, '2020-08-05', '2020-08-05 18:05:10'),
(175, 'phidoivox', 'vohoangnam', 8, 0, '6100 Kim Cương', 0, '', 0, '2020-08-05', '2020-08-05 18:09:51'),
(176, 'phidoivox', 'vohoangnam', 5, 580664, '400 Kim Cương', 0, '', 0, '2020-08-05', '2020-08-05 18:10:22'),
(177, 'phidoivox', 'vohoangnam', 5, 596664, '400 Kim Cương', 0, '', 0, '2020-08-05', '2020-08-05 18:10:22'),
(178, 'phidoivox', 'vohoangnam', 2, 0, '11000 Kim Cương', 0, '', 0, '2020-08-05', '2020-08-05 18:38:41'),
(179, 'phidoivox', 'vohoangnam', 4, 0, '32 Kim Cương', 0, '', 1, '2020-08-05', '2020-08-05 18:39:25'),
(180, 'phidoivox', 'vohoangnam', 7, 0, '9000 Kim Cương', 0, '', 0, '2020-08-05', '2020-08-05 18:40:50'),
(181, 'phidoivox', 'vohoangnam', 4, 0, '32 Kim Cương', 0, '', 1, '2020-08-05', '2020-08-05 18:41:02'),
(182, 'phidoivox', 'vohoangnam', 4, 0, '32 Kim Cương', 0, '', 1, '2020-08-05', '2020-08-05 18:41:19'),
(183, 'phidoivox', 'vohoangnam', 2, 0, '11000 Kim Cương', 0, '', 0, '2020-08-05', '2020-08-05 19:24:10'),
(184, 'phidoivox', 'vohoangnam', 2, 0, '11000 Kim Cương', 0, '', 0, '2020-08-05', '2020-08-05 19:25:06'),
(185, 'phidoivox', 'vohoangnam', 2, 0, '11000 Kim Cương', 0, '', 0, '2020-08-05', '2020-08-05 19:31:55'),
(186, 'phidoivox', 'vohoangnam', 2, 0, '11000 Kim Cương', 0, '', 0, '2020-08-05', '2020-08-05 19:32:16'),
(187, 'namhoai221100', 'Namhoài', 1, 0, '45 Kim Cương', 0, '', 0, '2020-08-05', '2020-08-05 22:27:26'),
(188, 'namhoai221100', 'Namhoài', 4, 0, '32 Kim Cương', 0, '', 1, '2020-08-05', '2020-08-05 22:27:39'),
(189, 'phidoivox', 'vohoangnam', 7, 0, '9000 Kim Cương', 0, '', 0, '2020-08-05', '2020-08-05 23:10:52'),
(190, 'phidoivox', 'vohoangnam', 2, 0, '11000 Kim Cương', 0, '', 0, '2020-08-05', '2020-08-05 23:11:04'),
(191, 'phidoivox', 'vohoangnam', 5, 820664, '400 Kim Cương', 0, '', 0, '2020-08-05', '2020-08-05 23:11:16'),
(192, 'phidoivox', 'vohoangnam', 1, 0, '45 Kim Cương', 0, '', 0, '2020-08-05', '2020-08-05 23:11:30'),
(193, 'duongdz', 'Trịnh Quang Hung', 8, 0, '6100 Kim Cương', 0, '', 0, '2020-08-06', '2020-08-06 07:11:47'),
(194, 'phidoivox', 'vohoangnam', 8, 0, '6100 Kim Cương', 0, '', 0, '2020-08-06', '2020-08-06 07:11:54'),
(195, 'duongdz', 'Trịnh Quang Hung', 7, 0, '9000 Kim Cương', 0, '', 0, '2020-08-06', '2020-08-06 07:12:00'),
(196, 'phidoivox', 'vohoangnam', 6, 0, '3000 Kim Cương', 0, '', 1, '2020-08-06', '2020-08-06 07:12:06'),
(197, 'phidoivox', 'vohoangnam', 4, 0, '32 Kim Cương', 0, '', 1, '2020-08-06', '2020-08-06 07:12:21'),
(198, 'duongdz', 'Trịnh Quang Hung', 3, 0, '200 Kim Cương', 0, '', 0, '2020-08-06', '2020-08-06 07:12:23'),
(199, 'phidoivox', 'vohoangnam', 7, 0, '9000 Kim Cương', 0, '', 0, '2020-08-06', '2020-08-06 07:12:51'),
(200, 'phidoivox', 'vohoangnam', 5, 964664, '400 Kim Cương', 0, '', 0, '2020-08-06', '2020-08-06 07:13:03'),
(201, 'phidoivox', 'vohoangnam', 8, 0, '6100 Kim Cương', 0, '', 0, '2020-08-06', '2020-08-06 07:13:15'),
(202, 'phidoivox', 'vohoangnam', 5, 996664, '400 Kim Cương', 0, '', 0, '2020-08-06', '2020-08-06 07:13:27'),
(203, 'phidoivox', 'vohoangnam', 8, 0, '6100 Kim Cương', 0, '', 0, '2020-08-06', '2020-08-06 07:13:52'),
(204, 'phidoivox', 'vohoangnam', 6, 0, '3000 Kim Cương', 0, '', 1, '2020-08-06', '2020-08-06 07:14:05'),
(205, 'duongdz', 'Trịnh Quang Hung', 6, 0, '3000 Kim Cương', 0, '', 1, '2020-08-06', '2020-08-06 07:14:14'),
(206, 'phidoivox', 'vohoangnam', 3, 0, '200 Kim Cương', 0, '', 0, '2020-08-06', '2020-08-06 07:14:18'),
(207, 'phidoivox', 'vohoangnam', 4, 0, '32 Kim Cương', 0, '', 1, '2020-08-06', '2020-08-06 07:14:30'),
(208, 'duongdz', 'Trịnh Quang Hung', 3, 0, '200 Kim Cương', 0, '', 0, '2020-08-06', '2020-08-06 07:19:02'),
(209, 'phidoivox', 'vohoangnam', 2, 0, '11000 Kim Cương', 0, '', 0, '2020-08-06', '2020-08-06 07:20:14'),
(210, 'phidoivox', 'vohoangnam', 3, 0, '200 Kim Cương', 0, '', 0, '2020-08-06', '2020-08-06 07:20:14'),
(211, 'phidoivox', 'vohoangnam', 2, 0, '11000 Kim Cương', 0, '', 0, '2020-08-06', '2020-08-06 07:20:14'),
(212, 'phidoivox', 'vohoangnam', 3, 0, '200 Kim Cương', 0, '', 0, '2020-08-06', '2020-08-06 07:20:27'),
(213, 'duongdz', 'Trịnh Quang Hung', 2, 0, '11000 Kim Cương', 0, '', 0, '2020-08-06', '2020-08-06 07:20:35'),
(214, 'phidoivox', 'vohoangnam', 4, 0, '32 Kim Cương', 0, '', 1, '2020-08-06', '2020-08-06 07:20:38'),
(215, 'phidoivox', 'vohoangnam', 5, 1204664, '400 Kim Cương', 0, '', 0, '2020-08-06', '2020-08-06 07:20:50'),
(216, 'phidoivox', 'vohoangnam', 2, 0, '11000 Kim Cương', 0, '', 0, '2020-08-06', '2020-08-06 07:21:03'),
(217, 'duongdz', 'Trịnh Quang Hung', 4, 0, '32 Kim Cương', 0, '', 1, '2020-08-06', '2020-08-06 07:21:38'),
(218, 'duongdz', 'Trịnh Quang Hung', 1, 0, '45 Kim Cương', 0, '', 0, '2020-08-06', '2020-08-06 07:22:02'),
(219, 'duongdz', 'Trịnh Quang Hung', 5, 1268664, '400 Kim Cương', 0, '', 0, '2020-08-06', '2020-08-06 07:22:22'),
(220, 'duongdz', 'Trịnh Quang Hung', 6, 0, '3000 Kim Cương', 0, '', 1, '2020-08-06', '2020-08-06 07:23:21'),
(221, 'duongdz', 'Trịnh Quang Hung', 8, 0, '6100 Kim Cương', 0, '', 0, '2020-08-06', '2020-08-06 07:23:56'),
(222, 'duongdz', 'Trịnh Quang Hung', 8, 0, '6100 Kim Cương', 0, '', 0, '2020-08-06', '2020-08-06 07:24:38'),
(223, 'duongdz', 'Trịnh Quang Hung', 2, 0, '11000 Kim Cương', 0, '', 0, '2020-08-06', '2020-08-06 07:24:52'),
(224, 'duongdz', 'Trịnh Quang Hung', 1, 0, '45 Kim Cương', 0, '', 0, '2020-08-06', '2020-08-06 08:15:18'),
(225, 'duongdz', 'Trịnh Quang Hung', 1, 0, '45 Kim Cương', 0, '', 0, '2020-08-06', '2020-08-06 08:15:30'),
(226, 'duongdz', 'Trịnh Quang Hung', 5, 1380664, '400 Kim Cương', 0, '', 0, '2020-08-06', '2020-08-06 08:15:42'),
(227, 'duongdz', 'Trịnh Quang Hung', 5, 1396664, '400 Kim Cương', 0, '', 0, '2020-08-06', '2020-08-06 08:52:23'),
(228, 'duongdz', 'Trịnh Quang Hung', 3, 0, '200 Kim Cương', 0, '', 0, '2020-08-06', '2020-08-06 08:52:27'),
(229, 'duongdz', 'Trịnh Quang Hung', 4, 0, '32 Kim Cương', 0, '', 1, '2020-08-06', '2020-08-06 08:52:50'),
(230, 'duongdz', 'Trịnh Quang Hung', 7, 0, '9000 Kim Cương', 0, '', 0, '2020-08-06', '2020-08-06 08:53:04'),
(231, 'duongdz', 'Trịnh Quang Hung', 5, 1460664, '400 Kim Cương', 0, '', 0, '2020-08-06', '2020-08-06 08:53:09'),
(232, 'duongdz', 'Trịnh Quang Hung', 4, 0, '32 Kim Cương', 0, '', 1, '2020-08-06', '2020-08-06 08:53:09'),
(233, 'duongdz', 'Trịnh Quang Hung', 8, 0, '6100 Kim Cương', 0, '', 0, '2020-08-06', '2020-08-06 08:53:12'),
(234, 'duongdz', 'Trịnh Quang Hung', 8, 0, '6100 Kim Cương', 0, '', 0, '2020-08-06', '2020-08-06 08:54:02'),
(235, 'duongdz', 'Trịnh Quang Hung', 8, 0, '6100 Kim Cương', 0, '', 0, '2020-08-06', '2020-08-06 08:54:21'),
(236, 'duongdz', 'Trịnh Quang Hung', 4, 0, '32 Kim Cương', 0, '', 1, '2020-08-06', '2020-08-06 08:54:33'),
(237, 'duongdz', 'Trịnh Quang Hung', 2, 0, '11000 Kim Cương', 0, '', 0, '2020-08-06', '2020-08-06 08:54:45'),
(238, 'duongdz', 'Trịnh Quang Hung', 8, 0, '6100 Kim Cương', 0, '', 0, '2020-08-06', '2020-08-06 08:54:58'),
(239, 'duongdz', 'Trịnh Quang Hung', 2, 0, '11000 Kim Cương', 0, '', 0, '2020-08-06', '2020-08-06 08:55:09'),
(240, 'duongdz', 'Trịnh Quang Hung', 4, 0, '32 Kim Cương', 0, '', 1, '2020-08-06', '2020-08-06 08:55:22'),
(241, 'duongdz', 'Trịnh Quang Hung', 2, 0, '11000 Kim Cương', 0, '', 0, '2020-08-06', '2020-08-06 08:55:34'),
(242, 'duongdz', 'Trịnh Quang Hung', 3, 0, '200 Kim Cương', 0, '', 0, '2020-08-06', '2020-08-06 08:55:46'),
(243, 'duongdz', 'Trịnh Quang Hung', 5, 1652664, '400 Kim Cương', 0, '', 0, '2020-08-06', '2020-08-06 08:55:58'),
(244, 'duongdz', 'Trịnh Quang Hung', 8, 0, '6100 Kim Cương', 0, '', 0, '2020-08-06', '2020-08-06 08:56:11'),
(245, 'duongdz', 'Trịnh Quang Hung', 7, 0, '9000 Kim Cương', 0, '', 0, '2020-08-06', '2020-08-06 08:56:56'),
(246, 'duongdz', 'Trịnh Quang Hung', 1, 0, '45 Kim Cương', 0, '', 0, '2020-08-06', '2020-08-06 08:57:08'),
(247, 'duongdz', 'Trịnh Quang Hung', 2, 0, '11000 Kim Cương', 0, '', 0, '2020-08-06', '2020-08-06 08:57:20'),
(248, 'duongdz', 'Trịnh Quang Hung', 7, 0, '9000 Kim Cương', 0, '', 0, '2020-08-06', '2020-08-06 08:57:32'),
(249, 'duongdz', 'Trịnh Quang Hung', 8, 0, '6100 Kim Cương', 0, '', 0, '2020-08-06', '2020-08-06 08:57:46'),
(250, 'duongdz', 'Trịnh Quang Hung', 6, 0, '3000 Kim Cương', 0, '', 1, '2020-08-06', '2020-08-06 08:58:01'),
(251, 'duongdz', 'Trịnh Quang Hung', 7, 0, '9000 Kim Cương', 0, '', 0, '2020-08-06', '2020-08-06 08:58:13'),
(252, 'duongdz', 'Trịnh Quang Hung', 3, 0, '200 Kim Cương', 0, '', 0, '2020-08-06', '2020-08-06 08:58:25'),
(253, 'duongdz', 'Trịnh Quang Hung', 1, 0, '45 Kim Cương', 0, '', 0, '2020-08-06', '2020-08-06 08:58:38'),
(254, 'duongdz', 'Trịnh Quang Hung', 1, 0, '45 Kim Cương', 0, '', 0, '2020-08-06', '2020-08-06 08:58:50'),
(255, 'duongdz', 'Trịnh Quang Hung', 1, 0, '45 Kim Cương', 0, '', 0, '2020-08-06', '2020-08-06 08:59:01'),
(256, 'duongdz', 'Trịnh Quang Hung', 2, 0, '11000 Kim Cương', 0, '', 0, '2020-08-06', '2020-08-06 08:59:13'),
(257, 'duongdz', 'Trịnh Quang Hung', 2, 0, '11000 Kim Cương', 0, '', 0, '2020-08-06', '2020-08-06 08:59:25'),
(258, 'duongdz', 'Trịnh Quang Hung', 6, 0, '3000 Kim Cương', 0, '', 1, '2020-08-06', '2020-08-06 08:59:40'),
(259, 'duongdz', 'Trịnh Quang Hung', 6, 0, '3000 Kim Cương', 0, '', 1, '2020-08-06', '2020-08-06 08:59:52'),
(260, 'duongdz', 'Trịnh Quang Hung', 8, 0, '6100 Kim Cương', 0, '', 0, '2020-08-06', '2020-08-06 09:00:04'),
(261, 'duongdz', 'Trịnh Quang Hung', 4, 0, '32 Kim Cương', 0, '', 1, '2020-08-06', '2020-08-06 09:07:21'),
(262, 'duongdz', 'Trịnh Quang Hung', 5, 1956664, '400 Kim Cương', 0, '', 0, '2020-08-06', '2020-08-06 09:07:36'),
(263, 'duongdz', 'Trịnh Quang Hung', 3, 0, '200 Kim Cương', 0, '', 0, '2020-08-06', '2020-08-06 09:07:50'),
(264, 'duongdz', 'Trịnh Quang Hung', 1, 0, '45 Kim Cương', 0, '', 0, '2020-08-06', '2020-08-06 09:08:03'),
(265, 'duongdz', 'Trịnh Quang Hung', 2, 0, '11000 Kim Cương', 0, '', 0, '2020-08-06', '2020-08-06 09:08:16'),
(266, 'duongdz', 'Trịnh Quang Hung', 2, 0, '11000 Kim Cương', 0, '', 0, '2020-08-06', '2020-08-06 09:08:29'),
(267, 'phidoivox', 'vohoangnam', 2, 0, '11000 Kim Cương', 0, '', 0, '2020-08-06', '2020-08-06 09:08:30'),
(268, 'duongdz', 'Trịnh Quang Hung', 2, 0, '11000 Kim Cương', 0, '', 0, '2020-08-06', '2020-08-06 09:08:41'),
(269, 'phidoivox', 'vohoangnam', 2, 0, '11000 Kim Cương', 0, '', 0, '2020-08-06', '2020-08-06 09:08:43'),
(270, 'duongdz', 'Trịnh Quang Hung', 2, 0, '11000 Kim Cương', 0, '', 0, '2020-08-06', '2020-08-06 09:08:53'),
(271, 'phidoivox', 'vohoangnam', 2, 0, '11000 Kim Cương', 0, '', 0, '2020-08-06', '2020-08-06 09:08:55'),
(272, 'duongdz', 'Trịnh Quang Hung', 4, 0, '32 Kim Cương', 0, '', 1, '2020-08-06', '2020-08-06 09:09:29'),
(273, 'phidoivox', 'vohoangnam', 4, 0, '32 Kim Cương', 0, '', 1, '2020-08-06', '2020-08-06 09:09:51'),
(274, 'duongdz', 'Trịnh Quang Hung', 4, 0, '32 Kim Cương', 0, '', 1, '2020-08-06', '2020-08-06 09:10:01'),
(275, 'phidoivox', 'vohoangnam', 2, 0, '11000 Kim Cương', 0, '', 0, '2020-08-06', '2020-08-06 09:11:17'),
(276, 'phidoivox', 'vohoangnam', 2, 0, '11000 Kim Cương', 0, '', 0, '2020-08-06', '2020-08-06 09:11:30'),
(277, 'phidoivox', 'vohoangnam', 2, 0, '11000 Kim Cương', 0, '', 0, '2020-08-06', '2020-08-06 09:11:42'),
(278, 'phidoivox', 'vohoangnam', 2, 0, '11000 Kim Cương', 0, '', 0, '2020-08-06', '2020-08-06 09:11:54'),
(279, 'phidoivox', 'vohoangnam', 2, 0, '11000 Kim Cương', 0, '', 0, '2020-08-06', '2020-08-06 09:12:07'),
(280, 'duongdz', 'Trịnh Quang Hung', 2, 0, '11000 Kim Cương', 0, '', 0, '2020-08-06', '2020-08-06 09:12:35'),
(281, 'duongdz', 'Trịnh Quang Hung', 2, 0, '11000 Kim Cương', 0, '', 0, '2020-08-06', '2020-08-06 09:12:47'),
(282, 'duongdz', 'Trịnh Quang Hung', 2, 0, '11000 Kim Cương', 0, '', 0, '2020-08-06', '2020-08-06 09:12:49'),
(283, 'duongdz', 'Trịnh Quang Hung', 2, 0, '11000 Kim Cương', 0, '', 0, '2020-08-06', '2020-08-06 09:13:58'),
(284, 'duongdz', 'Trịnh Quang Hung', 2, 0, '11000 Kim Cương', 0, '', 0, '2020-08-06', '2020-08-06 09:14:25'),
(285, 'duongdz', 'Trịnh Quang Hung', 2, 0, '11000 Kim Cương', 0, '', 0, '2020-08-06', '2020-08-06 09:15:01'),
(286, 'phidoivox', 'vohoangnam', 2, 0, '11000 Kim Cương', 0, '', 0, '2020-08-06', '2020-08-06 09:15:18'),
(287, 'duongdz', 'Trịnh Quang Hung', 2, 0, '11000 Kim Cương', 0, '', 0, '2020-08-06', '2020-08-06 09:16:16'),
(288, 'phidoivox', 'vohoangnam', 2, 0, '11000 Kim Cương', 0, '', 0, '2020-08-06', '2020-08-06 09:16:18'),
(289, 'duongdz', 'Trịnh Quang Hung', 2, 0, '11000 Kim Cương', 0, '', 0, '2020-08-06', '2020-08-06 09:16:19'),
(290, 'duongdz', 'Trịnh Quang Hung', 2, 0, '11000 Kim Cương', 0, '', 0, '2020-08-06', '2020-08-06 09:16:21'),
(291, 'duongdz', 'Trịnh Quang Hung', 2, 0, '11000 Kim Cương', 0, '', 0, '2020-08-06', '2020-08-06 09:16:34'),
(292, 'duongdz', 'Trịnh Quang Hung', 2, 0, '11000 Kim Cương', 0, '', 0, '2020-08-06', '2020-08-06 09:16:51'),
(293, 'duongdz', 'Trịnh Quang Hung', 3, 0, '200 Kim Cương', 0, '', 0, '2020-08-06', '2020-08-06 09:17:05'),
(294, 'duongdz', 'Trịnh Quang Hung', 7, 0, '9000 Kim Cương', 0, '', 0, '2020-08-06', '2020-08-06 09:17:17'),
(295, 'duongdz', 'Trịnh Quang Hung', 7, 0, '9000 Kim Cương', 0, '', 0, '2020-08-06', '2020-08-06 09:17:32'),
(296, 'phidoivox', 'vohoangnam', 4, 0, '32 Kim Cương', 0, '', 1, '2020-08-06', '2020-08-06 09:17:33'),
(297, 'phidoivox', 'vohoangnam', 1, 0, '45 Kim Cương', 0, '', 0, '2020-08-06', '2020-08-06 09:17:54'),
(298, 'duongdz', 'Trịnh Quang Hung', 6, 0, '3000 Kim Cương', 0, '', 1, '2020-08-06', '2020-08-06 09:17:56'),
(299, 'phidoivox', 'vohoangnam', 5, 82254264, '400 Kim Cương', 0, '', 0, '2020-08-06', '2020-08-06 09:18:06'),
(300, 'duongdz', 'Trịnh Quang Hung', 6, 0, '3000 Kim Cương', 0, '', 1, '2020-08-06', '2020-08-06 09:18:08'),
(301, 'duongdz', 'Trịnh Quang Hung', 7, 0, '9000 Kim Cương', 0, '', 0, '2020-08-06', '2020-08-06 09:18:20'),
(302, 'phidoivox', 'vohoangnam', 1, 0, '45 Kim Cương', 0, '', 0, '2020-08-06', '2020-08-06 09:18:20'),
(303, 'duongdz', 'Trịnh Quang Hung', 2, 0, '11000 Kim Cương', 0, '', 0, '2020-08-06', '2020-08-06 09:18:33'),
(304, 'duongdz', 'Trịnh Quang Hung', 3, 0, '200 Kim Cương', 0, '', 0, '2020-08-06', '2020-08-06 09:18:59'),
(305, 'phidoivox', 'vohoangnam', 5, 82259064, '400 Kim Cương', 0, '', 0, '2020-08-06', '2020-08-06 09:19:18'),
(306, 'duongdz', 'Trịnh Quang Hung', 6, 0, '3000 Kim Cương', 0, '', 1, '2020-08-06', '2020-08-06 09:19:30'),
(307, 'phidoivox', 'vohoangnam', 7, 0, '9000 Kim Cương', 0, '', 0, '2020-08-06', '2020-08-06 09:19:41'),
(308, 'duongdz', 'Trịnh Quang Hung', 3, 0, '200 Kim Cương', 0, '', 0, '2020-08-06', '2020-08-06 09:19:53'),
(309, 'phidoivox', 'vohoangnam', 6, 0, '3000 Kim Cương', 0, '', 1, '2020-08-06', '2020-08-06 09:20:04'),
(310, 'duongdz', 'Trịnh Quang Hung', 8, 0, '6100 Kim Cương', 0, '', 0, '2020-08-06', '2020-08-06 09:20:19'),
(311, 'phidoivox', 'vohoangnam', 2, 0, '11000 Kim Cương', 0, '', 0, '2020-08-06', '2020-08-06 09:20:34'),
(312, 'duongdz', 'Trịnh Quang Hung', 2, 0, '11000 Kim Cương', 0, '', 0, '2020-08-06', '2020-08-06 09:20:54'),
(313, 'phidoivox', 'vohoangnam', 6, 0, '3000 Kim Cương', 0, '', 1, '2020-08-06', '2020-08-06 09:21:06'),
(314, 'duongdz', 'Trịnh Quang Hung', 3, 0, '200 Kim Cương', 0, '', 0, '2020-08-06', '2020-08-06 09:21:17'),
(315, 'phidoivox', 'vohoangnam', 3, 0, '200 Kim Cương', 0, '', 0, '2020-08-06', '2020-08-06 09:21:22'),
(316, 'duongdz', 'Trịnh Quang Hung', 5, 82267864, '400 Kim Cương', 0, '', 0, '2020-08-06', '2020-08-06 09:21:34'),
(317, 'duongdz', 'Trịnh Quang Hung', 6, 0, '3000 Kim Cương', 0, '', 1, '2020-08-06', '2020-08-06 09:21:37'),
(318, 'phidoivox', 'vohoangnam', 2, 0, '11000 Kim Cương', 0, '', 0, '2020-08-06', '2020-08-06 09:21:51'),
(319, 'phidoivox', 'vohoangnam', 5, 82270264, '400 Kim Cương', 0, '', 0, '2020-08-06', '2020-08-06 09:22:27'),
(320, 'duongdz', 'Trịnh Quang Hung', 8, 0, '6100 Kim Cương', 0, '', 0, '2020-08-06', '2020-08-06 09:22:39'),
(321, 'duongdz', 'Trịnh Quang Hung', 3, 0, '200 Kim Cương', 0, '', 0, '2020-08-06', '2020-08-06 09:22:40'),
(322, 'duongdz', 'Trịnh Quang Hung', 8, 0, '6100 Kim Cương', 0, '', 0, '2020-08-06', '2020-08-06 09:22:41'),
(323, 'duongdz', 'Trịnh Quang Hung', 3, 0, '200 Kim Cương', 0, '', 0, '2020-08-06', '2020-08-06 09:22:41'),
(324, 'phidoivox', 'vohoangnam', 5, 82274264, '400 Kim Cương', 0, '', 0, '2020-08-06', '2020-08-06 09:22:52'),
(325, 'duongdz', 'Trịnh Quang Hung', 7, 0, '9000 Kim Cương', 0, '', 0, '2020-08-06', '2020-08-06 09:31:43'),
(326, 'phidoivox', 'vohoangnam', 3, 0, '200 Kim Cương', 0, '', 0, '2020-08-06', '2020-08-06 13:30:47'),
(327, 'phidoivox', 'vohoangnam', 2, 0, '11000 Kim Cương', 0, '', 0, '2020-08-06', '2020-08-06 13:31:01'),
(328, 'phidoivox', 'vohoangnam', 5, 82323064, '400 Kim Cương', 0, '', 0, '2020-08-06', '2020-08-06 13:34:53'),
(329, 'phidoivox', 'vohoangnam', 3, 0, '200 Kim Cương', 0, '', 0, '2020-08-06', '2020-08-06 13:35:07'),
(330, 'duongdz', 'Trịnh Quang Hung', 8, 0, '6100 Kim Cương', 0, '', 0, '2020-08-06', '2020-08-06 14:49:44'),
(331, 'phidoivox', 'vohoangnam', 8, 0, '6100 Kim Cương', 0, '', 0, '2020-08-06', '2020-08-06 17:24:20'),
(332, 'phidoivox', 'vohoangnam', 6, 0, '3000 Kim Cương', 0, '', 1, '2020-08-06', '2020-08-06 17:26:37'),
(333, 'phidoivox', 'vohoangnam', 8, 0, '6100 Kim Cương', 0, '', 0, '2020-08-06', '2020-08-06 17:28:15'),
(334, 'duongdz', 'Trịnh Quang Hung', 5, 82419064, '400 Kim Cương', 0, '', 0, '2020-08-06', '2020-08-06 18:47:15'),
(335, 'duongdz', 'Trịnh Quang Hung', 3, 0, '200 Kim Cương', 0, '', 0, '2020-08-06', '2020-08-06 18:47:27'),
(336, 'duongdz', 'Trịnh Quang Hung', 3, 0, '200 Kim Cương', 0, '', 0, '2020-08-06', '2020-08-06 18:50:13'),
(337, 'duongdz', 'Trịnh Quang Hung', 2, 0, '11000 Kim Cương', 0, '', 0, '2020-08-06', '2020-08-06 18:50:26'),
(338, 'duongdz', 'Trịnh Quang Hung', 3, 0, '200 Kim Cương', 0, '', 0, '2020-08-06', '2020-08-06 18:50:41'),
(339, 'duongdz', 'Trịnh Quang Hung', 8, 0, '6100 Kim Cương', 0, '', 0, '2020-08-06', '2020-08-06 18:50:53'),
(340, 'duongdz', 'Trịnh Quang Hung', 8, 0, '6100 Kim Cương', 0, '', 0, '2020-08-06', '2020-08-06 18:51:06'),
(341, 'duongdz', 'Trịnh Quang Hung', 3, 0, '200 Kim Cương', 0, '', 0, '2020-08-06', '2020-08-06 18:51:18'),
(342, 'phidoivox', 'vohoangnam', 7, 0, '9000 Kim Cương', 0, '', 0, '2020-08-06', '2020-08-06 20:31:44'),
(343, 'duongdz', 'Trịnh Quang Hung', 7, 0, '9000 Kim Cương', 0, '', 0, '2020-08-06', '2020-08-06 21:56:12'),
(344, 'duongdz', 'Trịnh Quang Hung', 8, 0, '6100 Kim Cương', 0, '', 0, '2020-08-06', '2020-08-06 21:56:27');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `history_wheel1`
--

CREATE TABLE `history_wheel1` (
  `id` int(11) NOT NULL,
  `username` text COLLATE utf8_unicode_ci NOT NULL,
  `name` text COLLATE utf8_unicode_ci NOT NULL,
  `type` int(11) NOT NULL DEFAULT '0',
  `nohu` int(11) NOT NULL DEFAULT '0',
  `prize` text COLLATE utf8_unicode_ci NOT NULL,
  `id_wheel` int(11) NOT NULL DEFAULT '0',
  `note` text COLLATE utf8_unicode_ci NOT NULL,
  `hide` int(11) NOT NULL DEFAULT '0',
  `date` text COLLATE utf8_unicode_ci,
  `time` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `HK_lattheff`
--

CREATE TABLE `HK_lattheff` (
  `id` int(11) NOT NULL,
  `nguoiquay` varchar(12) NOT NULL,
  `kimcuong` int(11) NOT NULL,
  `date` text NOT NULL,
  `time` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `lq_champion`
--

CREATE TABLE `lq_champion` (
  `id` int(11) NOT NULL,
  `name` text COLLATE utf8_unicode_ci NOT NULL,
  `vip` enum('yes','no') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'no',
  `img_name` text COLLATE utf8_unicode_ci NOT NULL,
  `add_time` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `lq_skin`
--

CREATE TABLE `lq_skin` (
  `id` int(11) NOT NULL,
  `name` text COLLATE utf8_unicode_ci NOT NULL,
  `vip` enum('yes','no') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'no',
  `img_name` text COLLATE utf8_unicode_ci NOT NULL,
  `add_time` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `username` text COLLATE utf8_unicode_ci NOT NULL,
  `password` text COLLATE utf8_unicode_ci NOT NULL,
  `price` int(11) NOT NULL,
  `gem_count` int(11) NOT NULL,
  `skins_count` int(11) NOT NULL,
  `skins` longtext COLLATE utf8_unicode_ci NOT NULL,
  `champs_count` int(11) NOT NULL,
  `champs` longtext COLLATE utf8_unicode_ci NOT NULL,
  `rank` int(11) NOT NULL,
  `note` longtext COLLATE utf8_unicode_ci NOT NULL,
  `type_post` int(11) NOT NULL,
  `type_account` text COLLATE utf8_unicode_ci NOT NULL,
  `date_posted` datetime NOT NULL,
  `status` int(11) NOT NULL DEFAULT '0',
  `sdt` text COLLATE utf8_unicode_ci NOT NULL,
  `cmnd` text COLLATE utf8_unicode_ci NOT NULL,
  `email` text COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `products`
--

INSERT INTO `products` (`id`, `username`, `password`, `price`, `gem_count`, `skins_count`, `skins`, `champs_count`, `champs`, `rank`, `note`, `type_post`, `type_account`, `date_posted`, `status`, `sdt`, `cmnd`, `email`) VALUES
(1, 'Daubuoi', '444444', 500000000, 4, 100, '', 100, '', 24, '', 0, 'Free Fire', '2020-08-06 09:31:44', 1, '', '', '');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `settings`
--

CREATE TABLE `settings` (
  `title` text COLLATE utf8_unicode_ci NOT NULL,
  `descr` text COLLATE utf8_unicode_ci NOT NULL,
  `keywords` text COLLATE utf8_unicode_ci NOT NULL,
  `video_home` text COLLATE utf8_unicode_ci NOT NULL,
  `fanpage` text COLLATE utf8_unicode_ci NOT NULL,
  `fb_admin` text COLLATE utf8_unicode_ci NOT NULL,
  `name_admin` text COLLATE utf8_unicode_ci NOT NULL,
  `phone_admin` text COLLATE utf8_unicode_ci NOT NULL,
  `email_admin` text COLLATE utf8_unicode_ci NOT NULL,
  `notify` longtext COLLATE utf8_unicode_ci NOT NULL,
  `domain` text COLLATE utf8_unicode_ci NOT NULL,
  `status` int(11) NOT NULL,
  `status_random` int(11) NOT NULL,
  `rd_1` int(11) NOT NULL,
  `rd_2` int(11) NOT NULL,
  `rd_3` int(11) NOT NULL,
  `rd_4` int(11) NOT NULL,
  `rd_5` int(11) NOT NULL DEFAULT '0',
  `rd_6` int(11) NOT NULL DEFAULT '0',
  `rd_7` int(11) NOT NULL DEFAULT '0',
  `rd_8` int(11) NOT NULL DEFAULT '0',
  `rd_9` int(11) NOT NULL DEFAULT '0',
  `rd_10` int(11) NOT NULL DEFAULT '0',
  `rd_11` int(11) NOT NULL DEFAULT '0',
  `rd_12` int(11) NOT NULL DEFAULT '0',
  `rd_13` int(11) NOT NULL DEFAULT '0',
  `rd_14` int(11) NOT NULL DEFAULT '0',
  `rd_15` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `settings`
--

INSERT INTO `settings` (`title`, `descr`, `keywords`, `video_home`, `fanpage`, `fb_admin`, `name_admin`, `phone_admin`, `email_admin`, `notify`, `domain`, `status`, `status_random`, `rd_1`, `rd_2`, `rd_3`, `rd_4`, `rd_5`, `rd_6`, `rd_7`, `rd_8`, `rd_9`, `rd_10`, `rd_11`, `rd_12`, `rd_13`, `rd_14`, `rd_15`) VALUES
('SHOPHOANGNAM.TK - SHOP THỬ VẬN MAY KIM CƯƠNG TRÚNG NGAY 9999 TRON HÔM NAY !', 'Bán nick free fire shop thử vận may rankom free fire , liên quân, ', 'Shop bán acc , free fire,liên quân , uy tín lớn nhất Việt Nam.', '', '', 'https://facebook.com/CEO.SOCIAL.VHN', 'Trịnh Quang Hưng ', '0858812179', 'quanghungtrinh789123456@gmail.com', 'NẠP THẺ 100K TRỞ LÊN TỶ LỆ TRÚNG 9999KC CỰC CAO ❤️ MỪNG RA MẮT BỘ TỨ M1014, SHOP TĂNG TỶ LỆ TRÚNG KIM CƯƠNG CỰC CAO ❤️ AE TRANH THỦ QUAY KIM CƯƠNG TRONG THỜI GIAN HÈ NÀY NHA ❤️', 'https://shophoangnam.tk', 1, 1, 7000, 20000, 50000, 100000, 200000, 20000, 50000, 100000, 200000, 20000, 20000, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `setting_wheel`
--

CREATE TABLE `setting_wheel` (
  `1` int(11) NOT NULL DEFAULT '0',
  `2` int(11) NOT NULL DEFAULT '0',
  `3` int(11) NOT NULL DEFAULT '0',
  `4` int(11) NOT NULL DEFAULT '0',
  `5` int(11) NOT NULL DEFAULT '0',
  `6` int(11) NOT NULL DEFAULT '0',
  `7` int(11) NOT NULL DEFAULT '0',
  `8` int(11) NOT NULL DEFAULT '0',
  `huvang` int(11) NOT NULL DEFAULT '0',
  `wheel_price` int(11) NOT NULL DEFAULT '0',
  `id_nohu` text COLLATE utf8_unicode_ci,
  `status` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `setting_wheel`
--

INSERT INTO `setting_wheel` (`1`, `2`, `3`, `4`, `5`, `6`, `7`, `8`, `huvang`, `wheel_price`, `id_nohu`, `status`) VALUES
(0, 1000, 100, 0, 100, 100, 100, 100, 82579064, 20000, 'v&otilde; ho&agrave;ng nam', 1);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `setting_wheel1`
--

CREATE TABLE `setting_wheel1` (
  `1` int(11) NOT NULL,
  `2` int(11) NOT NULL,
  `3` int(11) NOT NULL,
  `4` int(11) NOT NULL,
  `5` int(11) NOT NULL,
  `6` int(11) NOT NULL,
  `7` int(11) NOT NULL,
  `8` int(11) NOT NULL,
  `huvang` int(11) NOT NULL,
  `wheel_price` int(11) NOT NULL,
  `id_nohu` text CHARACTER SET utf8 COLLATE utf8_unicode_ci,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `top_recharge`
--

CREATE TABLE `top_recharge` (
  `id` int(11) NOT NULL,
  `username` text COLLATE utf8_unicode_ci NOT NULL,
  `name` text COLLATE utf8_unicode_ci NOT NULL,
  `cash` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `top_recharge`
--

INSERT INTO `top_recharge` (`id`, `username`, `name`, `cash`) VALUES
(1, 'phidoivox', 'vohoangnam', 900000);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `wheel`
--

CREATE TABLE `wheel` (
  `id` int(11) NOT NULL,
  `iduser` text COLLATE utf8_unicode_ci NOT NULL,
  `type` int(11) NOT NULL,
  `username` text COLLATE utf8_unicode_ci NOT NULL,
  `password` text COLLATE utf8_unicode_ci NOT NULL,
  `status` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `wheel1`
--

CREATE TABLE `wheel1` (
  `id` int(11) NOT NULL COMMENT '	',
  `iduser` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` int(11) NOT NULL,
  `username` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Chỉ mục cho các bảng đã đổ
--

--
-- Chỉ mục cho bảng `accounts`
--
ALTER TABLE `accounts`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `acc_random`
--
ALTER TABLE `acc_random`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `history_buy`
--
ALTER TABLE `history_buy`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `history_card`
--
ALTER TABLE `history_card`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `history_dff`
--
ALTER TABLE `history_dff`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `history_wheel`
--
ALTER TABLE `history_wheel`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `HK_lattheff`
--
ALTER TABLE `HK_lattheff`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `lq_champion`
--
ALTER TABLE `lq_champion`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `lq_skin`
--
ALTER TABLE `lq_skin`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`status`);

--
-- Chỉ mục cho bảng `setting_wheel`
--
ALTER TABLE `setting_wheel`
  ADD PRIMARY KEY (`1`);

--
-- Chỉ mục cho bảng `top_recharge`
--
ALTER TABLE `top_recharge`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `wheel`
--
ALTER TABLE `wheel`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `wheel1`
--
ALTER TABLE `wheel1`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT cho các bảng đã đổ
--

--
-- AUTO_INCREMENT cho bảng `accounts`
--
ALTER TABLE `accounts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT cho bảng `acc_random`
--
ALTER TABLE `acc_random`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT cho bảng `history_buy`
--
ALTER TABLE `history_buy`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT cho bảng `history_card`
--
ALTER TABLE `history_card`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT cho bảng `history_dff`
--
ALTER TABLE `history_dff`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=44;

--
-- AUTO_INCREMENT cho bảng `history_wheel`
--
ALTER TABLE `history_wheel`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=345;

--
-- AUTO_INCREMENT cho bảng `HK_lattheff`
--
ALTER TABLE `HK_lattheff`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT cho bảng `lq_champion`
--
ALTER TABLE `lq_champion`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT cho bảng `lq_skin`
--
ALTER TABLE `lq_skin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT cho bảng `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT cho bảng `top_recharge`
--
ALTER TABLE `top_recharge`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT cho bảng `wheel`
--
ALTER TABLE `wheel`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
